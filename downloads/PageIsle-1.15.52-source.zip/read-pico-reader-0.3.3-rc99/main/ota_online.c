/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 * 中文：HTTPS 分块下载、完整性校验和可取消升级任务。/ English: streamed HTTPS updates, integrity checks and cancellable workers.
 * 冻结：禁止覆盖当前槽；离页或锁屏先等待任务结束。/ Frozen: never overwrite the running slot; join before leaving or locking.
 * 用户修订：分段擦除并串行化闪存与屏幕推送，启动前检查连续内存，低内存安全失败。
 * User revision: erase incrementally and serialize flash with display output; require memory headroom and fail safely on shortage.
 */
#include "ota_online.h"
#include "esp_app_desc.h"
#include "esp_app_format.h"
#include "esp_crt_bundle.h"
#include "esp_heap_caps.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "ble_page_turner.h"
#include "read_pico_transfer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "psa/crypto.h"
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <time.h>

static SemaphoreHandle_t s_mutex, s_done, s_flash_display;
static pico_update_status_t *s_status;
static atomic_bool s_cancel;
static bool s_joinable, s_download;
static const char *TAG = "ota_online";
// 本次任务是否持有“网络占用”（挂起蓝牙翻页器）；由 start() 取得、worker() 结束时归还。
// Whether this job holds the network reservation that keeps the BLE page-turner paused;
// acquired by start() and released when worker() finishes.
static bool s_ble_held;
static const esp_partition_t *s_verified;

// 门槛按 OTA 自己的分配量来定，而不是 rc100 在“无蓝牙、未联网”状态下量到的经验值：
// 任务栈 12,288 B 必须连续（FreeRTOS 把栈和 TCB 放在同一块），下载缓冲 4,096 + 288 B
// 走内部 RAM，mbedTLS 的 SSL 缓冲/上下文走 PSRAM（CONFIG_MBEDTLS_EXTERNAL_MEM_ALLOC=y）。
// 本固件静态 DIRAM 只剩约 85 KB 给堆（idf.py size），WiFi 驱动在 esp_wifi_init() 里
// 还要占十几 KB 内部 RAM 的静态收发缓冲，所以联网后再要求 32 KB 内部空闲必然失败。
// Floors follow this job's actual allocations rather than rc100's measurements taken with
// the radio off: the 12,288 B task stack must be contiguous (FreeRTOS keeps stack and TCB
// in one block), the 4,096 + 288 B download buffers are internal RAM, and mbedTLS' SSL
// buffers/context live in PSRAM (CONFIG_MBEDTLS_EXTERNAL_MEM_ALLOC=y). Static DIRAM leaves
// only ~85 KB for the heap (idf.py size) and esp_wifi_init() reserves more internal RAM for
// its static RX/TX buffers, so a 32 KB internal floor after Wi-Fi is up can never pass.
#define OTA_INTERNAL_RADIO (48 * 1024)   // 需要启动 STA 时给 WiFi 驱动的余量。/ Headroom for esp_wifi_init().
#define OTA_INTERNAL_NETUP (20 * 1024)   // STA 已就绪时只需任务栈加缓冲。/ Task stack plus buffers when STA is up.
#define OTA_INTERNAL_BLOCK (16 * 1024)   // xTaskCreate 需要一块 ≥ 栈大小的连续块。/ Contiguous block for xTaskCreate.
#define OTA_PSRAM_START (512 * 1024)     // 清单、release 与 TLS 的 PSRAM 余量。/ Feed, release and TLS headroom.
#define OTA_PSRAM_RADIO (256 * 1024)     // 无线电起来后的 TLS 下限。/ TLS floor once the radio is up.

static bool initialize(void) {
    if (!s_status) s_status = heap_caps_calloc(1, sizeof(*s_status), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_mutex) s_mutex = xSemaphoreCreateMutex();
    if (!s_done) s_done = xSemaphoreCreateBinary();
    if (!s_flash_display) s_flash_display = xSemaphoreCreateRecursiveMutex();
    return s_status && s_mutex && s_done && s_flash_display;
}
// 显示/OTA 递归锁必须在开机时就有：推屏出口、低优先级断电任务都靠它互斥，不能等第一次进
// 升级页才创建（否则未进过升级页的会话里 begin() 恒为 false，互斥完全失效）。
// The display/OTA recursive mutex must exist from boot: output paths and the low-priority power-off
// task rely on it, so it cannot wait for the first visit to the upgrade page.
void pico_online_display_lock_init(void) {
    if (!s_flash_display) s_flash_display = xSemaphoreCreateRecursiveMutex();
}
bool pico_online_display_begin(void) {
    if (!s_flash_display) pico_online_display_lock_init();
    return s_flash_display && xSemaphoreTakeRecursive(s_flash_display, portMAX_DELAY) == pdTRUE;
}
void pico_online_display_end(bool held) {
    if (held) xSemaphoreGiveRecursive(s_flash_display);
}
static bool psram_available(size_t external_min) {
    const unsigned external = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT;
    return heap_caps_get_free_size(external) >= external_min &&
        heap_caps_get_largest_free_block(external) >= 32768;
}
static bool memory_available(size_t internal_min, size_t internal_block, size_t external_min) {
    const unsigned internal = MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT;
    return heap_caps_get_free_size(internal) >= internal_min &&
        heap_caps_get_largest_free_block(internal) >= internal_block &&
        psram_available(external_min);
}
// 失败时把四项实测值写进日志：无串口时 USB Serial/JTAG 也能看到，方便下次真机定位
// 是哪一项（内部/PSRAM 的空闲或最大块）不足，而不是只看一句“内存不足”。
// Log the four measured values on failure; USB Serial/JTAG shows them even without a UART
// console, so the next device test can tell which floor (internal/PSRAM free or block) failed.
static void log_memory(const char *where) {
    const unsigned internal = MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT;
    const unsigned external = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT;
    ESP_LOGW(TAG, "%s: internal %u/%u psram %u/%u", where,
        (unsigned)heap_caps_get_free_size(internal),
        (unsigned)heap_caps_get_largest_free_block(internal),
        (unsigned)heap_caps_get_free_size(external),
        (unsigned)heap_caps_get_largest_free_block(external));
}
// 取得网络占用会串行停止蓝牙；失败（超时）不算致命，只是少回收这部分内部 RAM。
// Taking the reservation stops BLE serially; a timeout is not fatal, it only skips the reclaim.
static void release_ble(void) {
    if (!s_ble_held) return;
    s_ble_held = false;
    ble_pt_network_release();
}
// 锁只覆盖闪存操作，不覆盖网络等待、状态互斥锁或任务收尾，避免取消/刷屏互相等待。
// Lock flash operations only, excluding network waits, status locks and joins to avoid cancellation/display deadlocks.
static esp_err_t flash_begin(const esp_partition_t *target, esp_ota_handle_t *handle) {
    bool held = pico_online_display_begin();
    esp_err_t error = esp_ota_begin(target, OTA_WITH_SEQUENTIAL_WRITES, handle);
    pico_online_display_end(held);
    return error;
}
static esp_err_t flash_write(esp_ota_handle_t handle, const void *data, size_t size) {
    bool held = pico_online_display_begin();
    esp_err_t error = esp_ota_write(handle, data, size);
    pico_online_display_end(held);
    return error;
}
static esp_err_t flash_finish(esp_ota_handle_t handle, bool aborting) {
    bool held = pico_online_display_begin();
    esp_err_t error = aborting ? esp_ota_abort(handle) : esp_ota_end(handle);
    pico_online_display_end(held);
    return error;
}
static void state(pico_update_state_t value, const char *message) {
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    s_status->state = value;
    snprintf(s_status->message, sizeof(s_status->message), "%s", message);
    ++s_status->revision;
    xSemaphoreGive(s_mutex);
}
bool pico_online_busy(void) {
    if (!s_status || !s_mutex) return false;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    bool busy = s_status->busy;
    xSemaphoreGive(s_mutex); return busy;
}
void pico_online_get_status(pico_update_status_t *status) {
    if (!status) return;
    memset(status, 0, sizeof(*status));
    if (!s_status || !s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    memcpy(status, s_status, sizeof(*status));
    xSemaphoreGive(s_mutex);
}
static bool layout_valid(void) {
    const esp_partition_t *a = esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, NULL);
    const esp_partition_t *b = esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_1, NULL);
    const esp_partition_t *data = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, NULL);
    return a && b && data && a->address == 0x10000 && b->address == 0x910000 &&
        a->size == 0x400000 && b->size == 0x400000 && data->address == 0xd10000 && data->size == 0x2000;
}
static bool online(bool *owned) {
    read_pico_transfer_status_t status;
    read_pico_transfer_get_status(&status);
    if (!(status.mode == READ_PICO_TRANSFER_MODE_STA && status.network_ready)) {
        char ssid[33]; bool saved = false;
        if (read_pico_transfer_get_saved_wifi(ssid, &saved) != ESP_OK || !saved) {
            state(PICO_UPDATE_FAILED, "请先在 WiFi 设置中连接网络"); return false;
        }
        read_pico_transfer_stop();
        read_pico_transfer_cfg_t cfg = {.mode = READ_PICO_TRANSFER_MODE_STA, .network_only = true};
        *owned = true;
        const esp_err_t start_error = read_pico_transfer_start(&cfg);
        if (start_error != ESP_OK) {
            // 启动无线电失败时区分“真的没内存”：WiFi 驱动初始化要占内部 RAM。
            // Distinguish a real memory shortage: esp_wifi_init() needs internal RAM.
            state(PICO_UPDATE_FAILED, start_error == ESP_ERR_NO_MEM
                ? "内存不足，请退出传书后重试" : "WiFi 连接失败，请重试");
            return false;
        }
    }
    int64_t deadline = esp_timer_get_time() + 30000000;
    while (!atomic_load(&s_cancel)) {
        read_pico_transfer_service_poll();
        read_pico_transfer_get_status(&status);
        if (status.mode == READ_PICO_TRANSFER_MODE_STA && status.network_ready) {
            if (time(NULL) < 1704067200) {
                uint32_t utc;
                if (read_pico_transfer_sync_time_online(&utc) != ESP_OK) {
                    state(PICO_UPDATE_FAILED, "网络对时失败，请对时后重试"); return false;
                }
            }
            return !atomic_load(&s_cancel);
        }
        if (status.state == READ_PICO_TRANSFER_ERROR || esp_timer_get_time() >= deadline) break;
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    if (!atomic_load(&s_cancel)) state(PICO_UPDATE_FAILED, "网络连接超时，请重试");
    return false;
}
typedef struct {
    uint32_t start, end, size;
    bool valid;
} download_range_t;
static esp_err_t range_header(esp_http_client_event_t *event) {
    download_range_t *range = event->user_data;
    if (!range || event->event_id != HTTP_EVENT_ON_HEADER || !event->header_key || !event->header_value)
        return ESP_OK;
    if (!strcasecmp(event->header_key, "Content-Range")) {
        unsigned long start, end, size; char tail;
        range->valid = strnlen(event->header_value, 96) < 96 &&
            sscanf(event->header_value, "bytes %lu-%lu/%lu%c", &start, &end, &size, &tail) == 3 &&
            start <= end && end < size && size <= UINT32_MAX;
        if (range->valid) { range->start = start; range->end = end; range->size = size; }
    }
    return ESP_OK;
}
static esp_http_client_handle_t open_http_range(const char *url, uint32_t offset,
        download_range_t *range, int *status, int64_t *length) {
    if (range) memset(range, 0, sizeof(*range));
    esp_http_client_config_t cfg = {.url = url, .timeout_ms = 15000, .buffer_size = 2048,
        .buffer_size_tx = 1024, .crt_bundle_attach = esp_crt_bundle_attach,
        .disable_auto_redirect = true, .keep_alive_enable = true,
        .event_handler = range_header, .user_data = range};
    esp_http_client_handle_t client = esp_http_client_init(&cfg);
    if (!client) return NULL;
    esp_http_client_set_header(client, "User-Agent", PICO_OTA_CAPABILITY);
    esp_http_client_set_header(client, "Accept-Encoding", "identity");
    esp_http_client_set_header(client, "Cache-Control", "no-cache");
    if (offset) {
        char value[48]; snprintf(value, sizeof(value), "bytes=%lu-", (unsigned long)offset);
        if (esp_http_client_set_header(client, "Range", value) != ESP_OK) goto fail;
    }
    if (esp_http_client_open(client, 0) != ESP_OK || atomic_load(&s_cancel)) goto fail;
    *length = esp_http_client_fetch_headers(client);
    if (*length < 0 || atomic_load(&s_cancel)) goto fail;
    *status = esp_http_client_get_status_code(client);
    esp_http_client_set_timeout_ms(client, 1000);
    return client;
fail:
    esp_http_client_cleanup(client);
    return NULL;
}
static esp_http_client_handle_t open_http(const char *url, int *status, int64_t *length) {
    return open_http_range(url, 0, NULL, status, length);
}
// 复用连接管理器等待短暂断网恢复，允许取消，不重启整个无线服务。
// Wait for the connection manager to recover a short outage, with cancellation and no radio restart.
static bool wait_network(void) {
    int64_t deadline = esp_timer_get_time() + 30000000;
    while (!atomic_load(&s_cancel) && esp_timer_get_time() < deadline) {
        read_pico_transfer_service_poll();
        read_pico_transfer_status_t status;
        read_pico_transfer_get_status(&status);
        if (status.mode == READ_PICO_TRANSFER_MODE_STA && status.network_ready) return true;
        if (status.state == READ_PICO_TRANSFER_ERROR) return false;
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    return false;
}
// 读超时可重试；每次收到数据续期，避免慢速网络被总时长截断。
// Retry temporary read timeouts and renew the idle deadline after each chunk.
static int read_chunk(esp_http_client_handle_t client, uint8_t *buffer, int cap, int64_t *idle) {
    while (!atomic_load(&s_cancel) && esp_timer_get_time() < *idle) {
        read_pico_transfer_service_poll();
        int n = esp_http_client_read(client, (char *)buffer, cap);
        if (n > 0) { *idle = esp_timer_get_time() + 30000000; return n; }
        if (!n && esp_http_client_is_complete_data_received(client)) return 0;
        if (n < 0 && n != -ESP_ERR_HTTP_EAGAIN) return -1;
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    return -1;
}
static bool check_feed(void) {
    char *json = heap_caps_malloc(8193, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    pico_release_t *release = heap_caps_calloc(1, sizeof(*release), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!json || !release) { log_memory("feed buffer"); state(PICO_UPDATE_FAILED, "内存不足，请退出传书后重试"); goto failed; }
    // GitHub Pages清单优先，官网清单备用；同一缓冲区顺序请求，无并发TLS连接。
    // Prefer GitHub Pages metadata, falling back to the website with one shared buffer and no concurrent TLS clients.
    static const char *const feeds[] = {PICO_OTA_FEED_URL, PICO_OTA_FEED_FALLBACK_URL};
    bool valid = false;
    for (size_t source = 0; source < sizeof(feeds) / sizeof(feeds[0]) && !atomic_load(&s_cancel); ++source) {
        char url[192]; snprintf(url, sizeof(url), "%s?t=%lld", feeds[source], (long long)time(NULL));
        int code = -1; int64_t length = -1;
        esp_http_client_handle_t client = NULL;
        for (int i = 0; i < 2 && !atomic_load(&s_cancel); ++i) {
            if (wait_network()) client = open_http(url, &code, &length);
            if (client) break;
            vTaskDelay(pdMS_TO_TICKS(250));
        }
        if (!client) continue;
        if (code != 200 || length > 8192) { esp_http_client_cleanup(client); continue; }
        size_t received = 0;
        int64_t idle = esp_timer_get_time() + 30000000;
        int n = -1;
        while (received < 8192 && (n = read_chunk(client, (uint8_t *)json + received, (int)(8192 - received), &idle)) > 0)
            received += n;
        bool complete = esp_http_client_is_complete_data_received(client);
        esp_http_client_cleanup(client);
        json[received] = 0;
        if (n >= 0 && complete && pico_release_parse(json, received, release) == ESP_OK) { valid = true; break; }
    }
    if (!valid) { state(PICO_UPDATE_FAILED, "更新服务器连接失败或清单无效，请稍后重试"); goto failed; }
    const esp_app_desc_t *running = esp_app_get_description();
    if (strcmp(release->project, running->project_name) || !layout_valid() ||
        pico_version_compare(running->version, release->minimum_base_version) < 0) {
        state(PICO_UPDATE_FAILED, "基础包不兼容，请先通过官网完整刷机"); goto failed;
    }
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    memcpy(&s_status->release, release, sizeof(*release));
    xSemaphoreGive(s_mutex);
    state(pico_version_compare(release->version, running->version) > 0 ? PICO_UPDATE_AVAILABLE : PICO_UPDATE_LATEST,
          pico_version_compare(release->version, running->version) > 0 ? "发现新版本，可下载安装" : "当前已是最新版本");
    heap_caps_free(json); heap_caps_free(release);
    return true;
failed:
    heap_caps_free(json); heap_caps_free(release);
    return false;
}
static bool header_valid(const uint8_t *data, const pico_release_t *release) {
    const esp_image_header_t *header = (const esp_image_header_t *)data;
    const esp_app_desc_t *desc = (const esp_app_desc_t *)(data + sizeof(*header) + sizeof(esp_image_segment_header_t));
    const esp_app_desc_t *current = esp_app_get_description();
    return header->magic == ESP_IMAGE_HEADER_MAGIC && header->chip_id == ESP_CHIP_ID_ESP32S3 &&
        desc->magic_word == ESP_APP_DESC_MAGIC_WORD &&
        memchr(desc->project_name, 0, sizeof(desc->project_name)) && memchr(desc->version, 0, sizeof(desc->version)) &&
        !strcmp(desc->project_name, current->project_name) && !strcmp(desc->version, release->version);
}
static bool download(void) {
    pico_release_t *release = heap_caps_malloc(sizeof(*release), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    uint8_t *buffer = heap_caps_malloc(4096, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    uint8_t *header = heap_caps_malloc(288, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!release || !buffer || !header) { log_memory("download buffer"); state(PICO_UPDATE_FAILED, "内存不足，无法下载升级包"); goto failed; }
    xSemaphoreTake(s_mutex, portMAX_DELAY); *release = s_status->release; xSemaphoreGive(s_mutex);
    const esp_partition_t *target = esp_ota_get_next_update_partition(NULL);
    if (!layout_valid() || !target || target == esp_ota_get_running_partition() || release->size > target->size) {
        state(PICO_UPDATE_FAILED, "基础包不兼容，请通过官网完整刷机"); goto failed;
    }
    int code = -1; int64_t length = -1;
    esp_http_client_handle_t client = NULL;
    download_range_t range;
    esp_ota_handle_t handle = 0;
    psa_hash_operation_t hash = PSA_HASH_OPERATION_INIT;
    bool begun = false;
    esp_err_t error = ESP_OK;
    if (psa_crypto_init() != PSA_SUCCESS || psa_hash_setup(&hash, PSA_ALG_SHA_256) != PSA_SUCCESS) error = ESP_FAIL;
    size_t total = 0, header_size = 0;
    int64_t idle = esp_timer_get_time() + 30000000;
    int n = -1;
    unsigned retries = 0;
    bool complete = false;
    while (error == ESP_OK && !atomic_load(&s_cancel)) {
        if (!client) {
            if (wait_network()) client = open_http_range(release->url, total, &range, &code, &length);
            if (!client) {
                if (atomic_load(&s_cancel) || retries++ >= 3) { error = ESP_FAIL; break; }
                vTaskDelay(pdMS_TO_TICKS(250 * retries)); continue;
            }
            // 续传必须严格匹配起点与全文件长度；最终仍验证整本镜像的 SHA256。
            // Resumed responses must match their offset and full length; the whole image still gets SHA256 verification.
            bool response_ok = total ? code == 206 && range.valid && range.start == total &&
                range.size == release->size && range.end == release->size - 1 : code == 200;
            if (!response_ok || (length > 0 && (uint64_t)length != release->size - total)) {
                error = ESP_ERR_INVALID_RESPONSE; break;
            }
            idle = esp_timer_get_time() + 30000000;
        }
        n = read_chunk(client, buffer, 4096, &idle);
        if (n <= 0) {
            complete = esp_http_client_is_complete_data_received(client);
            esp_http_client_cleanup(client); client = NULL;
            if (n == 0 && complete && total == release->size) break;
            complete = false;
            if (total >= release->size || atomic_load(&s_cancel) || retries++ >= 3) { error = ESP_FAIL; break; }
            vTaskDelay(pdMS_TO_TICKS(250 * retries));
            continue;
        }
        if (total + n > release->size) { error = ESP_ERR_INVALID_SIZE; break; }
        size_t used = 0;
        if (!begun) {
            size_t needed = 288 - header_size;
            used = (size_t)n < needed ? (size_t)n : needed;
            memcpy(header + header_size, buffer, used); header_size += used;
            if (header_size == 288) {
                if (!header_valid(header, release)) { error = ESP_ERR_INVALID_RESPONSE; break; }
                error = flash_begin(target, &handle);
                begun = error == ESP_OK;
                if (begun) error = flash_write(handle, header, header_size);
            }
        }
        if (error == ESP_OK && begun && (size_t)n > used) error = flash_write(handle, buffer + used, n - used);
        if (error != ESP_OK || psa_hash_update(&hash, buffer, n) != PSA_SUCCESS) { error = ESP_FAIL; break; }
        total += n;
        xSemaphoreTake(s_mutex, portMAX_DELAY);
        s_status->received = total; ++s_status->revision;
        xSemaphoreGive(s_mutex);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    if (client) esp_http_client_cleanup(client);
    uint8_t digest[32]; size_t digest_size = 0; char hex[65];
    if (error == ESP_OK && (!begun || n < 0 || !complete || total != release->size || atomic_load(&s_cancel))) error = ESP_FAIL;
    if (error == ESP_OK && psa_hash_finish(&hash, digest, sizeof(digest), &digest_size) != PSA_SUCCESS) error = ESP_FAIL;
    psa_hash_abort(&hash);
    if (error == ESP_OK) {
        for (unsigned i = 0; i < 32; ++i) snprintf(hex + i * 2, 3, "%02x", digest[i]);
        if (digest_size != 32 || strcasecmp(hex, release->sha256)) error = ESP_ERR_INVALID_RESPONSE;
    }
    if (error != ESP_OK) {
        if (begun) flash_finish(handle, true);
        state(PICO_UPDATE_FAILED, "下载中断或校验失败，当前版本保持不变"); goto failed;
    }
    error = flash_finish(handle, false);
    if (error != ESP_OK) { state(PICO_UPDATE_FAILED, "固件校验失败，当前版本保持不变"); goto failed; }
    // 后台仅验证镜像；主线程处理最终启动切换，取消时不影响当前槽。
    // The worker verifies only; the main task commits boot, so cancellation cannot change the running slot.
    xSemaphoreTake(s_mutex, portMAX_DELAY); s_verified = target; xSemaphoreGive(s_mutex);
    state(PICO_UPDATE_READY, "校验通过，即将重启安装");
    heap_caps_free(release); heap_caps_free(buffer); heap_caps_free(header);
    return true;
failed:
    heap_caps_free(release); heap_caps_free(buffer); heap_caps_free(header);
    return false;
}
static void worker(void *unused) {
    (void)unused;
    bool owned = false;
    wifi_ps_type_t previous_ps = WIFI_PS_MIN_MODEM;
    bool restore_ps = false;
    if (online(&owned) && !atomic_load(&s_cancel)) {
        // 更新期间关闭无线省电；完成、取消和失败均恢复原策略。
        // Disable radio power saving for updates, then restore it on success, cancellation or failure.
        restore_ps = esp_wifi_get_ps(&previous_ps) == ESP_OK && esp_wifi_set_ps(WIFI_PS_NONE) == ESP_OK;
        // 无线电起来后内部堆已被 WiFi 驱动的静态收发缓冲占掉一大块，这里再按 32 KB 判断
        // 只会把可用的场景误判成内存不足；下载缓冲由 download() 自己申请并按准确文案报错，
        // 因此这个时点只校验 PSRAM（TLS 缓冲/上下文走 PSRAM）。
        // Once the radio is up, the WiFi driver's static RX/TX buffers have taken most of the
        // internal heap; a 32 KB internal floor here only rejects workable cases. download()
        // allocates its own buffers and reports accurately, so only the PSRAM floor is checked.
        if (!psram_available(OTA_PSRAM_RADIO)) {
            log_memory("radio up");
            state(PICO_UPDATE_FAILED, "内存不足，请退出传书后重试");
        } else if (s_download) (void)download(); else (void)check_feed();
    }
    if (restore_ps) (void)esp_wifi_set_ps(previous_ps);
    if (owned) read_pico_transfer_stop();
    if (atomic_load(&s_cancel)) state(PICO_UPDATE_CANCELLED, "已取消，当前版本保持不变");
    // 先等传书组件停完无线电（它会释放自己的那份占用），再归还本任务取得的蓝牙占用；
    // 顺序反过来可能在停服过程中让主循环把蓝牙重新拉起来。
    // Stop the transfer radio first (it releases its own reservation), then hand back this
    // job's BLE reservation; the opposite order could let the main loop restart BLE mid-teardown.
    release_ble();
    xSemaphoreTake(s_mutex, portMAX_DELAY); s_status->busy = false; ++s_status->revision; xSemaphoreGive(s_mutex);
    xSemaphoreGive(s_done);
    vTaskDelete(NULL);
}
static esp_err_t start(bool downloading) {
    if (!initialize()) return ESP_ERR_NO_MEM;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    bool busy = s_status->busy;
    bool available = s_status->state == PICO_UPDATE_AVAILABLE;
    xSemaphoreGive(s_mutex);
    if (busy || (downloading && !available)) return ESP_ERR_INVALID_STATE;
    if (s_joinable) { xSemaphoreTake(s_done, portMAX_DELAY); s_joinable = false; }
    // 先暂停蓝牙翻页器再查内存：NimBLE 的 host 任务栈与控制器缓冲占用内部 RAM，而真正的
    // OTA 联网流程本来就会在 read_pico_transfer_start() 里 ble_pt_network_acquire() 暂停它；
    // 若等到 worker 里才释放，启动门槛会把“暂时被蓝牙占着”的内部内存判成不足（误报）。
    // 占用一直持有到 worker 结束，既避免误判，也防止主循环在检查/下载期间把蓝牙拉起来。
    // Pause the BLE page-turner before the gate: NimBLE's host stack and controller buffers
    // live in internal RAM and the OTA flow pauses it anyway inside read_pico_transfer_start().
    // Waiting until the worker would turn "temporarily held by BLE" into a false shortage.
    // The reservation is held until the worker ends, so the main loop cannot restart BLE
    // during the check/download either.
    s_ble_held = ble_pt_network_acquire() == ESP_OK;
    read_pico_transfer_status_t network = {0};
    read_pico_transfer_get_status(&network);
    // 任何进行中的传书会话（启动中/已就绪/接收中）都说明无线电已经起来并占着内部 RAM；
    // 这时 OTA 只需自己的任务栈与缓冲，不必再按“要启动 WiFi”预留那几十 KB。
    // Any live transfer session (starting/ready/receiving) means the radio is already up and
    // holding internal RAM; OTA then only needs its own stack and buffers, not the radio headroom.
    const bool radio_up = network.state == READ_PICO_TRANSFER_STARTING ||
        network.state == READ_PICO_TRANSFER_READY || network.state == READ_PICO_TRANSFER_UPLOADING;
    const bool network_up = network.mode == READ_PICO_TRANSFER_MODE_STA && network.network_ready;
    const size_t internal_min = (radio_up || network_up) ? OTA_INTERNAL_NETUP : OTA_INTERNAL_RADIO;
    if (!memory_available(internal_min, OTA_INTERNAL_BLOCK, OTA_PSRAM_START)) {
        // 页面绘制/头像解码的临时 PSRAM 可能刚归还；给一次短暂重试再判失败。
        // Temporary PSRAM from page painting may have just landed back on the heap; retry once.
        vTaskDelay(pdMS_TO_TICKS(200));
        if (!memory_available(internal_min, OTA_INTERNAL_BLOCK, OTA_PSRAM_START)) {
            log_memory(radio_up || network_up ? "start netup" : "start radio");
            release_ble();
            state(PICO_UPDATE_FAILED, "内存不足，请退出传书后重试");
            return ESP_ERR_NO_MEM;
        }
    }
    atomic_store(&s_cancel, false);
    s_download = downloading; s_verified = NULL;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    s_status->busy = true; s_status->received = 0;
    xSemaphoreGive(s_mutex);
    state(downloading ? PICO_UPDATE_DOWNLOADING : PICO_UPDATE_CHECKING,
          downloading ? "正在下载，短暂断网会自动重连" : "正在连接并检查更新");
    if (xTaskCreate(worker, "kiikoread_ota", 12288, NULL, 4, NULL) != pdPASS) {
        xSemaphoreTake(s_mutex, portMAX_DELAY); s_status->busy = false; xSemaphoreGive(s_mutex);
        log_memory("worker task");
        release_ble();
        state(PICO_UPDATE_FAILED, "内存不足，无法开始升级"); return ESP_ERR_NO_MEM;
    }
    s_joinable = true;
    return ESP_OK;
}
esp_err_t pico_online_check(void) { return start(false); }
esp_err_t pico_online_download(void) { return start(true); }
void pico_online_cancel_join(void) {
    if (s_joinable) {
        atomic_store(&s_cancel, true);
        xSemaphoreTake(s_done, portMAX_DELAY); s_joinable = false;
    }
    s_verified = NULL;
    if (s_status && s_status->state == PICO_UPDATE_READY) state(PICO_UPDATE_CANCELLED, "已取消，当前版本保持不变");
}
esp_err_t pico_online_commit(void) {
    if (s_joinable) { xSemaphoreTake(s_done, portMAX_DELAY); s_joinable = false; }
    if (!s_verified || atomic_load(&s_cancel)) return ESP_ERR_INVALID_STATE;
    bool held = pico_online_display_begin();
    esp_err_t error = esp_ota_set_boot_partition(s_verified);
    pico_online_display_end(held);
    s_verified = NULL;
    if (error != ESP_OK) state(PICO_UPDATE_FAILED, "启动切换失败，当前版本保持不变");
    return error;
}
