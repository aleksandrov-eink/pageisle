/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：分组设置页；网络短时对时后 PMU 持续走时，开机恢复系统时钟。
 * English: Grouped settings; temporary WiFi sync seeds the PMU, whose RTC restores time at boot.
 * 用户修订：设置列表滑动仅差分刷新内容，滑动过程中不周期插入黑白清屏。
 * User revision: settings lists scroll with content-only differentials and no periodic black/white wipe during swipes.
 * 用户授权新输入法：资料卡和签名共用九宫格/全键盘及离线词语候选，保存仍由设置页负责。
 * Authorized keyboard revision: profile and signature share T9/QWERTY and offline phrases; this page still owns saving.
 * 用户修订：资料卡与签名输入只画变化区域，不因输入次数触发整屏黑白清屏。
 * User revision: profile/signature input paints changed regions without whole-screen wipes based on typing counts.
 * 用户修订：快刷说明标注棋盘格亚克力，普通与水波纹继续保留灰阶；三种主页面刷新模式均固定底栏。
 * User revision: the fast-mode description identifies checkerboard acrylic; ordinary/water keep grays and all main-screen modes retain navigation.
 * 用户修订：联网升级先画反馈再启动任务；进度只追加黑色段，不擦除已完成段，不累计整页清屏。升级前释放不在显示的封面缓存。
 * User revision: present feedback before starting online work; append black progress without erasing completed segments or counting page cleanup. Release off-screen cover caches before updating.
 * 用户确认：字号并入系统字体并预览；选择字体后询问同步阅读字体，设置按连接/显示/个性化/升级分组。
 * Approved revision: size and preview live with the UI face; ask before syncing the reading face, and group connection/display/personalization/maintenance.
 * 用户修订：设置题头与列表周围留白保持纯白，普通主页切入/周期整理复用书架同轮分区输出；题头柔和，内容白像素只向白擦除，灰阶保留。普通列表滑动使用柔和差分；手动全刷、离散滚动和快刷/水波纹节奏保持。
 * User revision: keep setting chrome/list whitespace white. Ordinary root entry/periodic cleanup reuse simultaneous shelf regions with soft chrome, directional white content and preserved grays. Scroll ordinary lists with soft differences; retain manual full refresh, discrete gestures and fast/ripple pacing.
 * 用户2026-10-20修订：设置二级页常驻灰底栏，内容止于底栏上方，返回清理和不可中断任务守卫保持。
 * User revision2026-10-20: settings children retain gray navigation; content stops above it, reusing back cleanup and noninterruptible-job guards.
 * S31用户修订：设置主列表内容规整为黑白并使用DU20，固定底栏不变；子页的字体/壁纸预览仍保留灰阶。
 * S31 user revision: normalize root settings content to BW and use DU20, retaining fixed navigation and gray font/wallpaper previews in subpages.
 * 用户撤回跟手滚动：三种主页模式统一恢复一次手势推进一段列表并差分刷新的原逻辑，无惯性、浅墨或停稳补刷。
 * User rollback: all main modes return to one discrete list step per gesture with differential updates, without inertia, light motion ink or idle restoration.
 * 用户2026-10-21修订：设置列表滚动保留文字抗锯齿和灰阶头像，撤掉书架额外四相补白，列表仍一次输出且不影响固定底栏。
 * User revision2026-10-21: keep AA text and gray avatars during list scrolls, omit the shelf's four added white phases, and retain one output with fixed navigation.
 */
#include <stdio.h>
#include <stdlib.h>
#include "pageisle_version.h"
#include "esp_heap_caps.h"
#include <dirent.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>

#include "app.h"
#include "app_content_open.h"
#include "app_registry.h"
#include "app_ram_diag.h"
#include "app_transfer_mode.h"
#include "settings.h"
#include "factory_reset.h"
#include "book_cover_jobs.h"
#include "lock_pin_flow.h"
#include "ui_pinpad.h"
#include "book_lock_collage.h"
#include "book_lock_bookmark.h"
#include "boot_state.h"
#include "ble_page_turner.h"
#include "read_pico_pmu.h"
#include "read_pico_pmu_protocol.h"
#include "read_pico_transfer.h"
#include "esp_log.h"
#include "ttf_font.h"
#include "ui_font.h"
#include "app_font_context.h"
#include "zh_convert.h"
#include "ui_gesture.h"
#include "ui_kit.h"
#include "ui_text_input.h"
#include "ui_keyboard.h"
#include "ui_nav.h"
#include "ui_wallpaper.h"
#include "ui_avatar.h"
#include "ui_home_clock.h"
#include "read_pico_search.h"
#include "book_store.h"
#include "book_cover.h"
#include "ota_update.h"
#include "ota_online.h"
#include "esp_app_desc.h"
#include "esp_attr.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "display.h"
#include "display_main_waveform.h"
#include "e0470_epaper_waveform.h"
#include "pmu_selftest.h"
#include "soc/rtc_cntl_reg.h"

static void fit_value(char *value, int width);
static void settings_card(uint8_t *fb, EpdRect rect, int radius, uint8_t fill, uint8_t edge);
static char s_notice[96];
typedef enum { SETTINGS_MAIN, SETTINGS_WIFI, SETTINGS_TIME,
               SETTINGS_TIME_EDIT, SETTINGS_SHELF_STYLE, SETTINGS_SYSTEM_FONT,
               SETTINGS_SYSTEM_SIZE, SETTINGS_SYSTEM_CONTRAST, SETTINGS_MAIN_REFRESH, SETTINGS_LOCK_STYLE,
               SETTINGS_WALLPAPER, SETTINGS_WALLPAPER_PREVIEW,
               SETTINGS_CONFIG, SETTINGS_UPGRADE, SETTINGS_BOOT, SETTINGS_FACTORY_RESET,
               SETTINGS_POWER_SLEEP, SETTINGS_AUTO_LOCK, SETTINGS_PROFILE, SETTINGS_AVATAR,
               SETTINGS_BLUETOOTH, SETTINGS_BLE_SCAN,
               SETTINGS_LOCK_PIN, SETTINGS_PIN_ENTRY, SETTINGS_TEXT_EDIT,
               SETTINGS_UPGRADE_NOTES, SETTINGS_RAM_DIAG } settings_page_t;
static settings_page_t s_page;
static int settings_content_end(void) {
    return UI_NAV_REFRESH_END;
}
static int settings_viewport_end(void) {
    return UI_NAV_TOP;
}
static void settings_navigation(uint8_t *fb) {
    ui_nav_draw(fb,3);
}
static int settings_nav_hit(uint16_t x,uint16_t y) {
    return ui_nav_hit(x,y);
}

static bool s_reset_confirm, s_reset_pending;
static char s_reset_notice[96];
// 更新说明页：内容比一屏多，按 10 条一页分页显示；字号固定，不跟随系统字号放大溢出卡片。
// Release-notes page: the list is longer than one screen, so paginate 10 rows per page at a
// fixed type size instead of scaling it past the card.
static unsigned s_notes_page;
static const char *const k_upgrade_notes[] = {
    "· 继续修复 EPUB 封面：封面提取的 PSRAM 预留从 2 MB 降到 1 MB（列表路径 1.5 MB→1 MB）、封面解码门槛从 1.5 MB 降到 768 KB，基线 JPEG 解不出时回退 JPEGDEC；1.15.52 时被缓存成自动封面的书会重试（封面缓存版本 +1）",
    "· 新增封面诊断：封面提取/解码失败时在 TF 卡根目录追加 pageisle_cover_diag.log（原因、文件大小、剩余 PSRAM），便于定位仍不显示封面的书",
    "· 页面内存策略 Phase1：离开主页立即归还时钟基准池（约 763 KB）+ 7 张封面 + 文件夹拼图 + 头像缩略图；离开图书应用归还书架封面、书目列表与当前字体字形缓存；离开设置归还壁纸列表与拼贴索引；回到对应页面再按需重建（阅读/主页可用内存更多）",
    "· 其余与 1.15.52 相同：EPUB2 封面识别、内部 SRAM 削峰 + 内存诊断页、文件管理 rc103、书架封面速度/回退修复、水波纹·高清校准、瘦身、液态玻璃书架、WebP/渐进 JPEG",
    "· 降低运行内存占用：把非热路径的静态大块数组搬到 PSRAM（波形裁剪工作区、TTF 字体槽、首页/书架/文件/云界面缓存、显示 LUT 等，共约 80 KiB），内部 SRAM 静态占用从 75.9% 降到约 52%，每个界面都留出 ≥20% 余量（目标：各界面内部 SRAM 占用 <80%）",
    "· 新增「内存诊断」页（设置 → 升级和恢复 → 内存诊断）：显示内部 SRAM/PSRAM 当前占用与启动基线，按峰值列出每个界面的内部 RAM 占用%（超 80% 标 !）；离开界面时写入 TF 卡根目录 pageisle_ram_diag.log",
    "· 搬 PSRAM 后若感觉翻页/设置页文字变慢，可回退 ttf_font 字体槽那一条；其余与 1.15.50 相同",
    "· 修复个别有原生封面的 EPUB 在书架只显示书名占位卡（首页正常）：1.15.47 起的封面提速让渐进式 JPEG 封面先走 JPEGDEC 1/8 快速路径，个别封面 JPEGDEC 解不出时书架退回占位；本版快速路径失败会自动回退 lowzag 完整解码，书本不再丢封面",
    "· 其余与 1.15.49 相同：无封面书籍自动封面跟随系统字体、文件管理跟随 rc103、书架封面速度修复、水波纹·高清校准、瘦身、液态玻璃书架、WebP/渐进 JPEG",
    "· 没有封面的书籍：自动生成的封面标题/作者改用「设置里改过的系统字体」绘制；未选择自定义系统字体时保持内建字形的默认外观",
    "· 切换系统字体后封面缓存会按字体路径自动失效重建一次（自动封面换成新字体；有真实封面的书只是重建一次、外观不变）",
    "· 其余与 1.15.48 相同：文件管理跟随 rc103、书架封面速度修复、水波纹·高清校准、瘦身、液态玻璃书架、WebP/渐进 JPEG",
    "· 文件管理跟随上游 rc103：新增递归搜索（中文/全拼/首字母，增量扫描不卡界面）、列表↔图标网格视图切换、跨页多选与本页全选、批量移动/删除（确认面板、嵌套去重、失败项保留）、按名称/时间/大小升降序排序、目录用途设置（书籍/字体目录）",
    "· 文件根页按 rc103 新布局：存储卡卡面 + 容量条 + 格式化确认，书籍/字体/壁纸分类卡（含递归计数），Wi-Fi/热点/U 盘三入口与底栏操作，浅灰底白卡风格",
    "· 书籍递归统计（数量/体积）与空间统计后台轮询；搜索使用拼音/首字母匹配（复用本机离线搜索表）",
    "· 保留我方本地行为：.md/.markdown 书籍入口、.webp 图片入口、改名/移动时书名覆盖迁移、文件页入页整屏 GC16、分页器按压整块全像素刷新（黑残影修复）",
    "· 其余与 1.15.47 相同：书架封面速度修复（封面恢复 JPEGDEC 快速路径）、水波纹·高清校准实现、瘦身第一批、液态玻璃书架、WebP/渐进 JPEG",
    "· 修复 1.15.45/46 书架封面显示明显变慢：渐进式 JPEG 封面此前改用 lowzag 高清解码（为清晰度逐档探测+整幅选档），在 176×240 封面尺寸上收益很小但耗时明显；本版封面/缩略图恢复 1.15.44 的 JPEGDEC 1/8 快速路径，阅读插图/背景等大图仍用 lowzag 高清解码",
    "· 封面缓存 schema 2→3：升级后首次取封面会重建一次缓存（已是快速解码），之后恢复原来的书架速度",
    "· 修复 1.15.45 水波纹·高清翻页「速度变快、抗锯齿丢失严重」：高清档恢复 1.15.44 的实现——校准 GL16（厂商 E0470_WAVEFORM）+ FULL 标定扫描 + 8 带 44 拍（约 0.49 秒/页），抗锯齿按校准脉宽推准；水波纹·快刷仍是 rc103 的 41 相水波表",
    "· 原因：1.15.45 把高清也换成了 rc103 的「37 相柔和文字序列 + 4 相变白」水波表；文字序列的等灰保持/提前回浅是为文字优化的，不是为抗锯齿中灰校准，真机表现为中灰推不到位（字边变硬）且观感更快",
    "· 显示算法按上游 rc103 调整：普通/图文翻页改为整屏全像素 GL16（37+4=41 相，每页多 4 相擦白）；「普通·快刷」纯文字页仍走速读黑白（原厂 DU20）；周期清理/入书仍是完整 GC16",
    "· 阅读水波纹 37→41 相（多 4 相变白，约 +44ms/页）；设置/列表滚动 37→45 相（+8 相，约 +89ms/次）；错相引擎相数上限 40→45（PSRAM +5KB）",
    "· 新增「液态玻璃书架」样式：设置 → 书架样式 → 液态玻璃书架（三列九本、薄玻璃挡条、细层板；默认仍是亚克力书架，可在设置切换）",
    "· 图片显示跟随 rc103：新增 WebP 封面/插图/阅读背景/锁屏壁纸/文件页支持；渐进式 JPEG 改用 lowzag 完整解码（插图更清晰）；修复插图缩放空灰阶与复位问题",
    "· 瘦身第一批（不砍功能）：内建字体/图标/首页时钟位图 zlib 压缩到 PSRAM、拼音搜索与输入法表压缩后懒加载、TLS 根证书裁剪为常用 CA 子集；镜像约 -424 KiB，OTA 余量约 2.6%→13%",
    "· 注意：用户自建 WebDAV 若使用非常见根证书可能 TLS 失败；对时源 www.baidu.com 不在常用 CA 子集中，会自动回退备用时间源",
    "· 其余保持 1.15.44：自动对时 6 小时周期、标题整块不跨页、插图留白、防褪色、EPUB 目录/字号等均未改",
    "· 自动对时去掉开机后 15 秒的立刻检测：开机后满 6 小时才第一次尝试，之后每 6 小时一次；成功或失败都立即关闭 WiFi",
    "· 已在线（传书/云同步等）时仍每小时校准；深睡/关机不运行；时间由 PMU RTC 继续走时，唤醒后按 6 小时周期继续",
    "· 电量影响：每天最多 4 次、约 2–5mAh；2050mAh 电池约 0.1–0.25%/天",
    "· 自动 WiFi 对时改为每 6 小时一次：开机空闲时用已保存 WiFi 尝试一次联网校时；扫到就校时，扫不到/失败立即关闭 WiFi，6 小时后再试；首次开机 15 秒先试一次；不常驻无线任务",
    "· 深睡/关机时不扫描：同步成功的时间写入 PMU RTC，睡眠期间由 PMU 继续走时，唤醒/开机后 15 秒内自动补一次；不建议为了对时在深睡中定时唤醒（每次唤醒 + WiFi 约多耗 1–2mAh）",
    "· 电量影响：每次约 5–25 秒、约 0.5–1.2mAh，每天最多 4 次 ≈ 2–5mAh；2050mAh 电池约 0.1–0.25%/天",
    "· 新增开机自动对时：开机空闲时每 2 小时用已保存 WiFi 尝试一次联网校时；扫到就校时，扫不到/失败立即关闭 WiFi，2 小时后再试；首次开机 15 秒先试一次；不常驻无线任务",
    "· 已在线（传书/云同步等）时仍每小时校准一次；深睡/关机时不运行，对时只改时间，不动其他设置",
    "· 电量影响：每次尝试约 5–25 秒、WiFi 峰值 250mA 左右（平均约 1mAh/次），每天最多 12 次 ≈ 4–12mAh；2050mAh 电池按待机 30–50mA 估算约 0.2–0.6%/天，可忽略",
    "· 修复改名后首页仍显示旧标题：首页书名改为「用户改名 > 文件名 > 书内元数据」口径，与书架一致；文件在存储卡上改名后首页显示新名字",
    "· 应用内「改名」保存的书名现在书架、首页、阅读页都生效，重启/重扫后不再退回旧名；文件管理器改名/移动时自定义书名随文件一起迁移",
    "· 首页标题缓存加入书名版本号：应用内改名后返回首页自动刷新，不必等待重新扫描",
    "· 修复两行标题被分页拆开：目录只写「第一章」、正文题头拆成「第一章」+「章节标题」两块时，第二块会并入题头一起显示并跳过，不再留在正文里被拆到下一页或重复显示",
    "· 排版不再在连续标题块之间触发 h2 自动分页；多行标题整串作为一个整体参与分页，放不下时整串移到下一页",
    "· 其余保持不变：翻页不刷白/低频整屏 GC16、静置防褪色只推白、插图留白 20/8px、EPUB 二级目录/字号",
    "· 插图上下留白收细：左右保持 20px、上下由 20px 收到 8px，图片略变高（页面插图与整页插图都生效）",
    "· 图片下方与正文的间距由半行收为四分之一行，减少图片下方的空白",
    "· 其余保持不变：翻页不刷白/低频整屏 GC16 清残影、静置防褪色只推白、标题整块不跨页、EPUB 二级目录/h2/字号",
    "· 翻页清残影恢复为 1.15.23 及以前的策略：翻页不再做任何刷白/推白，残影由低频整屏 GC16 清除（阅读每 10 页或停留 10 分钟触发；显示层另有 30 次页级输出/10 分钟兜底）",
    "· 移除 1.15.24–1.15.37 的每页白推/双轮完整复位（不再有每页额外白帧或黑闪）；静置防褪色（只推白）仍保留，负责白底久置发灰",
    "· 其余保持不变：插图留白 20px、标题整块不跨页、EPUB 二级目录/h2 分页/书内字号",
    "· 取消闪黑模式：翻页清残影不再做双轮完整复位，恢复为只对纯白目标像素补白推（8 帧，约 95ms/页），每页不再闪黑两次、翻页速度恢复",
    "· 白底残留墨迹仍会逐步往白推，残影深度清理仍由低频整屏 GC16 复位负责",
    "· 其余保持不变：静置防褪色只推白（修久置灰斑）、插图留白 20px、标题整块不跨页、EPUB 二级目录/h2 分页/书内字号",
    "· 只把「翻页清残影」的代码恢复为 1.15.26 版本：阅读页每页对纯白目标像素做完整 GC16 等灰复位循环连跑两遍（36 帧压黑 + 34 帧白推，约 0.8 秒/页）；代价是每页闪黑两次，这是 1.15.26 的行为",
    "· 其余保持不变：插图留白 20px、标题整块不跨页、EPUB 二级目录缩进/h2 自动分页/书内 CSS 字号、静置防褪色仍为 1.15.34 的只推白版本（1.15.35 的整帧 GL16 改动已撤销）",
    "· 防褪色（刷白）算法按用户要求换回之前的版本：静置约 5 分钟的维护由「只推纯白像素」改回整帧全像素 GL16 重推（白底吃 15→15 白推、黑字回纯黑，不整屏闪）",
    "· 其余保持 1.15.34：插图留白 20px、标题整块不跨页、EPUB 二级目录缩进 / h2 自动分页 / 书内 CSS 字号",
    "· 若长时间放置后仍出现灰色斑块：可用 NVS metalio_hw/antifade_min 调大间隔或设为 0 关闭防褪色后对比",
    "· 阅读页插图四周留白由 32px 收到 20px（整页图/通栏图随之略放大，仍居中、无边框、不挤压下方文字）",
    "· 标题（含两行标题）整块不跨页拆开：标题放不下时整块移到下一页，不再出现标题第一行在上一页、第二行在下一页；h2 自动另起一页保留",
    "· 修复「放置一段时间后屏幕灰色斑块」：浅色防褪色（静置约 5 分钟触发）从整帧全像素 GL16 重推改为只对纯白像素发白推帧，黑字/抗锯齿/中灰不再被反复擦白再压黑；反色模式保留原行为",
    "· EPUB 二级目录：目录页按书内目录层级缩进显示（一级/二级/三级，均可点击跳转）；目录索引缓存版本已升级，首次打开会重建一次目录",
    "· 遇到二级标题（h2）自动另起一页分节（横排/竖排都生效；页面不足 1/3 时不拆，避免只剩标题的空页）",
    "· 按 EPUB 内置格式排版：解析书内 CSS 的 font-size（em/%/px/pt，有界 50–250%）按块缩放字号，配合已有的 text-indent / margin-top / margin-bottom / text-align / font-family 生效；浮动、表格、绝对定位等复杂 CSS 仍不支持",
    "· 修复文件界面「奇怪的黑色多边形」：给界面字形与图标绘制加硬性尺寸校验——损坏/异常的字形位图或异常大的图标请求一律丢弃并回退，不会再在屏幕上涂出巨大黑块（涉及内建界面字体、系统 TTF 字体两套渲染路径与图标绘制）",
    "· 同时包含方案 A：阅读页插图回正文栏（宽度跟随阅读边距、左右天然留白、整页图居中；代价是插图变小、分页可能变化）",
    "· 按方案 A 把阅读页插图从通栏改回正文栏：图片宽度跟随阅读边距、左右天然留白，再叠加 32px 内缩；整页插图在正文栏内水平+垂直居中。代价：插图变小、分页可能变化（重排后页数可能增加），请重点验收翻页位置",
    "· 文件界面修复「奇怪的黑色多边形」：进入文件页做一次整屏 GC16 清残影；分页器按压/松开改成整块 GL16 全像素重推，旧箭头不再留成黑色残影",
    "· 整页插图居中修复：整页插图页在插图带内水平+垂直居中、四周留白 32px，不再贴阅读区顶端或左右边缘（正文字页里的页首插图仍贴阅读区顶端）；插图保持无边框",
    "· 设置里移除「本版变更/更新说明」入口：设置页不再显示版本变更列表",
    "· 阅读页插图不再画边框（按反馈移除）：只调整图片位置和大小——图片在排版原矩形内四周留白 28px、居中等比缩小，大图约缩 8%，下方文字位置/分页不变；整页插图在插图带内垂直居中，不再贴顶",
    "· 同时包含 1.15.27 的修复：阅读页白底推白只发纯白推帧、去掉压黑段，翻页不再每页闪黑两次",
    "· 阅读页插图留白再加大：在排版原矩形内先留 12px 边框外留白、边框内再留 20px 图片留白（四周合计约 34px），盒内先铺回页面底色；整页插图改为在插图带内垂直居中，边框不再贴屏幕/题头顶部（修复上一版反馈的「图片没有缩小、上边和左右顶着」）",
    "· 同时包含 1.15.27 的修复：阅读页白底推白只发纯白推帧、去掉压黑段，翻页不再每页闪黑两次",
    "· 修复阅读页每次翻页整屏闪黑两次的问题（1.15.24–1.15.26 的白底「压黑→白饱和」复位在真机上就是每页两次黑闪）：白底推白改为只发纯白推帧、完全去掉压黑段，白底本来就白、视觉上不再闪；残影的彻底清理仍由低频整屏 GC16 负责",
    "· 阅读页插图四周留白由 10px 增大到 22px（图片在边框内更居中、留白更明显），边框 2px，仍不改行高与下方文字位置",
    "· 阅读页白底修复力度加强（用户反馈「推白力度不够」）：每次浅色翻页后的白底复位循环由 1 遍改为 2 遍（36 帧压黑 + 34 帧白推，仍黑白对称），对纯白区域推白/清残影更彻底；黑字、抗锯齿边、插图仍不驱动；代价是每次翻页约多 0.8 秒",
    "· 阅读页插图新增边框：图片在排版原矩形内四周留白后居中显示（2px 边线），下方文字位置与分页不变；反色模式下边框保持界面墨色、插图本身仍保留原灰阶",
    "· 阅读页浅色翻页新增「白底修复」：每次翻页后只对白色区域做一遍平衡的「压黑→白饱和」复位循环（完整 GC16 的等灰白序列，18 压黑+17 白推，约 +0.4 秒/页），把白底残留的上一页黑色文字/图案真正擦掉；黑字、抗锯齿边缘、插图不是纯白目标，完全不驱动，翻页与抗锯齿算法不变；反色模式不做",
    "· 配合 1.15.23 的清理策略（阅读默认每 10 页/满 10 分钟真 GC16、进入主页内容区 GC16、显示层 30 页/10 分钟兜底）进一步减少浅色残影；若翻页变慢或白底出现发灰/发亮，请反馈",
    "· 修复浅色模式下主页与阅读「本应是白色的地方残留上一屏黑色文字/图案」的残影：浅色刷新以差分为主、不清白底残影；阅读周期整屏全刷默认 15→10 页并增加「距上次整屏 GC16 满 10 分钟」时间触发（慢读/久停也清），进入主页首帧做一次 48 相 GC16 内容区复位，显示层再加「每 30 次页级输出或 10 分钟」真 GC16 兜底",
    "· 撤销 1.15.22 两处过驱动（浅色活动期全像素 GL16 重推、面板层 AA 修复全像素定稿），保留深→浅首帧擦白与静置防泛白；反色/深色路径（逐页压黑、深色 GC16 复位、LUT 保持）零改动",
    "· 修复浅色模式阅读/主页「用一段时间后淡墨」：显示层新增活动期低频全像素重推（约每 10 页或 5 分钟一次，无整屏白闪；每第 5 次升级整屏 GC16），并加固深色退出后浅色首帧擦白复位",
    "· 修复书架删不了书：删除范围与书架收录范围对齐（书根多级目录、卡内任意位置的 TXT/EPUB/Markdown），路径逐段校验防越界；文件已删但进度清理失败时条目立即从书架消失并自动补清进度",
    "· 修复部分书不进首页「最近阅读」：进度记录新增/云同步写回/改名迁移后立即补进最近阅读列表，首页停留期间后台进度变化也会自动刷新",
    "· 修复 WiFi/热点传书不可用：热点就绪改为等待系统 AP_START 事件（10 秒超时提示），启动失败给出可读原因与「重试 WiFi 传书 / 重试热点传书」，起服务前回收可重建缓存",
    "· 修复蓝牙翻页器搜索失败/「内存不足」：内存临时不足不再计入跨重启自锁，改为 2 秒短退避自动重试；扫描页显示启动原因并每秒重试；开启蓝牙前回收字形/表盘缓存，提示补全内部/PSRAM 数字",
    "· 修复阅读工具栏二级设置后正文锯齿：界面文字抗锯齿改为绘制期覆盖（不再受正文开关影响），面板层切换用 AA 修复表重驱动中灰边缘（纯黑/纯白保持、无闪白），缩进微调改完整 GL16 定稿",
    "· 深睡唤醒恢复显示小锁界面：唤醒时不再恢复上一次锁屏缓存（可能是一张壁纸），与冷启动统一先显示小锁面，醒来第一眼就是小锁",
    "· 修复 1.15.19 反色模式完全崩坏：深灰裁剪把背景压黑动作清零过多，进入深色后背景停在浅色、文字不可见；本版恢复之前的反黑算法（整屏 GC16 复位 + 8 帧压黑），深色恢复纯黑底",
    "· 图文书籍/带阅读背景图的书：反色翻页后也做逐页压黑清残影（之前这类页面被跳过）",
    "· 深色退出后浅色淡墨：切回浅色的第一帧先整屏擦白、再用 GC16 重写页面，清掉深色期间积累的残余电荷",
    "· 恢复深色模式逐页压黑（用户要求保留：没有压黑深色模式无法阅读）：竖屏/横屏/水波纹翻页后都补一次压黑；压黑目标改为深灰（逻辑 15 只驱动前 3 帧、不推到纯黑），降低过驱动",
    "· 深色整屏全刷仍为真正的 GC16 复位（临时关闭深色保持），到页周期清理/进书/手动全刷都做一次擦白+压黑复位；翻页压黑保证可读，周期 GC16 清残影",
    "· 修复浅色状态淡墨：深色背景不再推到纯黑（深灰）、深色退出时整屏 GC16 复位，避免残余电荷带到浅色模式导致淡墨",
    "· 深色模式整屏全刷改为真正的 GC16：手动整屏全刷、到页周期清理、进书/回正文时临时关闭LUT 深色保持，整屏走一次擦白+压黑复位，清残影并恢复墨色；不再只用压黑补扫",
    "· 修复深色模式残影越翻越多、墨色变淡：取消逐页/横屏/防泛白的压黑补扫，改为周期 GC16复位；退出深色模式时自动整屏刷新，避免回到浅色后淡墨",
    "· 反色模式横屏阅读也自动去残影：横屏翻页后补一遍压黑清理（竖屏条带路径在横屏不适用，旧版横屏翻页从不压黑）；阅读页整页刷新（全屏切换/章节跳转/换字体等）在反色下也补压黑",
    "· 反色模式阅读工具栏的二级/三级菜单（阅读设置、字体/背景选择、统计、章节跳转、按键/手势选择、背景预览等）每次打开、返回或切换后补一遍压黑清理，菜单边缘与回到正文后的残影不再残留",
    "· 反色模式设置界面与二级页面：整页切换、设置列表滚动停下后同样补压黑清理，设置里翻页/滚动不再留残影；浅色模式不变",
    "· 进入四个小游戏时先做一次整屏全刷（浅色=GC16，反色=黑闪整屏清理），入口页残影先清干净再开局，浅色/反色都生效",
    "· 修复小游戏分数/状态旧字迹被新字叠一层的 bug：贪吃蛇/五子棋/俄罗斯方块的状态行重画前先清整行白底（2048 已有），分数位数变化或文案换字后旧字迹不再残留",
    "· 反色模式主页/书架等几个主界面左右滑动后追加压黑清理：每次滑动完成补一遍满幅压黑（无白闪），主页残影不再越滑越重；浅色模式保持原样",
    "· 修复反色模式「到页不自动全刷、左半边残影清不掉、主页残影更重」：上一版为消除反色白闪，整屏 GC16 不再驱动深色底；补偿用的压黑补扫是固件里唯一的整屏 FAST 差分路径，真机供数欠载时只扫完前半段（反色映射后正好是逻辑左半），图文页与主页周期清理还漏了补扫。本版改 FULL 标定扫描 + 127 行预填并补齐缺失的清理点，压黑覆盖整屏",
    "· 反色模式到页周期清理与手动整屏全刷改为「黑闪整屏清理」：屏幕先短暂压黑再按全黑基准重绘，能彻底重推深色底残影且不出现白光（浅色模式不变）；清理失败保留到下一次重试",
    "· 修复「用着用着界面文字整片消失」：字形位图分配失败时旧代码会把空字形缓存起来、之后永不重试，内存恢复后文字仍空白，只能重启；现在失败不缓存、清缓存重试一次、必要时用内部内存兜底，整段一个字都没画出时自动换另一种字体重画，并记录诊断到 TF 卡根目录 pageisle_font_diag.log",
    "· 坚果云：进入联网任务前回收字形/表盘等可重建缓存并检查 PSRAM 余量（与 OTA 同级），降低云任务峰值（约 545KB）把内存吃紧、导致界面缺字的概率",
    "· 坚果云阅读进度同步：本机进度快照上限 64→96，同步超过 64 本时不再漏快照，避免云端较旧进度静默覆盖本机较新进度",
    "· 修复深色（反色）模式白闪：反色下整屏 GL16/GC16 会先把深色等灰对擦白再压回，每轮约 122ms 白闪；现在 1k LUT 正确保持逻辑 8–15 等灰对（物理黑底）、只驱动真正变化的像素。普通/快刷/水波纹快刷/水波纹高清翻页、进书与整屏刷新均生效",
    "· 翻页末尾补黑重做：改用只对物理黑底推 8 帧压黑、不碰字形/抗锯齿/白字的独立相位表（FAST 扫描约 56ms），不再改写 back 差分基准；进书/阅读周期清理/小游戏周期清理后追加压黑清理，黑底浅色残影不再累积",
    "· 防泛白与反色：静置满 5 分钟不再整屏白推（反色下改为深色等灰保持的全像素 GL16 + 压黑清理），不会每 5 分钟白闪一次；2048/贪吃蛇/五子棋/俄罗斯方块反色下周期清理不再整屏 GC16，分数/最高分/状态行旧字迹不再叠层（浅色模式不变）",
    "· 水波纹·高清提速：条带 32→8、节拍 12ms→11090us，动画约 0.82s→0.49s（和「水波纹·快刷」一样快）；扫描仍是 FULL 标定档、GL16 波形与每像素 37 相不变，抗锯齿质量不降，只是揭页前沿的台阶从 32 级变成 8 级",
    "· 修复深色（反色）模式水波纹翻页中间的白闪：反色时整页背景在物理上是深色，旧逻辑仍按 GL16 等灰对（15→15 白推 / 0→0 擦推）重推整片背景，导致明显白闪；现在反色下等灰像素保持不动、只驱动真正变化的像素，快速档与高清档都生效",
    "· 修复「透明书封/壁纸预览上下滑动换图直接重启」：预览缓存的灰度与 alpha 其实共用同一块 PSRAM（alpha = 灰度 + 像素数），旧代码把两个指针都当独立分配 free，切换图片或退出预览时把内部指针交给堆管理器，触发堆断言 restart。现在只释放一次；崩溃重启后界面会先回到内建字体（异常启动进入恢复模式），再重启一次即恢复所选字体——并非字体丢失",
    "· 流畅性：断电拆成两段——撤 VCOM/ON_OFF 后约 500ms 放电等待不再占显示锁，主循环/翻页/OTA 不用再等这 500ms；放电窗口内若有新翻页，先按正常顺序拉低 EN 再完整上电，绝不切断正在使用的轨",
    "· 自查修正：显示/OTA 递归锁改为开机即创建（此前只有进过升级页才创建，平时这把锁等于空操作）；防泛白白推忽略待处理的整屏全刷请求，久置到点不会再变成整屏黑白闪；去掉每个空闲周期一条 INFO 日志与一个未使用变量",
    "· 流畅性：整轨断电改到低优先级任务执行（含约 500ms 放电等待），主循环不再阻塞、不吞轻点/拖慢长按；强光防反黑仍是实验项（默认关闭，NVS sun_fix=1 才开启）：600ms 提前断电在连续翻页时会变成每页多一次上下电，需真机 A/B 后再定默认",
    "· 自查修正：①断电任务与睡眠/关机路径现在用显示锁串行，避免两路同时写 SY7636A；②强光防反黑不再默认开启（原默认开启会让连续翻页每页多一次电源循环，反而拖慢）；③去掉每个空闲周期一条 INFO 日志",
    "· 缓解「阅读页/票根锁屏久置发黑/泛白」：①防泛白链路接通——静置满间隔（默认 5 分钟，输入重新计时）用全像素 GL16 白推当前帧：未变化白底补 1 帧 15→15 白推，深色/中灰会短暂变浅后回到原灰阶，无整屏黑白全刷；票根锁屏浅睡与长睡唤醒也按间隔白推。②强光防反黑默认关闭：刷屏后高压轨约 600ms 断电（原来保留 8 秒），触摸/菜单/USB/OTA 时走 8 秒兜底；开启方式 NVS sun_fix=1",
    "· 修复「阅读页/票根锁屏久置发黑」：此前防褪色模块没编进固件，静态画面白底会慢慢发灰变暗；现在把它接通，并且不靠整屏全刷——静置满间隔（默认 5 分钟，输入重新计时）用全像素 GL16 重推当前帧：白底吃 GL16 的 15→15 白推、黑字回纯黑，不压黑、不整屏闪；票根锁屏浅睡与长睡唤醒也按间隔白推。若觉得重推太频繁/太少，可用 NVS metalio_hw/antifade_min 改成 0/3/10/30 分钟",
    "· 水波纹·高清抗锯齿再加强：改用普通·高清的校准 GL16 表 + FULL 标定扫描（11090us/帧）；rc100 的 FAST 扫描帧只有约 7ms、脉宽约标定的 63%，抗锯齿中灰推不到位，字体边缘才粗糙。现在每相脉宽回到校准值，字边更细，动画仍约 0.82s（68 拍/12ms），单次推屏不追加第二遍",
    "· 水波纹·高清抗锯齿加强：揭页条带 8→最多 32、动画 44→68 拍（12ms/拍，约 0.53s→0.82s），用更长动画换更细的揭页前沿；抗锯齿仍在动画内完成（单次推屏、结束提交基准，不追加第二遍），快刷档不变",
    "· 修复坚果云「同步阅读进度」闪退：云同步任务栈 8KB→12KB；进度同步路径栈占用约 3.3KB→1.3KB（新设备探测改单缓冲逐个 stat）；合并结果按本机+云端实际条数分配并逐条边界校验（旧版超过 96 条会写越界）",
    "· 修复「PNG 图片有时候无法预览」：解码器改为按文件内容识别 PNG/JPEG，不再信扩展名——手机/微信/QQ/下载站常把 JPEG 存成 .png（或 PNG 存成 .jpg），复制到 TF 卡后透明书封/阅读背景会报「无法预览」或「解码失败」",
    "· 透明书封与锁屏支持这类扩展名不符的图片（JPEG 按不透明层自动去白）；隔行（Adam7）PNG 补齐透明书封/图片页解码；PNG 坏 CRC/尾部缺失时按可用数据解码",
    "· 排版设置新增「上下边距」滑杆：0–48 像素、6 像素一档，竖排/横排/横屏都按新边距即时重排；抽屉加高，五条滑杆一页排满",
    "· 修复 2048 分数残影叠加：分数/最高分/状态行改为先清底再写字，位数变短或文案切换时不再与旧像素叠加",
    "· 白天翻页补白暂时停用（真机反馈：定向补白会让上一页字迹比背景更白）；白天清残影回到 rc100 差分翻页 + 周期整屏清理，反色补黑不变",
    "· 小游戏去闪屏：2048/五子棋/贪吃蛇/俄罗斯方块每步改差分局部刷新，不再每步整屏闪",
    "· 小游戏加清残影：2048/五子棋每 10 步、方块每 12 块、贪吃蛇每 20 步做一次整屏 GC16，吃食物不再整屏闪",
    "· 深睡唤醒不再阻塞等 TF 卡挂载：立即恢复缓存帧保留原锁屏，最多 500ms 窗口；PIN 开机等待 3s→1s",
    "· 卡慢/无卡时按清白+锁屏兜底继续开机，不再卡在启动画面",
    "· 时钟样式预览缓存（rc100）：浏览页固定 10:10:30 预览、5 槽 LRU、空闲预绘邻近样式",
    "· 字体/字号/对比度/繁简变化与恢复配置后预览自动失效，切换样式更跟手",
    "· 新增插图缩放（rc100 版）：双击整页插图定点 2 倍/还原，双击正文插图进入 2 倍缩放",
    "· 缩放中双指捏合 1–4 倍、单指拖动平移，松手整屏灰阶定稿；翻页/切面板/锁屏自动复位（本期竖屏）",
    "· 水波纹·高清改用 rc100 翻页抗锯齿算法（reader 文字灰阶波形），与快刷档只差节拍，其后仍补白",
    "· 阅读设置面板整体上移、卡片恢复原尺寸：十个功能一页排满（竖屏五行双列/横屏五列两行）",
    "· 修复阅读背景 PNG「无法导入/无法预览」：PNG 解码前回到文件起点，此前只读了文件头就解码导致全部失败",
    "· SD 卡健康检查与自动恢复：后台只读巡检 + 拔卡防抖，掉线后按 1/3/10/30 秒退避自动重挂",
    "· 自动重挂前先停封面/头像/云同步/阅读句柄；挂载交接期间不再打开旧卡文件",
    "· 本章跳转升级：草稿页码 + 数字键盘直接输入，跳转后 7 秒内可「返回跳转前」",
    "· 翻页清残影恢复「补白」：rc100 差分 GL16 翻页后紧跟一遍纯白底补扫，只推白底不动字形",
    "· 竖排（从右到左）与自适应方向不再互斥：横屏也能正常竖排，转屏自动重排整章",
    "· 阅读设置新增「阅读背景」，一页十个功能排满：三级菜单选图 + 透明书封同款自动去白",
    "· 修复透明书封「能选不能预览」：预览改用小块缓存，不再需要整屏画布与超大内存",
    "· 透明书封/背景预览按路径+大小+时间复用缓存，来回切换不重复解码，翻页更快",
    "· 书内字体反复回退时提示「立即重启 / 暂不重启」，重启前自动保存阅读进度",
    "· 锁屏缓存、拼贴书封、透明书封缓存改为 FAT 安全替换；透明书封改用行压缩格式",
    "· 联网 OTA 开启交叉签名证书校验（需真机联网确认）",
    "· 白天清残影整体换成 rc100 算法：普通翻页差分 GL16，去掉整幅补扫与第二遍补齐",
    "· 反色模式的补黑与相关路径保持原样（用户要求只换白天算法）",
    "· 坚果云同步新增「同步阅读进度」：换设备可续读，两边都改过时保留本机",
    "· 修复单击开机 / 单击解锁按了还要再按；深睡唤醒保留锁屏缓存帧标记",
    "· 修复连续 DU 刷新失败丢待驱动相位；阅读票根锁屏纯白不再被二次抖动成灰点",
    "· 普通·快刷改用 rc100 速读黑白：正文阈值纯黑白 + 原厂 DU 一次推屏，翻页更快",
    "· 修复阅读背景 PNG 无法预览：支持隔行 PNG，背景直写 4bpp 省 832KB 内存",
    "· 阅读背景解码失败按原因提示：格式不支持 / 尺寸过大 / 内存不足 / 文件损坏",
    "· 横屏阅读补齐状态栏、题头（返回/书名/收藏）与章节页码进度带",
    "· 横竖屏切换回到同一段文字页首；横屏时钟局刷只刷状态带，不再整屏闪",
    "· 清残影提速：翻页第一遍改用整幅 GL16，大部分残影当场清掉",
    "· 流畅性满配：全组件 -O3、热点循环展开、字形缓存 1.5MB、预渲染更深",
    "· 清残影回到翻页内立即补白（深色补黑）：修复退出阅读后菜单与锁屏残影",
    "· 清残影回到最早那版：翻页后补一次白（深色补黑），两侧残影更干净",
    "· 长按划线 / 目录开关移到底部工具栏「划线」页右上角",
    "· 新增坚果云同步：设置→连接与时间→坚果云同步，浏览云盘与下载图书",
    "· 同步页支持子目录、进度、取消与重名覆盖确认，下载后自动上书架",
    "· 新增 Markdown 阅读：标题分级、粗体斜体高亮、管道表格与自动目录",
    "· Obsidian 互通：导出划线笔记为 Markdown，推回坚果云同步文件夹",
    "· 新增手势设置：双击/长按/四向滑动/双指轻点可绑定动作",
    "· 手势含经典/上下翻页/单手/极简四套推荐；经典与旧版行为一致",
    "· 系统更名为「页屿 PageIsle」，版本与分区表仍为 0.3.3-rc99",
    "· 字级划线：长按选中当前字，滑动逐字增长，跨行跨段",
    "· 图文书的下一页插图提前加载，翻到插图页直接显示",
    "· 反色模式新增夜间自动：21:00–07:00 自动切换",
    "· 极简时钟锁屏：两行显示，每分钟局刷、每 20 分钟全刷",
    "· 横屏阅读章节首页恢复显示章名",
    "· 书架、打开图书与预渲染流畅度优化",
    "· 繁简两态显示、状态栏签名、锁屏样式等既有功能",
    "· 繁体模式字形改用 Noto Sans TC 的 TC 风格",
    "· 书架新增搜索：按二级书架过滤，最近阅读优先",
    "· 自定义系统字体应用到工具栏、二三级设置和其他界面",
    "· 首页今日阅读分钟移到头像右侧，去掉中间空档",
    "· 划线标签：点标签循环 重要/待读/疑问，随书保存",
    "· 书架空闲预取相邻页封面，翻页更快出图",
    "· 划线列表长按一条记录可写/改笔记，笔记随书保存",
    "· 书签标签：点标签循环 重要/待读/疑问，随书保存",
    "· 深色模式翻页后只补纯黑底像素，字形与边缘不动",
    "· 繁简转换按词选形：发→髮/發、面→麵/面、干→乾/幹/干 等",
    "· 修复书架搜索按钮被二级菜单抢走；书架点按局部重绘",
    "· 长按已划线句子可直接删除该段划线；划线列表排版修正",
    "· USB 读卡页也使用自定义系统字体（字库与字形缓存保持加载）",
    "· 锁屏两行时钟行距收紧，整体居中",
    "· 修复时间锁屏开机困难：深睡唤醒不再等第二次按键",
    "· 更新说明页改为分页显示，长列表不再溢出卡片",
    "· 修复锁屏分钟刷新白框切到小时下缘；开机困难加固（三处按键检查、深睡唤醒不等键）",
    "· 深色普通·快刷/高清翻页恢复去残影，改用短 DU 掩码补黑，不再整屏闪白",
    "· 普通·快刷翻页改 DU 差分提速（牺牲少量抗锯齿）；水波纹后补黑与动画衔接更紧",
    "· 划线跳转后底部新增“返回前阅读位置”；阅读状态栏跟随系统字体",
    "· 个性化功能新增“开机按键”单击/双击切换；锁屏签名/日期字号 +4px",
    "· 普通·快刷撤回 DU 翻页、恢复 GL16 擦除，修复整页残影",
    "· 阅读统计新增章节内自由跳转：− / + 切页，中间显示 x/x 页",
    "· 主页时钟样式切换预览只刷表盘区并走短 DU，切换更跟手",
    "· 插图双击放大：单指拖动平移、双指上下缩放、双击返回原页",
    "· 底部导航改为 5 栏：首页 / 特色功能 / 书架 / 文件 / 设置",
    "· 特色功能入口页：2×4 卡片 + 固件自绘图标，长按中键返回",
    "· 「做个决定」：投币、正/反结果与翻面过渡",
    "· 首页右下模块三态：日历 / 待办 / 本月统计，长按循环并记住",
    "· 首页待办显示完成进度，完成项压灰，超过 6 条提示剩余数量",
    "· 番茄时钟：25/5 预设、开始/暂停/重置，到点整页提醒并响铃",
    "· 周闹钟：周一到周日多选、时/分可调，锁屏/深睡到点唤醒提醒",
    "· 小游戏：2048、贪吃蛇、俄罗斯方块、五子棋（简单/困难 AI）",
    "· 待办事项页：手机键盘新增/编辑/删除/勾选，与首页共用",
    "· 插图缩放修正：双指分开放大、合拢缩小、单指拖动",
    "· 翻页推屏期间继续采样触摸，底栏点击立即生效",
};
#define UPGRADE_NOTES_PER_PAGE 10
static int upgrade_notes_pages(void) {
    const int count = (int)(sizeof(k_upgrade_notes) / sizeof(k_upgrade_notes[0]));
    return (count + UPGRADE_NOTES_PER_PAGE - 1) / UPGRADE_NOTES_PER_PAGE;
}
static ui_pinpad_t s_pinpad;
static lock_pin_flow_t s_pinflow;
static bool s_pin_pending;
static unsigned s_pin_failures;
static int64_t s_pin_retry_at;
static void pin_setup_close(void) {
    ui_pinpad_end(&s_pinpad); lock_pin_flow_end(&s_pinflow); s_pin_pending = false;
}
static void pin_setup_open(app_ctx_t *ctx, bool disable) {
    pin_setup_close(); lock_pin_flow_begin(&s_pinflow, disable);
    ui_pinpad_begin(&s_pinpad, ctx->fb, lock_pin_flow_title(&s_pinflow));
    s_pinpad.navigation=true;
    s_page = SETTINGS_PIN_ENTRY;
}
static app_redraw_t pin_paint(app_ctx_t *ctx, EpdRect area) {
    ui_pinpad_paint(ctx->fb, &s_pinpad, area);
    guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, area));
    return APP_REDRAW_DONE;
}
static app_redraw_t pin_setup_tick(app_ctx_t *ctx) {
    if (s_pinpad.blocked && ctx->now_ms >= s_pin_retry_at) {
        ui_pinpad_reset(&s_pinpad, NULL, "请重新输入");
        return pin_paint(ctx, ui_pinpad_entry_area());
    }
    if (!s_pin_pending) return APP_REDRAW_NONE;
    s_pin_pending = false;
    lock_pin_step_t prior = s_pinflow.step;
    esp_err_t error = lock_pin_flow_input(&s_pinflow, s_pinpad.digits);
    if (error == ESP_OK && s_pinflow.step == PIN_FLOW_DONE) {
        pin_setup_close(); s_page = SETTINGS_LOCK_PIN;
        snprintf(s_notice, sizeof(s_notice), "%s", lock_pin_enabled() ? "锁屏密码已保存" : "锁屏密码已关闭");
        return APP_REDRAW_PAGE;
    }
    const char *notice = error == ESP_OK ? "" : error == ESP_ERR_INVALID_RESPONSE ? "两次输入不同，请重设" :
        error == ESP_ERR_INVALID_ARG ? "原密码不正确，请重试" : "保存失败，请重试";
    ui_pinpad_reset(&s_pinpad, lock_pin_flow_title(&s_pinflow), notice);
    if (error == ESP_ERR_INVALID_ARG && prior == PIN_FLOW_OLD && ++s_pin_failures >= 3) {
        s_pin_failures = 0; s_pin_retry_at = ctx->now_ms + 10000;
        snprintf(s_pinpad.notice, sizeof(s_pinpad.notice), "请等待 10 秒后重试"); s_pinpad.blocked = true;
    }
    return pin_paint(ctx, (EpdRect){122, 218, 440, 247});
}
static int s_style_scroll, s_main_scroll;
// 新样式使用新编号；旧3/4仍退回亚克力，列表保持5。/ New style gets a new ID; retired3/4 still fall back to acrylic and list remains5.
static const uint8_t s_shelf_style_ids[] = {1, 2, 6, 5};
#define SHELF_STYLE_CHOICES 4
static bool s_collage_prepare_pending;
static bool s_scroll_drag_consumed, s_scroll_present_pending;
// 蓝牙翻页器子页：滚动位置、正在学习哪个动作（0 未学，1 上一页，2 下一页）、提示行。
// 扫描页另记上次尝试开始扫描的时刻：栈异步启动或被连接占用时按节拍重试。
// Bluetooth sub-page: scroll offset, which action is being learned (0 idle, 1 prev, 2 next),
// and a notice line. The scan page also remembers when it last tried to start scanning, so it can
// retry on a cadence while the stack starts asynchronously or a link is being torn down.
static int s_ble_scroll, s_ble_learning;
static char s_ble_notice[64];
static char s_ble_feedback[64];
static uint32_t s_ble_scan_retry_ms;
static int s_font_page, s_wallpaper_page;
// 空闲预热状态：字体目录与图片列表在设置主页静止时读入缓存，子页进入时不再同步扫卡。
// Idle warm-up state: the font catalogue and the picture list are cached while the settings root
// sits still, so their sub-pages never scan the card on entry.
static bool s_font_catalog_warmed;
static bool s_media_warm_done;
static bool s_wallpaper_list_png;
static int64_t s_warm_idle_ms = -1;
static bool s_sync_pending;
static bool s_font_sync_confirm;
static char s_font_sync_path[TTF_FONT_PATH_MAX];
static bool s_config_confirm;
// 屏幕修复：点一下就开始。整屏盲刷要几秒，活儿交给 tick——不能在触摸回调里做。
// Panel repair: one tap starts it. The blind full-screen drive takes seconds, so the work goes to the
// tick rather than a touch callback.
static bool s_panel_repair_pending;
static bool s_boot_pending;
static bool s_upgrade_confirm, s_upgrade_online, s_local_pending, s_upgrade_restart;
static pico_ota_info_t s_local_update;
static EXT_RAM_BSS_ATTR pico_update_status_t s_update;
static char s_upgrade_notice[96];
static uint32_t s_update_drawn_percent, s_update_drawn_at;
static pico_update_state_t s_update_drawn_state;
static bool s_update_drawn_busy, s_upgrade_offer_pending;
typedef enum { UPGRADE_JOB_NONE, UPGRADE_JOB_CHECK, UPGRADE_JOB_DOWNLOAD } upgrade_job_t;
static upgrade_job_t s_upgrade_job;
static int s_upgrade_bar_width;
static uint32_t upgrade_percent(void) {
    uint32_t percent = s_update.release.size ? (uint64_t)s_update.received * 100 / s_update.release.size : 0;
    return percent > 100 ? 100 : percent;
}
static void upgrade_remember(uint32_t now) {
    s_update_drawn_state = s_update.state;
    s_update_drawn_busy = s_update.busy;
    s_update_drawn_percent = upgrade_percent();
    s_update_drawn_at = now;
}
// 结果等任务收尾后一次显示；进度只在五秒且增长五个百分点后补画新增像素。
// Show results once after worker cleanup; append progress after five seconds and five percentage points.
static app_redraw_t upgrade_status_redraw(uint32_t now) {
    bool downloading = s_update.state == PICO_UPDATE_DOWNLOADING;
    if (s_update.busy && s_update.state != PICO_UPDATE_CHECKING && !downloading)
        return APP_REDRAW_NONE;
    bool offer = s_upgrade_offer_pending && !s_update.busy && s_update.state == PICO_UPDATE_AVAILABLE;
    if (offer) {
        s_upgrade_offer_pending = false;
        s_upgrade_confirm = s_upgrade_online = true;
    } else if (!s_update.busy) s_upgrade_offer_pending = false;
    if (offer || s_update.state != s_update_drawn_state || s_update.busy != s_update_drawn_busy) {
        upgrade_remember(now);
        return APP_REDRAW_PAGE;
    }
    uint32_t percent = upgrade_percent();
    if (downloading && percent >= s_update_drawn_percent + 5 && now - s_update_drawn_at >= 5000) {
        upgrade_remember(now);
        return APP_REDRAW_AREA;
    }
    return APP_REDRAW_NONE;
}
static EpdRect upgrade_progress_area(void) { return (EpdRect){52, 468, 580, 64}; }
static void draw_upgrade_percent(uint8_t *fb) {
    uint32_t percent = upgrade_percent();
    EpdRect number = {496, 472, 132, 42};
    ui_fill_rect_fast(number, UI_GRAY_WHITE, fb);
    char progress[32]; snprintf(progress, sizeof(progress), "%lu%%", (unsigned long)percent);
    ui_text_fixed(fb, 624, 477, 26, progress, EPD_DRAW_ALIGN_RIGHT, false);
    ui_image_bw_rect(fb, number);
}
static void draw_upgrade_progress(uint8_t *fb) {
    ui_fill_rect_fast(upgrade_progress_area(), UI_GRAY_WHITE, fb);
    draw_upgrade_percent(fb);
    ui_fill_rect_fast((EpdRect){60, 518, 564, 10}, UI_GRAY_BLACK, fb);
    ui_fill_rect_fast((EpdRect){61, 519, 562, 8}, UI_GRAY_WHITE, fb);
    s_upgrade_bar_width = (int)(562 * upgrade_percent() / 100);
    if (s_upgrade_bar_width)
        ui_fill_rect_fast((EpdRect){61, 519, s_upgrade_bar_width, 8}, UI_GRAY_BLACK, fb);
}
static void draw_upgrade_progress_delta(uint8_t *fb) {
    int width = (int)(562 * upgrade_percent() / 100);
    if (width <= s_upgrade_bar_width) return;
    draw_upgrade_percent(fb);
    ui_fill_rect_fast((EpdRect){61 + s_upgrade_bar_width, 519, width - s_upgrade_bar_width, 8}, UI_GRAY_BLACK, fb);
    s_upgrade_bar_width = width;
}
// 排队时只改 UI 快照；本次画面推送结束后的 tick 才启动 TLS/擦写。
// Scheduling changes only the UI snapshot; start TLS/flash on the tick after its presentation.
static void upgrade_schedule(bool downloading, uint32_t now) {
    s_upgrade_job = downloading ? UPGRADE_JOB_DOWNLOAD : UPGRADE_JOB_CHECK;
    s_update.state = downloading ? PICO_UPDATE_DOWNLOADING : PICO_UPDATE_CHECKING;
    s_update.busy = true;
    s_update.received = 0;
    snprintf(s_update.message, sizeof(s_update.message), "%s", downloading
        ? "正在下载，短暂断网会自动重连" : "正在连接并检查更新");
    s_upgrade_offer_pending = !downloading;
    upgrade_remember(now);
}
static app_redraw_t upgrade_start_pending(void) {
    bool downloading = s_upgrade_job == UPGRADE_JOB_DOWNLOAD;
    s_upgrade_job = UPGRADE_JOB_NONE;
    app_home_cover_mode_changed();
    app_book_cover_mode_changed();
    // 联网检查/下载前归还可重建的 PSRAM 缓存：所有槽位的字形缓存合计最大 1.5 MB、
    // 首页表盘池最大 763,632 B，这两块平时一直常驻，OTA 的 512 KB PSRAM 门槛在它们
    // 占用后就可能误判；开书前也是这么整块归还字形的，之后按需重建，不影响界面。
    // Return rebuildable PSRAM caches before the online check: the glyph caches of all slots
    // add up to 1.5 MB and Home's clock pool is up to 763,632 B; both stay resident and can
    // trip the OTA 512 KB PSRAM floor. Opening a book clears glyphs the same way; both rebuild
    // on demand, so the UI is unaffected.
    (void)ttf_font_cache_clear_all();
    // 内建界面字形位图（最多 512KB）同样可重建，一并归还给 OTA 的大块内存需求。
    // The built-in UI glyph bitmaps (up to 512 KiB) are rebuildable too; return them for OTA's
    // large contiguous allocations as well.
    ui_font_cache_clear();
    app_home_release_clock_cache();
    esp_err_t error = downloading ? pico_online_download() : pico_online_check();
    pico_online_get_status(&s_update);
    if (error == ESP_OK) return APP_REDRAW_NONE;
    s_upgrade_offer_pending = false;
    s_update.busy = false;
    if (s_update.state != PICO_UPDATE_FAILED) s_update.message[0] = 0;
    s_update.state = PICO_UPDATE_FAILED;
    if (!s_update.message[0]) snprintf(s_update.message, sizeof(s_update.message), "无法开始升级，请退出传书后重试");
    snprintf(s_upgrade_notice, sizeof(s_upgrade_notice), "%s", s_update.message);
    return APP_REDRAW_PAGE;
}
// 日志按 UTF-8 字符和实际字宽换行，限制六行，不影响下载时的局部刷新。
// Wrap notes on UTF-8 boundaries using measured widths; cap at six lines without changing download refreshes.
static bool upgrade_note_line(const char **cursor, char *line, size_t capacity) {
    if (!cursor || !*cursor || !line || capacity < 5) return false;
    const char *p = *cursor;
    while (*p && (strchr("\r\n\t ;", *p) || !strncmp(p, "；", 3)))
        p += !strncmp(p, "；", 3) ? 3 : 1;
    size_t used = 0;
    line[0] = 0;
    while (*p && !strchr("\r\n;", *p) && strncmp(p, "；", 3)) {
        unsigned char lead = (unsigned char)*p;
        size_t bytes = lead < 0x80 ? 1 : lead < 0xe0 ? 2 : lead < 0xf0 ? 3 : 4;
        if (bytes > strlen(p) || used + bytes >= capacity) break;
        memcpy(line + used, p, bytes);
        line[used + bytes] = 0;
        if (used && ui_text_fixed_width_px(26, line) > 540) { line[used] = 0; break; }
        used += bytes;
        p += bytes;
    }
    *cursor = p;
    return used != 0;
}
static void draw_upgrade_notes(uint8_t *fb) {
    const char *cursor = s_update.release.notes;
    char line[sizeof(s_update.release.notes)];
    if (!*cursor) {
        ui_text_fixed(fb, 60, 530, 26, "本次更新暂无说明", EPD_DRAW_ALIGN_LEFT, false);
        return;
    }
    for (int row = 0; row < 6 && upgrade_note_line(&cursor, line, sizeof(line)); ++row) {
        if (row == 5 && *cursor) {
            size_t used = strlen(line);
            while (used && (used + 4 > sizeof(line) || ui_text_fixed_width_px(26, line) > 514)) {
                do { --used; } while (used && ((unsigned char)line[used] & 0xc0) == 0x80);
                line[used] = 0;
            }
            memcpy(line + used, "…", 4);
        }
        ui_text_fixed(fb, 60, 530 + row * 38, 26, line, EPD_DRAW_ALIGN_LEFT, false);
    }
}
static EpdRect upgrade_confirm_button(bool online, bool accept) {
    return (EpdRect){accept ? 364 : 60, online ? 842 : 613, 260, 64};
}
static void upgrade_open(void) {
    (void)pico_ota_inspect(PICO_OTA_UPDATE_PATH, &s_local_update);
    pico_online_get_status(&s_update);
    s_upgrade_confirm = s_local_pending = s_upgrade_restart = false;
    s_upgrade_offer_pending = false;
    s_upgrade_job = UPGRADE_JOB_NONE;
    s_upgrade_bar_width = 0;
    upgrade_remember(esp_timer_get_time() / 1000);
    s_upgrade_notice[0] = 0;
    s_page = SETTINGS_UPGRADE;
}
static const char *const TAG = "device_settings";
// 主设置始终单行；大字号只改变字形，字体预览单独保留足够空间。
// Main rows never stack; larger glyphs share one centerline, with extra space only in font previews.
static bool settings_stacked(void) { return app_settings_system_font_size() >= 150; }
static int settings_profile_height(void) { return 106; }
static int settings_main_row_height(void) {
    return 82;
}
#define SETTINGS_ROW_H settings_main_row_height()
#define SETTINGS_WIRELESS_ROWS 4
#define SETTINGS_DISPLAY_ROWS 8
#define SETTINGS_PERSONAL_ROWS 5
#define SETTINGS_MAINTENANCE_ROWS 6
#define SETTINGS_WIRELESS_Y (180 + settings_profile_height() + 77)
#define SETTINGS_DISPLAY_Y (SETTINGS_WIRELESS_Y + SETTINGS_WIRELESS_ROWS * SETTINGS_ROW_H + 78)
#define SETTINGS_PERSONAL_Y (SETTINGS_DISPLAY_Y + SETTINGS_DISPLAY_ROWS * SETTINGS_ROW_H + 78)
#define SETTINGS_MAINTENANCE_Y (SETTINGS_PERSONAL_Y + SETTINGS_PERSONAL_ROWS * SETTINGS_ROW_H + 78)
// 设置行图标：32 像素盒，在行高 68 里垂直居中；墨色统一，避免一行一个灰度。
// Setting row icons: a 32 px box centred in the 68 px row with one shared ink level.
#define SETTINGS_ICON_PX 32
#define SETTINGS_ICON_INK 0x58
// 主页面滚动上限：把最后一组的最后一行刚好推到导航栏之上，多留 8px 余量。
// Main-page scroll limit: just enough to bring the last row of the last group above the nav bar,
// with 8 px to spare.
#define SETTINGS_SCROLL_MAX \
    (SETTINGS_MAINTENANCE_Y + SETTINGS_MAINTENANCE_ROWS * SETTINGS_ROW_H - UI_NAV_REFRESH_END + 12)
static char s_editor[96], s_editor_notice[80];
static ui_text_edit_t s_editor_input;
static bool s_editor_signature;
static const char *system_font_label(const char *path) {
    if (!path || !path[0]) return "思源黑体";
    const char *name = strrchr(path, '/');
    name = name ? name + 1 : path;
    static char stem[TTF_FONT_NAME_MAX];
    snprintf(stem, sizeof(stem), "%s", name);
    size_t len = strlen(stem);
    if (len >= 4 && !strcasecmp(stem + len - 4, ".ttf")) stem[len - 4] = 0;
    if (!strcasecmp(stem, "Hei")) return "思源黑体（TF 卡）";
    return ttf_font_localized_name(stem);
}
// 设置页只显示当前脚本，具体转换在绘制层统一完成。
// The settings row only reports the active script; conversion itself happens in the draw layer.
static const char *zh_mode_value(app_zh_mode_t mode) {
    return mode == APP_ZH_TRADITIONAL ? "繁体" : "简体";
}
typedef struct {
    EpdRect size, preview;
    int preview_title, font_title, first, row_height, slots;
} system_font_layout_t;
static system_font_layout_t system_font_layout(void) {
    system_font_layout_t l = settings_stacked()
        ? (system_font_layout_t){{36,197,612,183},{36,471,612,216},413,722,785,142,2}
        : (system_font_layout_t){{36,197,612,100},{36,379,612,154},322,560,615,99,4};
    l.slots=(settings_viewport_end()-42-l.first)/l.row_height;
    return l;
}
static EpdRect system_font_item_rect(int slot) {
    system_font_layout_t l = system_font_layout();
    return (EpdRect){36,l.first + slot * l.row_height,612,l.row_height - 16};
}
// 系统字体页统一按「内建 + 卡上字体」计数分页：渲染、命中和滑动翻页共用同一份页数，
// 字体目录扩到 50 条后边界不会差一页。
// The system font page paginates over built-in plus card faces; paint, hit-test and swipe paging
// share one page count so the boundary stays exact now that the catalogue can hold 50 faces.
static int system_font_items(void) { return ttf_font_count() + 1; }
static int system_font_pages(int slots) {
    if (slots < 1) return 1;
    const int items = system_font_items();
    return (items + slots - 1) / slots;
}
static void system_font_clamp_page(int slots) {
    const int pages = system_font_pages(slots);
    if (s_font_page < 0) s_font_page = 0;
    if (s_font_page >= pages) s_font_page = pages - 1;
}
static EpdRect system_font_sync_button(bool sync) { return (EpdRect){sync ? 351 : 72,683,261,74}; }
static void draw_system_font_sync(uint8_t *fb) {
    // 仅一个有界弹窗，不额外打开阅读字体。/ One bounded dialog; never load the reading face here.
    settings_card(fb,(EpdRect){48,389,588,401},28,UI_GRAY_WHITE,0x58);
    ui_text_fixed_vc(fb,342,448,32,"同步到阅读字体？",EPD_DRAW_ALIGN_CENTER,false);
    char name[80]; snprintf(name,sizeof(name),"已选择「%s」",system_font_label(s_font_sync_path));
    while (ui_text_fixed_width_px(27,name) > 520 && strlen(name) > 6) {
        size_t n = strlen(name) - 1;
        while (n && ((unsigned char)name[n] & 0xc0) == 0x80) --n;
        name[n] = 0;
    }
    ui_text_fixed_vc(fb,342,516,27,name,EPD_DRAW_ALIGN_CENTER,false);
    ui_text_fixed_vc(fb,342,570,24,"是否让阅读正文也使用这个字体？",EPD_DRAW_ALIGN_CENTER,false);
    ui_text_fixed_vc(fb,342,614,23,s_notice[0]?s_notice:"不同步时，保留原来的阅读字体。",EPD_DRAW_ALIGN_CENTER,false);
    for (int i=0;i<2;++i) {
        EpdRect r=system_font_sync_button(i);
        settings_card(fb,r,20,i ? UI_GRAY_BLACK : UI_GRAY_WHITE,0x58);
        ui_text_fixed_vc(fb,r.x+r.width/2,r.y+r.height/2,25,i ? "同步阅读字体" : "仅系统字体",EPD_DRAW_ALIGN_CENTER,i);
    }
}
static int s_year, s_month, s_day, s_hour, s_minute;
#define WALLPAPER_MAX 64
typedef struct { char path[288]; char name[96]; } wallpaper_item_t;
// 壁纸列表放 PSRAM，理由同上。
// The wallpaper list lives in PSRAM for the same reason.
static wallpaper_item_t *s_wallpapers;

static bool wallpapers_alloc(void) {
    if (!s_wallpapers)
        s_wallpapers = heap_caps_calloc(WALLPAPER_MAX, sizeof(wallpaper_item_t),
                                        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    return s_wallpapers != NULL;
}
static int s_wallpaper_count;
static int s_wallpaper_selected;
static bool s_wallpaper_confirm, s_wallpaper_preview_ok;
static bool s_bookmark_picker;

static void wallpaper_scan_dir(const char *root) {
    if (!wallpapers_alloc()) return;
    DIR *dir = opendir(root);
    if (!dir) return;
    struct dirent *entry;
    while (s_wallpaper_count < WALLPAPER_MAX && (entry = readdir(dir))) {
        if (entry->d_name[0] == '.' || !strncmp(entry->d_name, "._", 2)) continue;
        const char *ext = strrchr(entry->d_name, '.');
        if (!ext || (strcasecmp(ext, ".jpg") && strcasecmp(ext, ".jpeg") && strcasecmp(ext, ".png"))) continue;
        if(s_bookmark_picker && strcasecmp(ext,".png"))continue;
        wallpaper_item_t *item = &s_wallpapers[s_wallpaper_count];
        if (snprintf(item->path, sizeof(item->path), "%s/%s", root, entry->d_name) >= sizeof(item->path)) continue;
        struct stat st;
        if (stat(item->path, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0 || (uint64_t)st.st_size > BOOK_IMAGE_FILE_MAX) continue;
        size_t name_len = strnlen(entry->d_name, sizeof(item->name) - 1);
        memcpy(item->name, entry->d_name, name_len);
        item->name[name_len] = 0;
        ++s_wallpaper_count;
    }
    closedir(dir);
}
static void bookmark_preview_release(void) {
    book_lock_bookmark_preview_release();
}
// 预览只缓存目标框大小的 PNG 层（透明书封同款自动去白），不再复制整屏画布：
// 之前整屏缓存需要约 2.4~3.9 MB 空闲 PSRAM，图片能选中却经常无法预览，这里彻底去掉该门槛。
// The preview caches only the PNG layer at the target box size (same auto white removal as the
// transparent cover) instead of a full-frame canvas: the old full-frame cache needed 2.4-3.9 MB of
// free PSRAM, which is why a picked PNG often could not be previewed at all.
static void bookmark_preview_prepare(const uint8_t *background) {
    (void)background;
    if(!s_bookmark_picker || s_wallpaper_selected<0 || s_wallpaper_selected>=s_wallpaper_count){
        book_lock_bookmark_preview_release();
        return;
    }
    const EpdRect image = {166, 194, 352, 626};
    (void)book_lock_bookmark_preview_build(s_wallpapers[s_wallpaper_selected].path,
                                           (unsigned)image.width, (unsigned)image.height);
}
static void wallpaper_scan(void) {
    s_wallpaper_count = s_wallpaper_page = 0;
    wallpaper_scan_dir("/sdcard/pictures");
    wallpaper_scan_dir("/sdcard/images");
    wallpaper_scan_dir("/sdcard");
}
// 只在列表为空或筛选类型变化时扫盘：设置主页空闲预热后，头像/壁纸页进入即用缓存。
// Scan only when the list is empty or the filter kind changed: after the settings root prewarms
// the list, the avatar and wallpaper pages open straight from the cache.
static void wallpaper_ensure(bool png_only) {
    s_bookmark_picker = png_only;
    s_wallpaper_page = 0;
    if (s_wallpaper_count > 0 && s_wallpaper_list_png == png_only) return;
    wallpaper_scan();
    s_wallpaper_list_png = png_only;
}


static void profile_editor_open(bool signature) {
    s_editor_signature = signature;
    snprintf(s_editor, sizeof(s_editor), "%s", signature ? app_settings_status_signature() : app_settings_device_name());
    ui_text_edit_init(&s_editor_input, s_editor, sizeof(s_editor));
    s_editor_notice[0] = 0;
    ui_keyboard_begin(&s_editor_input, false);
    s_page = SETTINGS_TEXT_EDIT;
}




static int days_in_month(int year, int month) {
    static const int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (month == 2 && (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0))) return 29;
    return days[month - 1];
}

// 公历日期转 UTC 天数；界面统一按北京时间 UTC+8 编辑。
// Convert a Gregorian date to UTC days; the editor uses Beijing time (UTC+8).
static int64_t civil_days(int year, int month, int day) {
    year -= month <= 2;
    int era = year / 400;
    int yoe = year - era * 400;
    int doy = (153 * (month + (month > 2 ? -3 : 9)) + 2) / 5 + day - 1;
    int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return (int64_t)era * 146097 + doe - 719468;
}

static void time_open(void) {
    time_t now = time(NULL);
    if (now < 1704067200) {
        const pmu_snapshot_t *pmu = read_pico_pmu_get();
        if (pmu && pmu->time_synced && pmu->unix_sec >= 1704067200) now = pmu->unix_sec;
    }
    if (now < 1704067200) {
        char month[4] = "Jan"; int day = 1, year = 2024;
        if (sscanf(__DATE__, "%3s %d %d", month, &day, &year) != 3) {
            strcpy(month, "Jan"); day = 1; year = 2024;
        }
        static const char *const months[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        int m = 1; while (m < 12 && strcmp(month, months[m - 1])) ++m;
        s_year = year; s_month = m; s_day = day; s_hour = s_minute = 0;
    } else {
        struct tm date;
        time_t local = now + 8 * 3600;
        gmtime_r(&local, &date);
        s_year = date.tm_year + 1900; s_month = date.tm_mon + 1; s_day = date.tm_mday;
        s_hour = date.tm_hour; s_minute = date.tm_min;
    }
    s_notice[0] = 0;
    s_page = SETTINGS_TIME_EDIT;
}

static void time_adjust(int field, int step) {
    if (field == 0) s_year = s_year + step > 2099 ? 2024 : s_year + step < 2024 ? 2099 : s_year + step;
    if (field == 1) s_month = s_month + step > 12 ? 1 : s_month + step < 1 ? 12 : s_month + step;
    if (field == 2) s_day = s_day + step > days_in_month(s_year, s_month) ? 1 :
                            s_day + step < 1 ? days_in_month(s_year, s_month) : s_day + step;
    if (field == 3) s_hour = (s_hour + step + 24) % 24;
    if (field == 4) s_minute = (s_minute + step + 60) % 60;
    if (s_day > days_in_month(s_year, s_month)) s_day = days_in_month(s_year, s_month);
}

static bool time_save(void) {
    int64_t epoch = civil_days(s_year, s_month, s_day) * 86400 +
                    s_hour * 3600 + s_minute * 60 - 8 * 3600;
    if (epoch < 1704067200 || epoch > 4102444799LL) return false;
    struct timeval tv = {.tv_sec = (time_t)epoch, .tv_usec = 0};
    if (settimeofday(&tv, NULL)) return false;
    uint8_t payload[4] = {(uint8_t)epoch, (uint8_t)(epoch >> 8),
                          (uint8_t)(epoch >> 16), (uint8_t)(epoch >> 24)};
    esp_err_t err = read_pico_pmu_cmd(PMU_CMD_TIME_SYNC, payload, sizeof(payload));
    if (err == ESP_OK) err = read_pico_pmu_cmd(PMU_CMD_TIME_GET, NULL, 0);
    const pmu_snapshot_t *pmu = read_pico_pmu_get();
    if (err != ESP_OK || !pmu || !pmu->time_synced) {
        snprintf(s_notice, sizeof(s_notice), "系统时间已设置，PMU 同步失败");
        return false;
    }
    snprintf(s_notice, sizeof(s_notice), "时间已保存，并同步到电源管理芯片");
    s_page = SETTINGS_TIME;
    return true;
}

static void settings_card(uint8_t *fb, EpdRect rect, int radius, uint8_t fill, uint8_t edge) {
    ui_fill_round_rect(fb, rect, radius, fill);
    ui_draw_control_frame(fb, rect, radius, edge);
}
static void settings_divider(uint8_t *fb, int y, int x, int width) {
    ui_draw_separator(fb, y, x, width, 0x60);
}
static void settings_value(uint8_t *fb,int x,int cy,int px,const char *value) {
    char shown[128]; snprintf(shown,sizeof(shown),"%s",value);
    size_t n=strlen(shown);
    bool arrow=n>=3 && !strcmp(shown+n-3,"›");
    if (arrow) {
        shown[n-=3]=0;
        while (n && shown[n-1]==' ') shown[--n]=0;
        ui_draw_icon(fb,x-4,cy,26,UI_ICON_CHEVRON_RIGHT,UI_GRAY_BLACK);
    }
    ui_text_vc(fb,x-(arrow?28:0),cy,px,shown,EPD_DRAW_ALIGN_RIGHT,false);
}
static void row(uint8_t *fb, int y, const char *label, const char *value) {
    ui_text(fb, 54, y + 17, 27, label, EPD_DRAW_ALIGN_LEFT, false);
    settings_value(fb,627,y+20+ui_text_effective_px(21)/2,21,value);
    settings_divider(fb, y + 68, 54, 575);
}
static void section(uint8_t *fb, int y, const char *title) {
    ui_text(fb, 40, y, 22, title, EPD_DRAW_ALIGN_LEFT, false);
}

/* ---- 蓝牙翻页器子页的版式 / Layout of the Bluetooth sub-page ---- */

// 行高比 setting_group 的 68 略大，因为这一页每行右侧常常要放一个按钮。
// Rows are a little taller than setting_group's 68 because these rows often carry a button.
#define BLE_ROW_H 84
// 按钮右缘与 row() 的值右缘对齐；值文字右端再让出按钮宽度，两者不重叠。
// The button's right edge aligns with row()'s value edge; the value text then stops short of the
// button, so the two never overlap.
#define BLE_BTN_W 118
#define BLE_BTN_RIGHT 624
#define BLE_VALUE_RIGHT (BLE_BTN_RIGHT - BLE_BTN_W - 17)

// 渲染和命中测试都调这个函数，两边看到的是同一份坐标——否则会出现「按钮画在这儿、
// 点在别处」，这一页之前就是这么坏的。
// Rendering and hit testing both call this, so they see identical coordinates. Without it a
// control ends up drawn in one place and tapped in another, which is exactly how this page was
// broken before.
typedef struct {
    int toggle_top;                  // 开关卡片顶；-1 表示被学习提示取代 / switch card top, -1 when the learn prompt replaces it
    int status_top;
    int notice_top;                  // -1 表示没有提示 / -1 when absent
    int bonds_title_top;
    int bond_top[BLE_PT_MAX_BONDS];  // 已配对行顶；-1 表示该位不存在 / bonded row tops, -1 when absent
    int bond_rows;
    int scan_entry_top;              // 「扫描设备 ›」入口行顶 / the "scan devices" entry row
    int learn_title_top;
    int learn_top[2];
    int footer_top;
    int content_bottom;              // 内容底，用于滚动上限 / content bottom, for the scroll limit
} ble_layout_t;

static ble_layout_t ble_layout(void) {
    ble_layout_t l;
    memset(&l, 0, sizeof(l));
    int y = 202 - s_ble_scroll;
    l.toggle_top = s_ble_learning || s_ble_feedback[0] ? -1 : y;
    y += 126 + 38;
    l.status_top = y;
    y += BLE_ROW_H + 20;
    l.notice_top = s_ble_notice[0] ? y : -1;
    if (s_ble_notice[0]) y += 38;
    l.bonds_title_top = y;
    y += 38;
    l.bond_rows = (int)ble_pt_bond_count();
    for (int i = 0; i < BLE_PT_MAX_BONDS; ++i)
        l.bond_top[i] = i < l.bond_rows ? y + i * BLE_ROW_H : -1;
    y += (l.bond_rows ? l.bond_rows : 1) * BLE_ROW_H;
    l.scan_entry_top = y + 16;
    y = l.scan_entry_top + BLE_ROW_H + 30;
    l.learn_title_top = y;
    l.learn_top[0] = y + 38;
    l.learn_top[1] = l.learn_top[0] + BLE_ROW_H;
    l.footer_top = l.learn_top[1] + BLE_ROW_H + 25;
    l.content_bottom = l.footer_top + 66;
    return l;
}

// 一行的左标签 + 让出按钮后的右值，外加分隔线。与 row() 同高，但右端不会压到按钮。
// A row's left label plus a right value that stops short of the button, with the usual divider.
// Same height as row(), but the value never runs under the button.
// 学到的键按整帧显示：帧里非零的字节照原样列出来。同一个键每次按下发的字节一样，所以这串
// 标识每次都一样；不同的键只要有一个字节不同，读出来就不同。
// A learned key shows its whole frame: the non-zero bytes, in order. The same key sends the same
// bytes every press, so this identifier never changes, and two keys that differ in any byte read
// differently.
static void format_bound_key(const ble_pt_frame_t *frame, char *out, size_t size) {
    if (!frame || !frame->len) {
        if (size) out[0] = 0;
        return;
    }
    size_t used = 0;
    unsigned shown = 0;
    for (size_t i = 0; i < frame->len && used + 4 < size; ++i) {
        if (!frame->bytes[i]) continue;
        if (shown == 3) {  // 值列只有 140px：最多列 3 个字节，多的用 + 表示 / the value column holds three
            snprintf(out + used, size - used, " +");
            return;
        }
        const int written = snprintf(out + used, size - used, shown ? " %02X" : "%02X", frame->bytes[i]);
        if (written <= 0) break;
        used += (size_t)written;
        ++shown;
    }
    if (!shown) snprintf(out, size, "00");  // 理论上到不了：全零帧不给绑 / unreachable: a zero frame is never bound
}

static void ble_row(uint8_t *fb, int y, const char *label, const char *value) {
    if (y + BLE_ROW_H < 190 || y >= settings_viewport_end()) return;
    settings_card(fb, (EpdRect){36, y, 612, BLE_ROW_H - 8}, 18, UI_GRAY_WHITE, 0x70);
    char name[96]; snprintf(name, sizeof(name), "%s", label);
    fit_value(name, 290);
    ui_text_vc(fb, 60, y + 38, 26, name, EPD_DRAW_ALIGN_LEFT, false);
    if (value && value[0]) {
        char shown[96]; snprintf(shown, sizeof(shown), "%s", value); fit_value(shown, 140);
        settings_value(fb,BLE_VALUE_RIGHT,y+38,21,shown);
    }
}

// 行右侧的按钮。竖直居中于该行，右缘与值文字对齐。
// The button on a row's right: vertically centred in the row, right edge aligned with the value.
static EpdRect ble_button_rect(int row_top) {
    return (EpdRect){BLE_BTN_RIGHT - BLE_BTN_W, row_top + 10, BLE_BTN_W, 56};
}

// 三级页：进页即持续扫描，选中一台连上就退回二级页。列表长了也不影响二级页。
// Third-level page: scanning starts on entry and runs continuously; picking a device connects
// and returns to level two. A long list never affects the page above it.
typedef struct {
    int devices_top;
    int device_rows;
    int status_top;
    int content_bottom;
} ble_scan_layout_t;

// 扫描列表只列真的广播了名字的设备。没有广播名时组件把地址回落成名字，那一行对用户
// 认不出是什么设备，而且地址太长会把信号强度挤掉。
// The scan list shows only devices that actually advertised a name. Without one the component
// falls back to the address: nothing the user can recognise, and long enough to crowd the signal
// strength off the row.
static bool ble_scan_visible(const ble_pt_device_t *dev) {
    return dev != NULL && dev->has_name;
}

static int ble_scan_visible_count(void) {
    int visible = 0;
    const uint8_t count = ble_pt_device_count();
    for (uint8_t i = 0; i < count; ++i) {
        if (ble_scan_visible(ble_pt_device(i))) ++visible;
    }
    return visible;
}

// 取第 row 台有名字的设备；遍历顺序仍是组件的原始顺序。
// The row-th device that has a name; the walk keeps the component's order.
static const ble_pt_device_t *ble_scan_visible_at(int row) {
    if (row < 0) return NULL;
    const uint8_t count = ble_pt_device_count();
    int seen = 0;
    for (uint8_t i = 0; i < count; ++i) {
        const ble_pt_device_t *dev = ble_pt_device(i);
        if (!ble_scan_visible(dev)) continue;
        if (seen++ == row) return dev;
    }
    return NULL;
}

static ble_scan_layout_t ble_scan_layout(void) {
    ble_scan_layout_t l;
    memset(&l, 0, sizeof(l));
    l.status_top = 200;
    l.devices_top = 300;
    l.device_rows = ble_scan_visible_count();
    l.content_bottom = l.devices_top + (l.device_rows ? l.device_rows * BLE_ROW_H : 68) + 40;
    return l;
}
static void back_header(uint8_t *fb, const char *title) {
    ui_nav_back(fb, 36, 79);
    ui_text_vc(fb, 342, 107, 34, title, EPD_DRAW_ALIGN_CENTER, false);
    settings_divider(fb, 174, 36, 612);
}

static void setting_icon(uint8_t *fb, int index, int cx, int cy) {
    // 每个设置项对应一个 Lucide 图标；索引顺序由各分组传入的 icons[] 数组决定。
    // One Lucide icon per setting row; the index order comes from each group's icons[] array.
    static const ui_icon_t icons[] = {
        UI_ICON_WIFI,              // 0 无线连接
        UI_ICON_BLUETOOTH,         // 1 蓝牙
        UI_ICON_TYPE,              // 2 系统字体、阅读操作
        UI_ICON_A_LARGE_SMALL,     // 3 系统字号
        UI_ICON_LIBRARY_BIG,       // 4 书架样式
        UI_ICON_TICKET,            // 5 锁屏样式
        UI_ICON_CLOCK,             // 6 日期与时间
        UI_ICON_CONTRAST,          // 7 系统对比度
        UI_ICON_COPY,              // 8 保存与恢复
        UI_ICON_POWER,             // 9 关机睡眠
        UI_ICON_TEXT_ALIGN_START,  // 10 状态栏签名
        UI_ICON_REFRESH_CW,        // 11 首页强刷
        UI_ICON_DOWNLOAD,          // 12 系统升级
        UI_ICON_CPU,               // 13 BOOT 刷机
        UI_ICON_EYE_CLOSED,        // 14 自动休眠
        UI_ICON_SLIDERS_HORIZONTAL, // 15 主页刷新模式 / Main refresh mode
        UI_ICON_LOCK,              // 16 锁屏密码 / lock screen password
        UI_ICON_ROTATE_CW,         // 17 屏幕修复 / panel repair
        UI_ICON_ZAP,               // 18 反色模式 / inverted display
        UI_ICON_TYPE,              // 19 中文显示 / Traditional-Simplified display
        UI_ICON_RADIO_TOWER,       // 20 坚果云同步 / Jianguoyun sync
        UI_ICON_CHART_COLUMN,      // 21 内存诊断 / RAM diagnostics
    };
    if (index < 0 || index >= (int)(sizeof(icons) / sizeof(icons[0]))) return;
    ui_draw_icon(fb, cx, cy, SETTINGS_ICON_PX, icons[index], SETTINGS_ICON_INK);
}

static void settings_fit_text(char *value, int px, int width) {
    while (value[0] && ui_text_fixed_width_px(ui_text_effective_px(px),value)>width) {
        size_t n=strlen(value)-1;while(n&&((unsigned char)value[n]&0xc0)==0x80)--n;value[n]=0;
    }
}
static void fit_value(char *value, int width) { settings_fit_text(value,20,width); }

static void setting_group(uint8_t *fb, int title_y, const char *title,
                          int card_y, const int icons[], const char *const labels[],
                          const char *const values[], int count) {
    const int row_height = SETTINGS_ROW_H;
    title_y -= s_main_scroll;
    card_y -= s_main_scroll;
    // 屏外的行不测字、不生成字形；保留卡片边界与原滚动坐标。
    // Skip off-screen glyph work while preserving card boundaries and scroll coordinates.
    if (card_y + count * row_height <= 160 || title_y >= settings_viewport_end()) return;
    if (title_y + ui_text_effective_px(20) > 160 && title_y < settings_viewport_end())
        ui_text(fb, 42, title_y, 20, title, EPD_DRAW_ALIGN_LEFT, false);
    settings_card(fb, (EpdRect){36, card_y, 612, count * row_height}, 22,
                  UI_GRAY_WHITE, 0x70);
    for (int i = 0; i < count; ++i) {
        int y = card_y + i * row_height;
        if (y + row_height <= 160 || y >= settings_viewport_end()) continue;
        if (i) settings_divider(fb, y, 88, 544);
        setting_icon(fb, icons[i], 67, y + row_height / 2);
        char shown[128]; snprintf(shown,sizeof(shown),"%s",values[i]);
        int value_width = 594 - 100 - 20 - ui_text_fixed_width_px(ui_text_effective_px(25),labels[i]);
        if (value_width > 215) value_width = 215;
        if (value_width < 0) value_width = 0;
        fit_value(shown,value_width);
        ui_text_vc(fb,100,y+row_height/2,25,labels[i],EPD_DRAW_ALIGN_LEFT,false);
        ui_text_vc(fb,594,y+row_height/2,20,shown,EPD_DRAW_ALIGN_RIGHT,false);
        // 导航是图标，不依赖用户字体是否包含 › 字形，也不会被截短掉。
        // Navigation is an icon, independent of the font cmap and value truncation.
        ui_draw_icon(fb,625,y+row_height/2,26,UI_ICON_CHEVRON_RIGHT,UI_GRAY_BLACK);
    }
}

static void setting_toggle(uint8_t *fb, int y, const char *title, const char *detail, bool active) {
    settings_card(fb, (EpdRect){36, y, 612, 126}, 22, UI_GRAY_WHITE, 0x70);
    ui_text(fb, 59, y + 24, 27, title, EPD_DRAW_ALIGN_LEFT, false);
    ui_text(fb, 59, y + 75, 19, detail, EPD_DRAW_ALIGN_LEFT, false);
    EpdRect track = {555, y + 43, 69, 39};
    ui_fill_round_rect(fb, track, 19, active ? 0x58 : 0xc4);
    int cx = active ? track.x + 49 : track.x + 20;
    epd_fill_circle(cx, track.y + 19, 16, UI_GRAY_WHITE, fb);
    epd_draw_circle(cx, track.y + 19, 16, 0x78, fb);
}

static void draw_style_thumbnail(uint8_t *fb, int style, int top) {
    if (top < 242 || top + 170 >= settings_viewport_end()) return;
    if (style == 5) {
        ui_fill_round_rect(fb, (EpdRect){68,top,548,170}, 12, UI_GRAY_WHITE);
        for (int i=0;i<3;++i) {
            int y=top+9+i*52;
            ui_fill_rect_fast((EpdRect){86,y,31,43},i==1?0x80:0x40,fb);
            ui_fill_rect_fast((EpdRect){137,y+6,218,3},0,fb);
            ui_fill_rect_fast((EpdRect){137,y+19,84,2},0x70,fb);
            ui_fill_rect_fast((EpdRect){137,y+34,435,4},0xd0,fb);
            ui_fill_rect_fast((EpdRect){137,y+34,120+i*75,4},0x40,fb);
        }
        return;
    }
    const int left = 99;
    for (int i = 0; i < 3; ++i) {
        int x = left + 20 + i * 155;
        EpdRect cover = {x, top, 116, 145};
        ui_fill_rect_fast(cover, i == 1 ? 0x60 : i == 2 ? 0xa0 : 0x40, fb);
        ui_draw_round_rect(fb, cover, 1, 0x30);
        ui_draw_round_rect(fb, (EpdRect){x + 7, top + 7, 102, 130}, 1, i == 1 ? 0xc0 : 0xe0);
        ui_hairline(fb, top + 47, x + 28, 60, i == 1 ? 0xc0 : 0xe0);
        ui_hairline(fb, top + 54, x + 39, 38, i == 1 ? 0xc0 : 0xe0);
        ui_hairline(fb, top + 111, x + 44, 28, i == 1 ? 0xc0 : 0xe0);
    }
    if (style == 1) {
        ui_fill_rect_fast((EpdRect){left, top + 143, 486, 16}, 0x30, fb);
        ui_hairline(fb, top + 143, left, 486, 0x80);
    } else if (style == 2) {
        ui_draw_acrylic_guard(fb, (EpdRect){left, top + 94, 486, 70});

    } else if (style == 6) {
        // 液态玻璃书架缩略图：直接调用真实挡条函数，预览与书架一致。
        // Liquid glass thumbnail calls the real rail routine so the preview matches the shelf.
        ui_draw_liquid_shelf_rail(fb, (EpdRect){left, top + 126, 486, 36});
    }
}

// 仅 82x82 灰阶头像，不缓存整屏或第二份字库；文件变更/拔卡会使缓存失效。
// One 82x82 gray avatar, never a full frame or second font; file changes/removal invalidate it.
static EXT_RAM_BSS_ATTR uint8_t s_avatar_pixels[82*82];
static char s_avatar_path[288];
static bool s_avatar_ready, s_avatar_pending;
static char s_main_wifi[33];
static bool s_main_wifi_saved;
static void render_content(app_ctx_t *ctx, uint8_t *fb) {
    (void)ctx;
    if (s_page == SETTINGS_PIN_ENTRY) { ui_pinpad_paint(fb, &s_pinpad, ui_pinpad_full()); return; }
    ui_clear_page(fb);
    if (s_page == SETTINGS_FACTORY_RESET) {
        ui_nav_status(fb);
        back_header(fb,"恢复出厂设置");
        ui_text_box(fb,(EpdRect){54,260,576,170},26,
            "重置系统偏好、资料卡、WiFi、蓝牙配对和锁屏密码。",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_box(fb,(EpdRect){54,450,576,170},23,
            "保留书籍、字体、图片、阅读记录和硬件校准。",EPD_DRAW_ALIGN_LEFT,false);
        if(s_reset_confirm)ui_text_box(fb,(EpdRect){54,645,576,80},23,"确认后将恢复默认设置并重启。",EPD_DRAW_ALIGN_LEFT,false);
        if(s_reset_notice[0])ui_text_box(fb,(EpdRect){54,735,576,90},21,s_reset_notice,EPD_DRAW_ALIGN_LEFT,false);
        ui_draw_button(fb,(EpdRect){54,850,576,78},s_reset_pending?"正在恢复…":s_reset_confirm?"确认恢复并重启":"恢复出厂设置",true);
        ui_draw_button(fb,(EpdRect){54,950,576,78},"取消",false);
        settings_navigation(fb);return;
    }

    // 保留 ui_clear_page 的白底，灰阶只由头像、卡片与字形生成。
    // Keep ui_clear_page's white background; avatars, cards and glyphs alone generate grays.
    ui_nav_status(fb);
    if (s_page == SETTINGS_LOCK_PIN) {
        back_header(fb, "锁屏密码");
        row(fb, 266, "四位数字密码", !lock_pin_available() ? "暂不可用" : lock_pin_enabled() ? "已开启" : "已关闭");
        if (!lock_pin_available()) ui_text_vc(fb, 342, 408, 24, "锁屏设置暂不可用", EPD_DRAW_ALIGN_CENTER, false);
        else if (lock_pin_enabled()) {
            row(fb, 406, "修改密码", "验证原密码  ›");
            row(fb, 512, "关闭密码", "验证原密码  ›");
        } else row(fb, 406, "开启密码", "设置四位密码  ›");
        if (s_notice[0]) ui_text_vc(fb, 342, 680, 23, s_notice, EPD_DRAW_ALIGN_CENTER, false);
        ui_text_vc(fb, 342, 752, 21, "修改和关闭密码需验证原密码", EPD_DRAW_ALIGN_CENTER, false);
        settings_navigation(fb); return;
    }
    if (s_page == SETTINGS_PROFILE) {
        back_header(fb, "个人资料");
        ui_text(fb, 42, 214, 21, "自定义名称与头像", EPD_DRAW_ALIGN_LEFT, false);
        row(fb, 266, "设备名称", app_settings_device_name());
        row(fb, 366, "更换头像", app_settings_avatar_path()[0] ? "已选择图片  ›" : "默认图标  ›");
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_AVATAR) {
        back_header(fb, "选择头像");
        section(fb, 232, "TF 卡 pictures 文件夹中的 JPG / PNG 图片");
        row(fb, 270, "使用默认图标", app_settings_avatar_path()[0] ? "选择  ›" : "当前  ✓");
        if (!s_wallpaper_count) ui_text(fb, 52, 384, 23, "未找到图片，请放入 pictures 文件夹", EPD_DRAW_ALIGN_LEFT, false);
        for (int i = 0; i < 7; ++i) {
            int index = s_wallpaper_page * 7 + i;
            if (index >= s_wallpaper_count) break;
            EpdRect box = {36, 374 + i * 96, 612, 80};
            bool active = !strcmp(s_wallpapers[index].path, app_settings_avatar_path());
            settings_card(fb, box, 17, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            char name[96]; snprintf(name, sizeof(name), "%s", s_wallpapers[index].name);
            fit_value(name, 490);
            ui_text_vc(fb, 60, box.y + 40, 24, name, EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(611, box.y + 40, 7, UI_GRAY_BLACK, fb);
        }
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_TEXT_EDIT) {
        back_header(fb, s_editor_signature ? "状态栏签名" : "设备名称");
        ui_text(fb, 642, 95, 24, "完成", EPD_DRAW_ALIGN_RIGHT, false);
        ui_text(fb, 36, 201, 21, s_editor_signature ? "状态栏中间显示，留空则隐藏" : "显示在设置页的资料卡", EPD_DRAW_ALIGN_LEFT, false);
        ui_text_input_draw(fb, &s_editor_input, (EpdRect){36, 243, 612, 82}, 28, false, NULL);
        if (s_editor_notice[0]) ui_text_fixed_vc(fb, 36, 510, 22, s_editor_notice, EPD_DRAW_ALIGN_LEFT, false);
        ui_keyboard_draw(fb, UI_SYSTEM_KEYBOARD_TOP);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_SHELF_STYLE) {
        static const char *const styles[] = {"深色书轨", "亚克力书架", "液态玻璃书架", "列表书架"};
        static const char *const descriptions[] = {"每页 9 本", "每页 9 本", "薄玻璃挡条 · 每页 9 本", "作者与进度 · 每页 4 本"};
        for (int i = 0; i < SHELF_STYLE_CHOICES; ++i) {
            int y = 263 + i * 253 - s_style_scroll;
            if (y + 230 < 242 || y >= settings_viewport_end()) continue;
            EpdRect card = {36, y, 612, 230};
            int style = s_shelf_style_ids[i];
            bool active = app_settings_shelf_style() == style;
            settings_card(fb, card, 24, active ? 0xd0 : UI_GRAY_WHITE,
                          active ? 0x58 : 0x70);
            draw_style_thumbnail(fb, style, y + 11);
            if (y + 190 < settings_viewport_end()) ui_text(fb, 68, y + 188, 23, styles[i], EPD_DRAW_ALIGN_LEFT, false);
            if (y + 195 < settings_viewport_end()) ui_text(fb, 310, y + 192, 17, descriptions[i], EPD_DRAW_ALIGN_LEFT, false);
            if (y + 220 < settings_viewport_end()) {
                epd_draw_circle(609, y + 207, 13, UI_GRAY_BLACK, fb);
                if (active) epd_fill_circle(609, y + 207, 6, UI_GRAY_BLACK, fb);
            }
        }
        // 四张卡片高于一屏，滚动后卡片会进入题头/底栏：先画卡片，再补回两条白带与题头。
        // Four cards exceed one screen, so scrolled cards enter the header/nav bands: repaint the
        // two white bands and the header after the cards.
        ui_fill_rect_fast((EpdRect){0, 0, UI_LOCK_WIDTH, 242}, UI_GRAY_WHITE, fb);
        ui_fill_rect_fast((EpdRect){0, settings_viewport_end(), UI_LOCK_WIDTH,
                                    UI_LOCK_HEIGHT - settings_viewport_end()}, UI_GRAY_WHITE, fb);
        ui_nav_status(fb);
        ui_nav_back(fb, 36, 79);
        ui_text_vc(fb, 342, 107, 34, "书架样式", EPD_DRAW_ALIGN_CENTER, false);
        ui_text(fb, 36, 207, 23, "选择书架外观与排列方式", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_TIME_EDIT) {
        ui_nav_back(fb, 36, 79);
        ui_text(fb, 36, 151, 47, "日期与时间", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 36, 216, 23, "北京时间 · UTC+8", EPD_DRAW_ALIGN_LEFT, false);
        ui_hairline(fb, 259, 36, 612, UI_GRAY_LIGHT);
        static const char *const labels[] = {"年", "月", "日", "时", "分"};
        int values[] = {s_year, s_month, s_day, s_hour, s_minute};
        for (int i = 0; i < 5; ++i) {
            int x = 36 + i * 122;
            ui_text(fb, x + 52, 300, 24, labels[i], EPD_DRAW_ALIGN_CENTER, false);
            ui_draw_control_frame(fb, (EpdRect){x, 354, 106, 62}, 8, UI_GRAY_BLACK);
            ui_text_vc(fb, x + 53, 385, 30, "+", EPD_DRAW_ALIGN_CENTER, false);
            char value[8]; snprintf(value, sizeof(value), i == 0 ? "%04d" : "%02d", values[i]);
            ui_text(fb, x + 53, 456, i == 0 ? 34 : 39, value, EPD_DRAW_ALIGN_CENTER, false);
            ui_draw_control_frame(fb, (EpdRect){x, 535, 106, 62}, 8, UI_GRAY_BLACK);
            ui_text_vc(fb, x + 53, 566, 30, "−", EPD_DRAW_ALIGN_CENTER, false);
        }
        ui_text(fb, 36, 649, 23, "点上方 + 或下方 − 调整数字", EPD_DRAW_ALIGN_LEFT, false);
        ui_draw_button(fb, (EpdRect){36, 767, 612, 78}, "保存时间", false);
        ui_draw_button(fb, (EpdRect){36, 874, 612, 78}, "取消", false);
        if (s_notice[0]) ui_text(fb, 36, 996, 22, s_notice, EPD_DRAW_ALIGN_LEFT, false);
        return;
    }
    if (s_page == SETTINGS_WIFI) {
        back_header(fb, "WiFi");
        section(fb, 253, "已保存网络");
        row(fb, 296, s_main_wifi_saved ? s_main_wifi : "尚未配置", s_main_wifi_saved ? "已保存" : "");
        row(fb, 408, "连接或更改网络", "前往传输  ›");
        ui_text(fb, 54, 529, 21, "配网后可在日期与时间中进行 WiFi 对时。", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_SYSTEM_FONT) {
        back_header(fb, "系统字体");
        system_font_layout_t l = system_font_layout();
        settings_card(fb,l.size,22,UI_GRAY_WHITE,0x70);
        char size[16]; snprintf(size,sizeof(size),"%u%%",app_settings_system_font_size());
        if (settings_stacked()) {
            ui_text_vc(fb,60,247,27,"系统字号",EPD_DRAW_ALIGN_LEFT,false);
            ui_text_vc(fb,589,247,27,size,EPD_DRAW_ALIGN_RIGHT,false);
            ui_text_vc(fb,60,328,18,"轻点切换，最大 200%",EPD_DRAW_ALIGN_LEFT,false);
        } else {
            ui_text_vc(fb,58,227,25,"系统字号",EPD_DRAW_ALIGN_LEFT,false);
            ui_text_vc(fb,58,269,18,"轻点切换，最大 200%",EPD_DRAW_ALIGN_LEFT,false);
            ui_text_vc(fb,589,247,26,size,EPD_DRAW_ALIGN_RIGHT,false);
        }
        ui_draw_icon(fb,619,247,28,UI_ICON_ROTATE_CW,0x38);
        section(fb,l.preview_title,"效果预览");
        settings_card(fb,l.preview,22,UI_GRAY_WHITE,0x70);
        ui_text_vc(fb,60,l.preview.y+(settings_stacked()?68:51),29,"阅读，让时间慢下来",EPD_DRAW_ALIGN_LEFT,false);
        ui_text_vc(fb,60,l.preview.y+(settings_stacked()?151:107),25,"Aa 123",EPD_DRAW_ALIGN_LEFT,false);
        section(fb,l.font_title,"选择字体");
        const char *selected = app_settings_system_font_path();
        // 页数可能因字体目录变化而缩短：绘制前先夹紧当前页，避免停在已经不存在的一页。
        // The page count may shrink when the catalogue changes; clamp before painting so the page
        // never sticks on one that no longer exists.
        system_font_clamp_page(l.slots);
        const int items = system_font_items(), first = s_font_page*l.slots;
        for (int slot=0;slot<l.slots && first+slot<items;++slot) {
            int index=first+slot;
            const ttf_font_item_t *item=index?ttf_font_item(index-1):NULL;
            bool active=item?!strcmp(selected,item->path):!selected[0];
            EpdRect box=system_font_item_rect(slot);
            settings_card(fb,box,20,active?0xe0:UI_GRAY_WHITE,0x70);
            char label[TTF_FONT_NAME_MAX];
            snprintf(label,sizeof(label),"%s",item?system_font_label(item->path):"思源黑体（内建）");
            settings_fit_text(label,26,box.width-100);
            ui_text_vc(fb,60,box.y+box.height/2,26,label,EPD_DRAW_ALIGN_LEFT,false);
            if (active) epd_fill_circle(613,box.y+box.height/2,6,UI_GRAY_BLACK,fb);
        }
        char pages[32];
        snprintf(pages,sizeof(pages),"%u / %u",(unsigned)(s_font_page+1),
                 (unsigned)system_font_pages(l.slots));
        ui_text_fixed_vc(fb,648,settings_viewport_end()-16,18,pages,EPD_DRAW_ALIGN_RIGHT,false);
        if (s_notice[0]) ui_text_fixed_vc(fb,42,settings_viewport_end()-16,18,s_notice,EPD_DRAW_ALIGN_LEFT,false);
        settings_navigation(fb);
        if (s_font_sync_confirm) draw_system_font_sync(fb);
        return;
    }
    if (s_page == SETTINGS_SYSTEM_SIZE) {
        back_header(fb, "系统字号");
        section(fb, 248, "界面文字大小");
        for (int i = 0; i < 11; ++i) {
            int value = 100 + i * 10;
            EpdRect box = {36 + (i % 2) * 316, 298 + (i / 2) * 122, 296, 102};
            bool active = app_settings_system_font_size() == value;
            settings_card(fb, box, 20, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            char label[48]; snprintf(label, sizeof(label), "%d%%", value);
            ui_text_vc(fb, box.x + 24, box.y + 51, 29, label, EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(box.x + box.width - 25, box.y + 51, 8, UI_GRAY_BLACK, fb);
        }
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_MAIN_REFRESH) {
        back_header(fb, "主页刷新模式");
        section(fb, 248, "首页 · 书架 · 文件管理 · 设置");
        const char* names[] = {"普通", "快刷", "水波纹"};
        const char* details[] = {"保留灰阶层次，兼顾画面清晰度", "黑白快刷，亚克力用细棋盘格", "以水波纹切换页面，保留灰阶"};
        for (int i = 0; i < 3; ++i) {
            const EpdRect box = {36, 298 + i * 158, 612, 132};
            const bool active = app_settings_main_refresh_mode() == (app_main_refresh_mode_t)i;
            settings_card(fb, box, 22, active ? 0xd0 : UI_GRAY_WHITE, 0x58);
            ui_text_vc(fb, 64, box.y + 38, 30, names[i], EPD_DRAW_ALIGN_LEFT, false);
            char detail[128]; snprintf(detail, sizeof(detail), "%s", details[i]); fit_value(detail, 498);
            ui_text_vc(fb, 64, box.y + 89, 22, detail, EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(607, box.y + 38, 8, UI_GRAY_BLACK, fb);
        }
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_SYSTEM_CONTRAST) {
        back_header(fb, "系统对比度");
        section(fb, 248, "调整系统界面的灰阶层次与清晰度");
        static const char *const names[] = {"柔和", "标准", "清晰", "鲜明", "高对比"};
        for (int i = 0; i < 5; ++i) {
            int value = 100 + i * 10;
            EpdRect box = {36, 298 + i * 116, 612, 90};
            bool active = app_settings_system_contrast() == value;
            settings_card(fb, box, 20, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            ui_text_vc(fb, 64, box.y + 45, 28, names[i], EPD_DRAW_ALIGN_LEFT, false);
            char shown[16]; snprintf(shown, sizeof(shown), "%d%%", value);
            ui_text_vc(fb, 570, box.y + 45, 22, shown, EPD_DRAW_ALIGN_RIGHT, false);
            if (active) epd_fill_circle(605, box.y + 45, 8, UI_GRAY_BLACK, fb);
        }
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_LOCK_STYLE) {
        back_header(fb, "锁屏样式");
        section(fb, 248, "选择电源键锁屏后的画面");
        const char *labels[] = {"壁纸锁屏", "阅读票根", "书架拼贴", "透明 PNG 书封", "极简时钟"};
        const char *details[] = {"使用 TF 卡中的 JPG / PNG 图片", "书封、进度和阅读记录", "真实封面 · 名称与数量 · 系统字体", "当前页面作底 · 白底 PNG 自动去白", "居中时分 · 日期 · 状态栏签名"};
        const uint8_t values[] = {1, 0, 2, 3, 4};
        for (int i = 0; i < 5; ++i) {
            EpdRect box = {36, 300 + i * 128, 612, 116};
            bool active = app_settings_lock_style() == values[i];
            settings_card(fb, box, 22, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            ui_text(fb, 64, box.y + 16, 30, labels[i], EPD_DRAW_ALIGN_LEFT, false);
            ui_text(fb, 64, box.y + 70, 20, details[i], EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(609, box.y + 58, 8, UI_GRAY_BLACK, fb);
        }
        ui_text(fb,54,966,21,"透明书封放入 pictures · 推荐 684 × 1216",EPD_DRAW_ALIGN_LEFT,false);
        if (app_settings_lock_style() == 4)
            row(fb, 1010, "时钟锁屏方向", app_settings_lock_clock_landscape() ? "横屏" : "竖屏");
        else if (app_settings_wallpaper_path()[0])
            row(fb, 1010, "当前壁纸", strrchr(app_settings_wallpaper_path(), '/') + 1);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_WALLPAPER) {
        back_header(fb,s_bookmark_picker?"选择透明书封":"选择壁纸");
        section(fb,244,s_bookmark_picker?"pictures · 透明 PNG · 保留整张画布":"TF 卡图片 · JPG / PNG · 不超过 50 MB");
        if (!s_wallpaper_count)
            ui_text(fb, 54, 325, 25, "未找到图片，请放入 TF 卡的 pictures 文件夹", EPD_DRAW_ALIGN_LEFT, false);
        for (int i = 0; i < 8; ++i) {
            int index = s_wallpaper_page * 8 + i;
            if (index >= s_wallpaper_count) break;
            EpdRect box = {36, 292 + i * 92, 612, 78};
            bool active = !strcmp(s_wallpapers[index].path,s_bookmark_picker?app_settings_bookmark_path():app_settings_wallpaper_path());
            settings_card(fb, box, 18, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            char name[96]; snprintf(name, sizeof(name), "%s", s_wallpapers[index].name);
            fit_value(name, 490);
            ui_text_vc(fb, 60, box.y + 39, 24, name, EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(609, box.y + 39, 6, UI_GRAY_BLACK, fb);
        }
        // 选图页底部也能直接切换时间锁屏方向：点一次竖屏，再点一次横屏。
        // The picker page also toggles the clock-lock direction: tap once portrait, again landscape.
        ui_text_vc(fb, 342, 1052, 21,
                   app_settings_lock_clock_landscape() ? "时钟锁屏方向：横屏（点按切换）"
                                                       : "时钟锁屏方向：竖屏（点按切换）",
                   EPD_DRAW_ALIGN_CENTER, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_WALLPAPER_PREVIEW) {
        back_header(fb,s_bookmark_picker?"预览透明书封":"预览壁纸");
        EpdRect image = {166, 194, 352, 626};
        ui_fill_round_rect(fb, image, 8, UI_GRAY_WHITE);
        s_wallpaper_preview_ok = s_wallpaper_selected >= 0 && s_wallpaper_selected < s_wallpaper_count &&
            (s_bookmark_picker ? book_lock_bookmark_preview_ready()
                               : ui_wallpaper_draw(fb, s_wallpapers[s_wallpaper_selected].path, image));
        if(s_bookmark_picker && s_wallpaper_preview_ok)book_lock_bookmark_preview_draw(fb,image);
        ui_draw_round_rect(fb, image, 8, 0x70);
        if (!s_wallpaper_preview_ok)
            ui_text_vc(fb, 342, 507, 23, s_bookmark_picker?"PNG无法加载，请更换图片":"图片无法预览", EPD_DRAW_ALIGN_CENTER, false);
        if (s_wallpaper_selected >= 0 && s_wallpaper_selected < s_wallpaper_count) {
            char name[96]; snprintf(name, sizeof(name), "%s", s_wallpapers[s_wallpaper_selected].name);
            fit_value(name, 570);
            ui_text_vc(fb, 342, 859, 24, name, EPD_DRAW_ALIGN_CENTER, false);
            char position[40];
            snprintf(position, sizeof(position), "%d / %d · 上下滑动切换", s_wallpaper_selected + 1, s_wallpaper_count);
            ui_text_vc(fb, 342, 908, 20, position, EPD_DRAW_ALIGN_CENTER, false);
        }
        if (s_wallpaper_preview_ok) {
            EpdRect button = {94, 962, 496, 70};
            ui_fill_round_rect(fb, button, 22, 0x30);
            ui_text_vc(fb, 342, 997, 25, s_bookmark_picker?"使用透明书封":"设为锁屏壁纸", EPD_DRAW_ALIGN_CENTER, true);
        }
        if (s_wallpaper_confirm) {
            EpdRect dialog = {68, 435, 548, 306};
            ui_fill_round_rect(fb, dialog, 26, UI_GRAY_WHITE);
            ui_draw_control_frame(fb, dialog, 26, 0x50);
            ui_text_vc(fb, 342, 503, 31, s_bookmark_picker?"开启透明书封锁屏？":"设为壁纸锁屏？", EPD_DRAW_ALIGN_CENTER, false);
            ui_text_vc(fb, 342, 565, 20, s_bookmark_picker?"以锁屏前当前页面为背景":"确认后，短按电源键将显示此图片", EPD_DRAW_ALIGN_CENTER, false);
            EpdRect cancel = {94, 643, 232, 68}, confirm = {358, 643, 232, 68};
            ui_fill_round_rect(fb, cancel, 18, 0xe0);
            ui_fill_round_rect(fb, confirm, 18, 0x30);
            ui_text_vc(fb, 210, 677, 24, "取消", EPD_DRAW_ALIGN_CENTER, false);
            ui_text_vc(fb, 474, 677, 24, "确认", EPD_DRAW_ALIGN_CENTER, true);
        }
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_TIME) {
        back_header(fb, "日期与时间");
        time_t now = time(NULL);
        char shown[64] = "未设置";
        if (now >= 1704067200) {
            struct tm tm; time_t local = now + 8 * 3600;
            if (gmtime_r(&local, &tm)) snprintf(shown, sizeof(shown), "%04d-%02d-%02d  %02d:%02d",
                tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min);
        }
        section(fb, 253, "当前时间 · 北京时间");
        row(fb, 296, shown, "");
        row(fb, 407, "通过 WiFi 对时", "立即同步  ›");
        row(fb, 518, "手动设置", "编辑  ›");
        ui_text(fb, 54, 656, 21, "对时成功后由内部时钟持续走时；无需保持联网。", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 54, 694, 21, "长时间离线可能产生误差，建议定期重新对时。", EPD_DRAW_ALIGN_LEFT, false);
        if (s_notice[0]) ui_text(fb, 54, 772, 22, s_notice, EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_AUTO_LOCK) {
        back_header(fb, "自动休眠锁屏");
        section(fb, 228, "无操作后自动锁屏");
        const char *labels[] = {"1 分钟", "5 分钟", "10 分钟", "关闭"};
        const uint8_t values[] = {1, 5, 10, 0};
        for (int i = 0; i < 4; ++i) {
            EpdRect box = {36, 272 + i * 112, 612, 92};
            bool active = app_settings_auto_lock_minutes() == values[i];
            settings_card(fb, box, 20, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            ui_text_vc(fb, 64, box.y + box.height / 2, 30, labels[i], EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(609, box.y + box.height / 2, 8, UI_GRAY_BLACK, fb);
        }
        ui_text(fb, 48, 760, 23, "操作后重新计时，传输和升级期间暂停", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, 810, 23, "锁屏先浅睡，10 分钟后进入深睡", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_POWER_SLEEP) {
        back_header(fb, "关机睡眠");
        section(fb, 236, "选择电源菜单中“关机”的方式");
        const char *shutdown_labels[] = {"彻底关机", "先浅睡，10 分钟后深睡"};
        const char *shutdown_details[] = {"完全断电，长按电源键开机",
                                          "锁屏画面保留；深睡后短按电源键开机"};
        for (int i = 0; i < 2; ++i) {
            int y = 278 + i * 136;
            bool active = app_settings_staged_shutdown() == (i == 1);
            settings_card(fb, (EpdRect){36, y, 612, 124}, 22, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            ui_text(fb, 64, y + 20, 29, shutdown_labels[i], EPD_DRAW_ALIGN_LEFT, false);
            ui_text(fb, 64, y + 72, 20, shutdown_details[i], EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(609, y + 62, 8, UI_GRAY_BLACK, fb);
        }
        ui_text(fb, 54, 558, 21, "浅睡时按键直接返回，深睡时会重新开机。", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 54, 594, 21, "锁屏样式同时适用于壁纸与阅读票根。", EPD_DRAW_ALIGN_LEFT, false);
        // 用户修订：开机按键次数可选，单击更快、双击防误触；深睡唤醒与锁屏解锁共用。
        // User revision: the boot press count is selectable; one press is faster, two resist accidental wake. Deep-sleep wake and lock unlock share it.
        section(fb, 650, "按电源键开机");
        const char *wake_labels[] = {"单击开机", "双击开机"};
        const char *wake_details[] = {"按一次电源键就开机，更快", "连续按两次，放在包里不易误开机"};
        for (int i = 0; i < 2; ++i) {
            int y = 692 + i * 124;
            bool active = app_settings_wake_presses() == (uint8_t)(i + 1);
            settings_card(fb, (EpdRect){36, y, 612, 112}, 22, active ? 0xd0 : UI_GRAY_WHITE, 0x70);
            ui_text(fb, 64, y + 16, 27, wake_labels[i], EPD_DRAW_ALIGN_LEFT, false);
            ui_text(fb, 64, y + 64, 20, wake_details[i], EPD_DRAW_ALIGN_LEFT, false);
            if (active) epd_fill_circle(609, y + 56, 8, UI_GRAY_BLACK, fb);
        }
        ui_text(fb, 54, 948, 21, "深睡唤醒与锁屏解锁都按这个次数。", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 54, 984, 21, "双击更防误触；单击一按即用。", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_BOOT) {
        back_header(fb, "电脑刷机");
        settings_card(fb, (EpdRect){36, 254, 612, 298}, 22, UI_GRAY_WHITE, 0x70);
        ui_text(fb, 60, 288, 29, "进入 BOOT 模式", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 60, 350, 22, "用于官网完整刷机或故障恢复", EPD_DRAW_ALIGN_LEFT, false);
        ui_draw_button(fb, (EpdRect){60, 438, 564, 78}, s_boot_pending ? "正在进入" : "进入 BOOT 模式", false);
        ui_text(fb, 48, 620, 22, "请用 USB 连接电脑，再打开官网刷机页", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb); return;
    }
    if (s_page == SETTINGS_UPGRADE) {
        back_header(fb, "系统升级");
        settings_card(fb, (EpdRect){36, 202, 612, 120}, 22, UI_GRAY_WHITE, 0x70);
        ui_text(fb, 60, 224, 22, "当前版本", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 60, 264, 29, esp_app_get_description()->version, EPD_DRAW_ALIGN_LEFT, false);
        char pi_line1[48];
        snprintf(pi_line1, sizeof(pi_line1), "页屿系统 %s · %s",
                 PAGEISLE_SYSTEM_VERSION, PAGEISLE_SYSTEM_DATE);
        ui_text(fb, 60, 300, 20, pi_line1, EPD_DRAW_ALIGN_LEFT, false);
        if (s_upgrade_confirm) {
            settings_card(fb, (EpdRect){36, 356, 612, s_upgrade_online ? 574 : 344}, 22, UI_GRAY_WHITE, 0x70);
            ui_text_fixed(fb, 60, 383, 31, s_upgrade_online ? "发现新版本" : "确认 TF 卡升级", EPD_DRAW_ALIGN_LEFT, false);
            ui_text_fixed(fb, 60, 447, 28, s_upgrade_online ? s_update.release.version : s_local_update.candidate_version,
                    EPD_DRAW_ALIGN_LEFT, false);
            if (s_upgrade_online) {
                ui_text_fixed(fb, 60, 494, 26, "本次更新", EPD_DRAW_ALIGN_LEFT, false);
                draw_upgrade_notes(fb);
            }
            ui_text_fixed(fb, 60, s_upgrade_online ? 770 : 513, 24, "升级期间请保持供电", EPD_DRAW_ALIGN_LEFT, false);
            ui_text_fixed(fb, 60, s_upgrade_online ? 806 : 560, 23, "设置、阅读记录与 TF 卡文件保留", EPD_DRAW_ALIGN_LEFT, false);
            ui_draw_button(fb, upgrade_confirm_button(s_upgrade_online, false), s_upgrade_online ? "稍后" : "取消", false);
            ui_draw_button(fb, upgrade_confirm_button(s_upgrade_online, true), s_upgrade_online ? "开始更新" : "确认升级", true);
        } else {
            settings_card(fb, (EpdRect){36, 356, 612, 278}, 22, UI_GRAY_WHITE, 0x70);
            ui_text(fb, 60, 383, 29, "联网 OTA", EPD_DRAW_ALIGN_LEFT, false);
            char detail[96];
            snprintf(detail, sizeof(detail), "%s", s_update.message[0] ? s_update.message : "连接 WiFi，检查官网发布的新版本");
            fit_value(detail, 540);
            ui_text(fb, 60, 436, 21, detail, EPD_DRAW_ALIGN_LEFT, false);
            if (s_update.state == PICO_UPDATE_AVAILABLE)
                ui_text(fb, 60, 477, 24, s_update.release.version, EPD_DRAW_ALIGN_LEFT, false);
            if (s_update.state == PICO_UPDATE_DOWNLOADING) draw_upgrade_progress(fb);
            ui_draw_button(fb, (EpdRect){60, 550, 564, 62}, s_update.busy ? "取消联网更新" :
                s_update.state == PICO_UPDATE_AVAILABLE ? "开始更新" : "检查更新", s_update.state == PICO_UPDATE_AVAILABLE);
            settings_card(fb, (EpdRect){36, 662, 612, 262}, 22, UI_GRAY_WHITE, 0x70);
            ui_text(fb, 60, 689, 29, "TF 卡升级", EPD_DRAW_ALIGN_LEFT, false);
            ui_text(fb, 60, 739, 23, "升级包放在 TF 卡根目录", EPD_DRAW_ALIGN_LEFT, false);
            ui_text(fb, 60, 786, 21, s_local_update.ready ? s_local_update.candidate_version : "把官网升级包放入 TF 卡根目录", EPD_DRAW_ALIGN_LEFT, false);
            ui_draw_button(fb, (EpdRect){60, 840, 564, 62}, s_local_pending ? "正在安装，请勿断电" :
                s_local_update.ready ? "安装 TF 卡升级包" : "重新检查 TF 卡", s_local_update.ready);
        }
        if (s_upgrade_notice[0]) ui_text(fb, 48, 957, 21, s_upgrade_notice, EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, 1010, 20, "首次安装或修复，请通过官网完整刷机", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_UPGRADE_NOTES) {
        // 更新说明：版本号 + 本版可感知的变化，按页显示，不依赖网络与 TF 卡。
        // Release notes: version plus the user-visible changes, paginated and readable offline.
        ui_text_set_system_scale(false);
        back_header(fb, "页屿 · 更新说明");
        settings_card(fb, (EpdRect){36, 202, 612, 104}, 22, UI_GRAY_WHITE, 0x70);
        ui_text(fb, 60, 224, 22, "当前版本", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 60, 262, 28, esp_app_get_description()->version, EPD_DRAW_ALIGN_LEFT, false);
        char pi_line2[48];
        snprintf(pi_line2, sizeof(pi_line2), "页屿系统 %s · %s",
                 PAGEISLE_SYSTEM_VERSION, PAGEISLE_SYSTEM_DATE);
        ui_text(fb, 60, 300, 20, pi_line2, EPD_DRAW_ALIGN_LEFT, false);
        settings_card(fb, (EpdRect){36, 338, 612, 660}, 22, UI_GRAY_WHITE, 0x70);
        ui_text(fb, 60, 362, 26, "本版重点", EPD_DRAW_ALIGN_LEFT, false);
        const int count = (int)(sizeof(k_upgrade_notes) / sizeof(k_upgrade_notes[0]));
        const int pages = upgrade_notes_pages();
        if ((int)s_notes_page >= pages) s_notes_page = (unsigned)(pages - 1);
        int y = 410;
        const int first = (int)s_notes_page * UPGRADE_NOTES_PER_PAGE;
        for (int i = first; i < count && i < first + UPGRADE_NOTES_PER_PAGE; ++i) {
            ui_text_fixed(fb, 60, y, 21, k_upgrade_notes[i], EPD_DRAW_ALIGN_LEFT, false);
            y += 44;
        }
        char page_text[32];
        snprintf(page_text, sizeof(page_text), "‹  %u / %d  ›", s_notes_page + 1, pages);
        ui_text_fixed_vc(fb, 342, 950, 21, page_text, EPD_DRAW_ALIGN_CENTER, false);
        ui_text_fixed_vc(fb, 342, 982, 17, "左右点按页码或上下滑动翻页",
                         EPD_DRAW_ALIGN_CENTER, false);
        settings_navigation(fb);
        ui_text_set_system_scale(true);
        return;
    }
    if (s_page == SETTINGS_RAM_DIAG) {
        // 内存诊断：顶部是当前内部 SRAM / PSRAM 用量，下面按内部 RAM 峰值降序列出已访问界面。
        // RAM diagnostics: current internal-SRAM/PSRAM use on top, visited pages by internal peak below.
        // 版式按固定字号设计：临时关闭系统字号缩放，避免大字号把 12 行列表挤出行高。
        // Layout is designed at fixed sizes: disable system text scaling so large UI fonts keep the 12-row pitch.
        ui_text_set_system_scale(false);
        back_header(fb, "内存诊断");
        app_ram_diag_mem_t mem;
        app_ram_diag_mem(&mem);
        char value[96];
        settings_card(fb, (EpdRect){36, 196, 612, 144}, 22, UI_GRAY_WHITE, 0x70);
        settings_divider(fb, 268, 88, 544);
        // 两行汇总：剩余 / 总量 KB 与占用百分比（free、total、当前% 三个口径同屏）。
        // Two summary rows: free / total KB plus the current percentage.
        snprintf(value, sizeof(value), "余 %u / %u KB · %u.%u%%",
                 (unsigned)((mem.internal_free + 512u) / 1024u),
                 (unsigned)((mem.internal_total + 512u) / 1024u),
                 (unsigned)(mem.internal_pct / 10u), (unsigned)(mem.internal_pct % 10u));
        ui_text_vc(fb, 60, 234, 25, "内部 SRAM", EPD_DRAW_ALIGN_LEFT, false);
        ui_text_vc(fb, 620, 234, 20, value, EPD_DRAW_ALIGN_RIGHT, false);
        snprintf(value, sizeof(value), "余 %u / %u KB · %u.%u%%",
                 (unsigned)((mem.psram_free + 512u) / 1024u),
                 (unsigned)((mem.psram_total + 512u) / 1024u),
                 (unsigned)(mem.psram_pct / 10u), (unsigned)(mem.psram_pct % 10u));
        ui_text_vc(fb, 60, 302, 25, "PSRAM", EPD_DRAW_ALIGN_LEFT, false);
        ui_text_vc(fb, 620, 302, 20, value, EPD_DRAW_ALIGN_RIGHT, false);
        // 启动基线：首个页面进入前的占用，可与 esp_idf_size 的静态占比对照；内部堆剩余/总量即 80% 门槛余量。
        // Baseline before the first page (compare with esp_idf_size static use); heap free/total is the 80% headroom.
        snprintf(value, sizeof(value), "启动基线 %u.%u%% · 目标 <80%% · 内部堆剩余 %u/%u KB",
                 (unsigned)(app_ram_diag_baseline_internal_pct() / 10u),
                 (unsigned)(app_ram_diag_baseline_internal_pct() % 10u),
                 (unsigned)(mem.internal_heap_free / 1024u),
                 (unsigned)(mem.internal_heap_total / 1024u));
        ui_text(fb, 40, 362, 20, value, EPD_DRAW_ALIGN_LEFT, false);
        section(fb, 400, "各界面内部 RAM 峰值（超 80% 标 !，按峰值降序）");
        ui_text_fixed_vc(fb, 60, 438, 17, "界面", EPD_DRAW_ALIGN_LEFT, false);
        ui_text_fixed_vc(fb, 520, 438, 17, "峰值", EPD_DRAW_ALIGN_RIGHT, false);
        ui_text_fixed_vc(fb, 620, 438, 17, "最小剩余", EPD_DRAW_ALIGN_RIGHT, false);
        // 最多 12 行：每轮挑当前最大值逐个输出，不额外占静态排序表。
        // At most 12 rows: pick the next maximum each time instead of keeping a static order table.
        const int count = app_ram_diag_count();
        int rows = count < 12 ? count : 12;
        if (rows < 1) rows = 1;
        // 单行时保持圆角半径不大于半高，避免 22px 圆角在 42px 卡片上画歪。
        // Keep the corner radius within half the height when only one row is present.
        const int list_h = rows * 42 < 64 ? 64 : rows * 42;
        settings_card(fb, (EpdRect){36, 456, 612, list_h}, 22, UI_GRAY_WHITE, 0x70);
        uint32_t shown = 0;
        int drawn = 0;
        for (int row = 0; row < rows; ++row) {
            int best = -1;
            uint16_t best_peak = 0;
            for (int i = 0; i < count; ++i) {
                if (shown & (1u << i)) continue;
                uint16_t peak = 0;
                if (!app_ram_diag_entry(i, NULL, &peak, NULL, NULL)) continue;
                if (best < 0 || peak > best_peak) { best = i; best_peak = peak; }
            }
            if (best < 0) break;
            shown |= 1u << best;
            const char *name = NULL;
            uint16_t peak = 0;
            uint32_t min_free = 0;
            (void)app_ram_diag_entry(best, &name, &peak, &min_free, NULL);
            char line[64];
            snprintf(line, sizeof(line), "%s", name != NULL ? name : "?");
            fit_value(line, 320);
            int cy = 456 + row * 42 + 21;
            if (row) settings_divider(fb, cy - 21, 88, 544);
            char peak_text[24], free_text[24];
            // 验收目标 80%：超线的行在百分比后加 !，一眼看出需要削峰的界面。
            // 80% acceptance gate: flag over-budget rows with "!" right after the percentage.
            snprintf(peak_text, sizeof(peak_text), "%u.%u%%%s",
                     (unsigned)(peak / 10u), (unsigned)(peak % 10u), peak > 800 ? "!" : "");
            snprintf(free_text, sizeof(free_text), "%lu KB",
                     (unsigned long)((min_free + 1023u) / 1024u));
            ui_text_vc(fb, 60, cy, 21, line, EPD_DRAW_ALIGN_LEFT, false);
            ui_text_vc(fb, 520, cy, 20, peak_text, EPD_DRAW_ALIGN_RIGHT, false);
            ui_text_vc(fb, 620, cy, 19, free_text, EPD_DRAW_ALIGN_RIGHT, false);
            ++drawn;
        }
        if (drawn == 0)
            ui_text_vc(fb, 60, 456 + 21, 20, "暂无数据：先去其它界面逛一圈", EPD_DRAW_ALIGN_LEFT, false);
        // 「重置统计」：清空峰值并从当前页重新累计；重绘沿用普通页面刷新，不整屏闪。
        // "Reset statistics": clear peaks and restart from this page; the ordinary page path redraws it.
        ui_draw_button(fb, (EpdRect){36, 978, 612, 74}, "重置统计", false);
        ui_text_fixed_vc(fb, 342, 1066, 16, "离开界面时追加日志到 TF 卡：pageisle_ram_diag.log",
                         EPD_DRAW_ALIGN_CENTER, false);
        settings_navigation(fb);
        ui_text_set_system_scale(true);
        return;
    }
    if (s_page == SETTINGS_CONFIG) {
        back_header(fb, "保存与恢复配置");
        section(fb, 248, "换机或刷机后，快速恢复个性化设置");
        settings_card(fb, (EpdRect){36, 299, 612, 197}, 22, UI_GRAY_WHITE, 0x70);
        ui_text(fb, 60, 326, 26, "TF 卡根目录", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 60, 377, 23, "配置备份文件", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 60, 435, 19, "文字排版、设备资料、阅读记录与书签", EPD_DRAW_ALIGN_LEFT, false);
        ui_draw_button(fb, (EpdRect){36, 561, 612, 83}, "保存当前配置到 TF 卡", false);
        ui_draw_button(fb, (EpdRect){36, 681, 612, 83},
                       s_config_confirm ? "再次点按，确认恢复配置" : "从 TF 卡恢复配置", false);
        if (s_notice[0]) ui_text(fb, 48, 819, 21, s_notice, EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, 899, 19, "包含阅读记录、设备资料和已存 WiFi。", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, 939, 19, "书籍、字体和图片仍需留在 TF 卡。", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, 979, 19, "备份含 WiFi 密码，请妥善保管 TF 卡。", EPD_DRAW_ALIGN_LEFT, false);
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_BLE_SCAN) {
        ui_nav_back(fb, 36, 79);
        ui_text_vc(fb, 342, 107, 34, "扫描设备", EPD_DRAW_ALIGN_CENTER, false);
        const ble_scan_layout_t l = ble_scan_layout();
        const int scroll = s_ble_scroll;
        // 持续扫描中：告诉用户正在找，以及找到几台。栈还在异步启动时给出等待提示，
        // 不要显示"扫描已停止"——那看起来像搜索失败。
        // Continuous scan: say that it is running and how many turned up. While the stack is still
        // starting, say it is starting rather than "scan stopped", which reads as a failure.
        char head[64];
        if (ble_pt_scanning()) snprintf(head, sizeof(head), "正在搜索…已找到 %u 台", (unsigned)ble_scan_visible_count());
        else if (app_settings_ble_turner() && !ble_pt_running()) {
            // 与蓝牙二级页同一口径：WiFi 占用射频时栈会被暂停，这里要说清楚是在等 WiFi 让出，
            // 而不是搜索失败。
            // Same wording as level two: WiFi holding the radio pauses the stack, so say that
            // instead of leaving "scan stopped" to read as a failed search.
            read_pico_transfer_status_t network = {0};
            read_pico_transfer_get_status(&network);
            snprintf(head, sizeof(head), "%s", network.state != READ_PICO_TRANSFER_STOPPED
                     ? "WiFi 使用中，蓝牙暂停" : "蓝牙正在启动…");
        }
        else snprintf(head, sizeof(head), "扫描已停止");
        ui_text(fb, 44, l.status_top - scroll, 23, head, EPD_DRAW_ALIGN_LEFT, false);
        // 提示行：启动失败原因（含内存数字）与断开旧设备的说明都放在这里。
        // Notice line: start-failure reasons (with memory figures) and the old-link teardown note.
        if (s_ble_notice[0]) {
            char notice[64];
            snprintf(notice, sizeof(notice), "%s", s_ble_notice);
            fit_value(notice, 540);
            ui_text(fb, 44, l.status_top - scroll + 46, 20, notice, EPD_DRAW_ALIGN_LEFT, false);
        }
        for (int i = 0; i < l.device_rows; ++i) {
            const ble_pt_device_t *dev = ble_scan_visible_at(i);
            if (!dev) continue;
            char label[48];
            snprintf(label, sizeof(label), "%s", dev->name);
            fit_value(label, 360);
            char value[44];
            snprintf(value, sizeof(value), "%d dBm%s%s", dev->rssi, dev->hid ? " · HID" : "",
                     dev->bonded ? " · 已配对" : "");
            int top = l.devices_top - scroll + i * BLE_ROW_H;
            if (top + BLE_ROW_H >= 190 && top < settings_viewport_end()) {
                settings_card(fb, (EpdRect){36, top, 612, BLE_ROW_H - 8}, 18, UI_GRAY_WHITE, 0x70);
                ui_text(fb, 60, top + 12, 25, label, EPD_DRAW_ALIGN_LEFT, false);
                ui_text(fb, 60, top + 45, 19, value, EPD_DRAW_ALIGN_LEFT, false);
                ui_draw_icon(fb,(624)-8,top + 38,26,UI_ICON_CHEVRON_RIGHT,UI_GRAY_BLACK);
            }
        }
        if (!l.device_rows)
            ui_text(fb, 44, l.devices_top - scroll + 18, 23, "附近还没有发现设备",
                    EPD_DRAW_ALIGN_LEFT, false);
        ui_fill_rect_fast((EpdRect){0, 0, UI_LOCK_WIDTH, 190}, UI_GRAY_WHITE, fb);
        ui_nav_status(fb);
        back_header(fb, "扫描设备");
        settings_navigation(fb);
        return;
    }
    if (s_page == SETTINGS_BLUETOOTH) {
        ui_nav_back(fb, 36, 79);
        ui_text_vc(fb, 342, 107, 34, "蓝牙翻页器", EPD_DRAW_ALIGN_CENTER, false);
        const ble_layout_t l = ble_layout();

        // 学习按键时把提示顶到最上面，用户不用滚回去看。
        // While learning, the prompt is pinned to the top so the user need not scroll back.
        if (s_ble_learning || s_ble_feedback[0]) {
            settings_card(fb, (EpdRect){36, 202 - s_ble_scroll, 612, 126}, 22, 0xd0, 0x58);
            ui_text_vc(fb, 342, 265 - s_ble_scroll, 24,
                       !s_ble_learning ? s_ble_feedback :
                       s_ble_learning == 1 ? "请按翻页器上「上一页」要用的键"
                                           : "请按翻页器上「下一页」要用的键",
                       EPD_DRAW_ALIGN_CENTER, false);
            if (!s_ble_learning)
                ui_text_vc(fb, 342, 305 - s_ble_scroll, 19, "轻点此处返回蓝牙开关", EPD_DRAW_ALIGN_CENTER, false);
        } else {
            setting_toggle(fb, l.toggle_top, "启用蓝牙", "开启后可配对蓝牙翻页器；关闭会释放蓝牙内存",
                           app_settings_ble_turner());
        }

        section(fb, l.status_top - 38, "状态");
        char ble_status[80];
        if (!app_settings_ble_turner()) snprintf(ble_status, sizeof(ble_status), "已关闭");
        else if (!ble_pt_running()) {
            read_pico_transfer_status_t network;
            read_pico_transfer_get_status(&network);
            snprintf(ble_status, sizeof(ble_status), network.state != READ_PICO_TRANSFER_STOPPED ? "WiFi 使用中，蓝牙暂停" : "启动中…");
        }
        else if (ble_pt_connected()) snprintf(ble_status, sizeof(ble_status), "已连接 %s", ble_pt_connected_name());
        else if (ble_pt_connecting()) snprintf(ble_status, sizeof(ble_status), "连接中…");
        else snprintf(ble_status, sizeof(ble_status), "未连接");
        ble_row(fb, l.status_top, "当前", ble_status);
        if (l.notice_top >= 0) ui_text(fb, 44, l.notice_top, 21, s_ble_notice, EPD_DRAW_ALIGN_LEFT, false);

        // 已配对：点行连接，右侧按钮删除。/ Bonded peers: the row connects, the button forgets.
        section(fb, l.bonds_title_top, "已配对");
        if (!l.bond_rows)
            ble_row(fb, l.bonds_title_top + 38, "暂无已配对设备", "");
        for (int i = 0; i < l.bond_rows && i < BLE_PT_MAX_BONDS; ++i) {
            const ble_pt_bond_t *bond = ble_pt_bond((uint8_t)i);
            if (!bond) continue;
            char label[40];
            snprintf(label, sizeof(label), "%s", bond->name[0] ? bond->name : bond->addr);
            fit_value(label, 300);
            const bool live = ble_pt_connected() && !strcmp(ble_pt_connected_name(), bond->name);
            ble_row(fb, l.bond_top[i], label, live ? "已连接" : "连接  ›");
            ui_draw_button(fb, ble_button_rect(l.bond_top[i]), "删除", false);
        }

        ble_row(fb, l.scan_entry_top, "添加翻页器", "扫描设备");
        ui_draw_icon(fb,(624)-8,l.scan_entry_top + 38,26,UI_ICON_CHEVRON_RIGHT,UI_GRAY_BLACK);

        section(fb, l.learn_title_top, "按键映射");
        static const char *const learn_names[] = {"上一页", "下一页"};
        static const ble_pt_action_t learn_actions[] = {BLE_PT_ACTION_PREV, BLE_PT_ACTION_NEXT};
        for (int i = 0; i < 2; ++i) {
            // 学到的键直接显示出来；没学过就走内置映射。
            // Show the learned key itself; with none, the built-in map applies.
            char bound_label[40];
            ble_pt_frame_t bound;
            if (ble_pt_binding(learn_actions[i], &bound)) format_bound_key(&bound, bound_label, sizeof(bound_label));
            else snprintf(bound_label, sizeof(bound_label), "内置按键");
            ble_row(fb, l.learn_top[i], learn_names[i], bound_label);
            ui_draw_button(fb, ble_button_rect(l.learn_top[i]), "学习", false);
        }
        ui_text(fb, 48, l.footer_top, 20, "上下、左右及 PageUp / PageDown 均可翻页", EPD_DRAW_ALIGN_LEFT, false);
        ui_text(fb, 48, l.footer_top + 34, 20, "仅支持 BLE 翻页器，按键只在阅读时生效", EPD_DRAW_ALIGN_LEFT, false);
        ui_fill_rect_fast((EpdRect){0, 0, UI_LOCK_WIDTH, 190}, UI_GRAY_WHITE, fb);
        ui_nav_status(fb);
        back_header(fb, "蓝牙翻页器");
        settings_navigation(fb);
        return;
    }
    const int profile_y=180-s_main_scroll, profile_h=settings_profile_height();
    if (profile_y+profile_h>160) {
        settings_card(fb,(EpdRect){36,profile_y,612,profile_h},24,UI_GRAY_WHITE,0x70);
        int avatar_y=profile_y+(profile_h-82)/2;
        bool avatar_ok=s_avatar_ready;
        if (avatar_ok) ui_wallpaper_draw_avatar(fb,s_avatar_pixels,(EpdRect){57,avatar_y,82,82},20);
        if (!avatar_ok) {
            ui_fill_round_rect(fb,(EpdRect){57,avatar_y,82,82},20,0x30);
            ui_text_fixed_vc(fb,98,avatar_y+41,49,"K",EPD_DRAW_ALIGN_CENTER,true);
        }
        char name[64];snprintf(name,sizeof(name),"%s",app_settings_device_name());
        int width=588-ui_text_fixed_width_px(ui_text_effective_px(20),"编辑")-188;
        while (name[0] && ui_text_fixed_width_px(ui_text_effective_px(32),name)>width) {
            size_t n=strlen(name)-1;while(n&&((unsigned char)name[n]&0xc0)==0x80)--n;name[n]=0;
        }
        ui_text_vc(fb,164,profile_y+53,32,name,EPD_DRAW_ALIGN_LEFT,false);
        ui_text_vc(fb,588,profile_y+53,20,"编辑",EPD_DRAW_ALIGN_RIGHT,false);
        ui_draw_icon(fb,625,profile_y+profile_h/2,26,UI_ICON_CHEVRON_RIGHT,UI_GRAY_BLACK);
    }
    char wifi[56];snprintf(wifi,sizeof(wifi),"%s",s_main_wifi_saved?s_main_wifi:"未配置");
    // 坚果云账号存在时不显示密码，只显示账号；未配置时给一句可操作的提示。
    // Show the account only (never the app password), or a hint when nothing is stored.
    app_cloud_config_t cloud_cfg;
    char cloud_value[APP_CLOUD_USER_MAX + 8];
    if (app_settings_cloud_configured() && app_settings_cloud_get(&cloud_cfg))
        snprintf(cloud_value,sizeof(cloud_value),"%s",cloud_cfg.user);
    else
        snprintf(cloud_value,sizeof(cloud_value),"%s","未配置");
    memset(&cloud_cfg, 0, sizeof(cloud_cfg));
    const char *connection_labels[]={"WiFi","蓝牙翻页器","日期与时间","坚果云同步"};
    const char *connection_values[]={wifi,app_settings_ble_turner()?"已开启":"已关闭","设置",cloud_value};
    const int connection_icons[]={0,1,6,20};
    setting_group(fb,SETTINGS_WIRELESS_Y-49,"连接与时间",SETTINGS_WIRELESS_Y,
                  connection_icons,connection_labels,connection_values,SETTINGS_WIRELESS_ROWS);
    char font_name[96],contrast[24],idle[24],signature[96];
    snprintf(font_name,sizeof(font_name),"%s · %u%%",system_font_label(app_settings_system_font_path()),app_settings_system_font_size());
    snprintf(contrast,sizeof(contrast),"%u%%",app_settings_system_contrast());
    unsigned minutes=app_settings_auto_lock_minutes();
    if(minutes)snprintf(idle,sizeof(idle),"%u 分钟",minutes);else strcpy(idle,"关闭");
    const char *invert_value = app_settings_inverted() ? "开启" :
        app_settings_invert_night() ? (app_settings_invert_effective() ? "夜间自动·生效中" : "夜间自动") : "关闭";
    const char *display_labels[]={"系统字体","系统对比度","主页刷新模式","首页强刷","自动休眠锁屏","关机睡眠","反色模式","中文显示"};
    const char *display_values[]={font_name,contrast,
        app_settings_main_refresh_mode()==APP_MAIN_REFRESH_FAST?"快刷":app_settings_main_refresh_mode()==APP_MAIN_REFRESH_WATER?"水波纹":"普通",
        app_settings_home_full_refresh()?"开启":"关闭",idle,app_settings_staged_shutdown()?"先浅后深":"彻底断电",
        invert_value,zh_mode_value(app_settings_zh_mode())};
    const int display_icons[]={2,7,15,11,14,9,18,19};
    setting_group(fb,SETTINGS_DISPLAY_Y-49,"显示",SETTINGS_DISPLAY_Y,
                  display_icons,display_labels,display_values,SETTINGS_DISPLAY_ROWS);
    snprintf(signature,sizeof(signature),"%s",app_settings_status_signature()[0]?app_settings_status_signature():"未设置");
    const char *personal_labels[]={"书架样式","锁屏样式","锁屏密码","状态栏签名","开机按键"};
    const char *personal_values[]={app_settings_shelf_style()==5?"列表书架":app_settings_shelf_style()==6?"液态玻璃书架":app_settings_shelf_style()==1?"深色书轨":"亚克力书架",
        app_settings_lock_style()==4?"极简时钟":app_settings_lock_style()==3?"透明书封":app_settings_lock_style()==2?"书架拼贴":app_settings_lock_style()==1?"壁纸":"阅读票根",
        lock_pin_enabled()?"已开启":"已关闭",signature,
        app_settings_wake_presses()==1?"单击开机":"双击开机"};
    const int personal_icons[]={4,5,16,10,11};
    setting_group(fb,SETTINGS_PERSONAL_Y-49,"个性化功能",SETTINGS_PERSONAL_Y,
                  personal_icons,personal_labels,personal_values,SETTINGS_PERSONAL_ROWS);
    // 「本版变更/更新说明」入口已按用户要求移除：设置里不再显示版本变更列表。
    // The "what's new" entry was removed on user request: Settings no longer shows the change list.
    const char *maintenance_labels[]={"系统升级","保存与恢复","屏幕修复","BOOT 刷机","恢复出厂设置","内存诊断"};
    const char *maintenance_values[]={"OTA / TF 卡","配置","清除条纹","电脑刷机","重置系统","各界面峰值"};
    const int maintenance_icons[]={12,8,17,13,11,21};
    setting_group(fb,SETTINGS_MAINTENANCE_Y-49,"升级和恢复",SETTINGS_MAINTENANCE_Y,
                  maintenance_icons,maintenance_labels,maintenance_values,SETTINGS_MAINTENANCE_ROWS);
    // 主列表也要有一行提示位：确认、修复结果都写在这里，不然点了没有任何回音。
    // The main list needs a notice line too: confirmation and the repair result land here, or a tap
    // would have no answer at all.
    ui_fill_rect_fast((EpdRect){0,0,UI_LOCK_WIDTH,160},UI_GRAY_WHITE,fb);
    ui_nav_status(fb);
    ui_text(fb, 36, 91, 52, "设置", EPD_DRAW_ALIGN_LEFT, false);
    if (s_notice[0]) ui_text_fixed_vc(fb, 36, 138, 20, s_notice, EPD_DRAW_ALIGN_LEFT, false);
    settings_navigation(fb);
}

static void render(app_ctx_t *ctx,uint8_t *fb) {
    render_content(ctx,fb);
    settings_navigation(fb);
}

static void settings_prepare_profile(void) {
    const char *path=app_settings_avatar_path();
    if(pico_boot_recovery()||!path[0]){ui_avatar_request("",60);s_avatar_ready=s_avatar_pending=false;s_avatar_path[0]=0;return;}
    if(strcmp(path,s_avatar_path))s_avatar_ready=false;
    snprintf(s_avatar_path,sizeof(s_avatar_path),"%s",path);
    ui_avatar_request(path,82);
    ui_avatar_state_t state=ui_avatar_poll(path,82,s_avatar_pixels);
    s_avatar_ready=state==UI_AVATAR_READY;s_avatar_pending=state==UI_AVATAR_PENDING;
}
static void on_enter(app_ctx_t *ctx) {
    (void)ctx;
    pin_setup_close();
    s_notice[0] = 0;
    s_ble_feedback[0] = 0;
    s_page = SETTINGS_MAIN;
    s_style_scroll = s_main_scroll = s_font_page = s_wallpaper_page = 0;
    s_notes_page = 0;
    s_collage_prepare_pending = false;
    s_scroll_drag_consumed = s_scroll_present_pending = false;
    s_wallpaper_selected = -1;
    s_bookmark_picker=false;bookmark_preview_release();
    s_wallpaper_confirm = s_wallpaper_preview_ok = false;
    s_sync_pending = false;
    s_font_sync_confirm = false; s_font_sync_path[0] = 0;
    s_config_confirm = false;
    s_panel_repair_pending = false;
    s_boot_pending = s_local_pending = s_upgrade_restart = false;
    s_upgrade_offer_pending = s_upgrade_confirm = false;
    (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved);
    // 每次进入设置给空闲预热一次机会；字体目录缓存跨页保留，图片列表由媒体事件作废。
    // Give the idle warm-up one chance per visit; the font catalogue cache survives page switches
    // while the picture list is invalidated by media events.
    s_media_warm_done = false;
    s_warm_idle_ms = -1;
    settings_prepare_profile();
}

// 主循环主动消费按键；识别不需要再触摸屏幕。/ Consume key edges on ticks without requiring another touch.
static bool ble_receive_feedback(void) {
    ble_pt_event_t unused;
    while (ble_pt_pop_key(&unused)) {}
    bool changed = false;
    ble_pt_raw_t raw;
    while (ble_pt_pop_raw(&raw)) {
        if (!raw.pressed || !ble_pt_connected()) continue;
        if (s_ble_learning) {
            const ble_pt_action_t action = s_ble_learning == 1 ? BLE_PT_ACTION_PREV : BLE_PT_ACTION_NEXT;
            const esp_err_t error = ble_pt_bind(action, &raw.frame);
            snprintf(s_ble_feedback, sizeof(s_ble_feedback), "%s",
                     error == ESP_OK ? (action == BLE_PT_ACTION_PREV ? "识别成功 · 已绑定上一页" : "识别成功 · 已绑定下一页")
                                     : "识别成功 · 绑定保存失败，请重试");
            s_ble_learning = 0;
            s_ble_scroll = 0;
            changed = true;
            // 同一帧的其余字节不得覆盖这次学习结果。/ Drain remaining bytes without overwriting this learned result.
            while (ble_pt_pop_raw(&raw)) {}
            break;
        }
        if (!s_ble_feedback[0]) {
            snprintf(s_ble_feedback, sizeof(s_ble_feedback), "识别成功 · 已收到翻页器按键");
            s_ble_scroll = 0;
            changed = true;
        }
    }
    return changed;
}

// 启动蓝牙前归还可重建缓存（与 OTA/坚果云同级）：所有槽位的字形缓存合计最大 1.5 MB、
// 内建界面字形位图最大 512 KB、首页表盘池最大 763 KB，这些平时常驻 PSRAM，会把蓝牙启动
// 门槛里的 PSRAM/内部余量挤到线下，报成"内存不足"。它们都按需重建，不影响界面。
// Return rebuildable caches before starting Bluetooth (same level as OTA/cloud sync): the glyph
// caches of all slots (up to 1.5 MB), built-in UI glyph bitmaps (up to 512 KB) and Home's clock
// pool (up to 763 KB) stay resident in PSRAM and can push the BLE start gate below its floors,
// which then reads as "out of memory". All of them rebuild on demand, so the UI is unaffected.
static void ble_release_rebuildable_caches(void) {
    (void)ttf_font_cache_clear_all();
    ui_font_cache_clear();
    app_home_release_clock_cache();
}

// 扫描页的重试节拍：栈异步启动（2 秒防抖 + NimBLE 初始化）或旧连接还没拆完时，单次
// ble_pt_scan_start() 会被拒绝；以前页面就永远停在"扫描已停止"。这里每 1 秒补一次，
// 栈就绪后真正开始扫描。
// Scan-page retry cadence: while the stack starts asynchronously (2 s debounce plus NimBLE init)
// or an old link is still being torn down, a one-shot ble_pt_scan_start() is refused, and the page
// used to sit on "scan stopped" forever. Retry once per second and start once it is allowed.
static void ble_scan_retry_tick(uint32_t now_ms) {
    if (!app_settings_ble_turner() || ble_pt_scanning()) return;
    if (s_ble_scan_retry_ms && now_ms - s_ble_scan_retry_ms < 1000) return;
    s_ble_scan_retry_ms = now_ms ? now_ms : 1;
    ble_pt_scan_start(BLE_PT_SCAN_FOREVER);
}

static app_redraw_t profile_editor_paint(app_ctx_t *ctx, bool field);
static app_redraw_t reset_tick(void) {
    s_reset_pending=false;
    read_pico_transfer_status_t state;read_pico_transfer_get_status(&state);
    esp_err_t error=ESP_ERR_INVALID_STATE;
    if(!pico_online_busy() && state.state!=READ_PICO_TRANSFER_UPLOADING &&
       book_cover_jobs_quiesce(2000) && ui_avatar_quiesce(2000)) {
        ble_pt_cancel_recent();
        error=ble_pt_stop(2000);
        if(error==ESP_OK) {
            read_pico_transfer_stop();
            error=app_factory_reset();
        }
    }
    if(error==ESP_OK) {esp_restart();return APP_REDRAW_NONE;}
    s_reset_confirm=false;
    snprintf(s_reset_notice,sizeof(s_reset_notice),"恢复未完成，请稍后重试：%s",esp_err_to_name(error));
    return APP_REDRAW_PAGE;
}

static app_redraw_t on_tick(app_ctx_t *ctx) {
    // 屏幕修复：先画最终结果，再在 tick 中整屏恢复；成功后不重复推页。
    // Paint the final notice before the tick's full restoration; do not push the page twice on success.
    if (s_panel_repair_pending) {
        s_panel_repair_pending = false;
        if (s_page != SETTINGS_MAIN) return APP_REDRAW_NONE;
        s_scroll_present_pending = false;
        snprintf(s_notice, sizeof(s_notice), "屏幕修复完成；若条纹仍在可再做一次");
        render(ctx, ctx->fb);
        if (display_panel_repair(ctx->hl) != EPD_DRAW_SUCCESS) {
            snprintf(s_notice, sizeof(s_notice), "屏幕输出未完成，请稍后重试");
            return APP_REDRAW_FULL;
        }
        return APP_REDRAW_DONE;
    }

    // 设置主页空闲预热：静止 0.8s 后分两轮把字体目录、图片列表读进缓存，进入字体/头像/
    // 壁纸页时不再扫卡；触摸会重置计时，两轮之间也不会一次阻塞太久。
    // Idle warm-up on the settings root: after 0.8 s still, read the font catalogue and then the
    // picture list into their caches so the font, avatar and wallpaper pages open without a card
    // scan; touch resets the timer and the two scans are split across ticks.
    if (s_page == SETTINGS_MAIN) {
        if (ctx->touch && ctx->touch->touched) {
            s_warm_idle_ms = -1;
        } else {
            if (s_warm_idle_ms < 0 || ctx->now_ms < s_warm_idle_ms) s_warm_idle_ms = ctx->now_ms;
            if (!s_media_warm_done && ctx->now_ms - s_warm_idle_ms >= 800) {
                if (!s_font_catalog_warmed) {
                    if (ttf_font_count() == 0) ttf_font_scan();
                    s_font_catalog_warmed = true;
                    s_warm_idle_ms = ctx->now_ms;  // 下一轮空闲再扫图片列表 / scan pictures next idle round
                } else {
                    if (s_wallpaper_count == 0) wallpaper_ensure(false);
                    s_media_warm_done = true;
                }
            }
        }
    }

    if (s_page==SETTINGS_MAIN && s_avatar_pending && !(ctx->touch && ctx->touch->touched)) {
        ui_avatar_state_t state=ui_avatar_poll(s_avatar_path,82,s_avatar_pixels);
        s_avatar_pending=state==UI_AVATAR_PENDING;
        s_avatar_ready=state==UI_AVATAR_READY;
        if (s_avatar_ready && s_main_scroll < 180+settings_profile_height()-160) {
            render(ctx,ctx->fb);
            EpdRect area={57,180-s_main_scroll+(settings_profile_height()-82)/2,82,82};
            if (area.y<160) { area.height-=160-area.y; area.y=160; }
            if(area.height>0)guard_draw_result(ctx->hl,update_display_area_diff_with(ctx->hl,
                app_settings_main_refresh_mode()==APP_MAIN_REFRESH_NORMAL?display_main_normal_waveform():display_main_gray_waveform(),MODE_GL16,area));
            return APP_REDRAW_DONE;
        }
    }
    if(s_reset_pending && s_page==SETTINGS_FACTORY_RESET)return reset_tick();
    if (s_page == SETTINGS_PIN_ENTRY) return pin_setup_tick(ctx);
    if (s_collage_prepare_pending && s_page == SETTINGS_LOCK_STYLE) {
        s_collage_prepare_pending = false;
        // 先让选中反馈可见，再生成卡上缓存；render 本身只绘图。
        // Show selection feedback first, then prepare the SD cache; render stays paint-only.
        const size_t bytes = UI_LOCK_WIDTH * UI_LOCK_HEIGHT / 2u;
        size_t available = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        uint8_t *preview = available > bytes + 1024u * 1024u
            ? heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) : NULL;
        if (preview) {
            app_lock_font_t saved;
            app_font_begin_lock(&saved);
            (void)book_lock_collage_draw(preview);
            app_font_end_lock(&saved);
            free(preview);
        }
        return APP_REDRAW_NONE;
    }

    if (s_page == SETTINGS_TEXT_EDIT) {
        if (ctx->consumed) return APP_REDRAW_NONE;
        bool held = !ctx->released && ctx->touch && ctx->touch->touched && ctx->touch->count == 1;
        if (ui_keyboard_hold_tick(held, ctx->touch ? ctx->touch->x : 0,
            ctx->touch ? ctx->touch->y : 0, ctx->now_ms) == UI_KEYBOARD_CHANGED) return profile_editor_paint(ctx, false);
        return ui_keyboard_idle_tick(ctx->touch && ctx->touch->touched, ctx->now_ms) == UI_KEYBOARD_CHANGED
            ? profile_editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_BLUETOOTH && ble_receive_feedback()) return APP_REDRAW_PAGE;
    // 蓝牙启动失败的原因转成提示。放在这里而不是 render()：render 必须是纯绘制，
    // 而 take_* 会清空状态。
    // Fold a Bluetooth start failure into the notice here rather than in render(), which must
    // stay pure, and because take_* clears the state.
    // 蓝牙页要跟着栈的状态重绘：开关拨开后栈是异步起来的，配对表、扫描结果和连接状态
    // 都在页面画完以后才变。不重绘的话用户看到的永远是进页那一刻的快照，只能退出去再进来。
    // The Bluetooth pages redraw with the stack: enabling it starts it asynchronously, and the
    // bond list, scan results and link state all change after the page was painted. Without a
    // poll the user only ever sees the snapshot from when they entered, and has to leave and
    // come back.
    if (s_page == SETTINGS_BLUETOOTH || s_page == SETTINGS_BLE_SCAN) {
        static uint32_t ble_seen;
        const uint32_t sig = (app_settings_ble_turner() ? 1u : 0u) | (ble_pt_running() ? 2u : 0u) |
                             (ble_pt_connected() ? 4u : 0u) | (ble_pt_connecting() ? 8u : 0u) |
                             (ble_pt_scanning() ? 16u : 0u) |
                             ((uint32_t)ble_pt_bond_count() << 8) |
                             ((uint32_t)ble_scan_visible_count() << 16);
        if (sig != ble_seen) {
            ble_seen = sig;
            return APP_REDRAW_PAGE;
        }
    }
    if (s_page == SETTINGS_BLUETOOTH || s_page == SETTINGS_BLE_SCAN) {
        // 扫描页也要显示启动失败原因：以前只有二级页取这条提示，用户停在扫描页时永远看不到
        // "内存不足",只看到"扫描已停止"。同时在这里补扫描重试。
        // The scan page shows the start-failure reason too: only level two used to take this
        // notice, so a user sitting on the scan page never saw "out of memory", just "scan stopped".
        // Retrying the scan also happens here.
        if (s_page == SETTINGS_BLE_SCAN) ble_scan_retry_tick((uint32_t)ctx->now_ms);
        if (!s_ble_notice[0]) {
            char why[64];
            if (ble_pt_take_start_failure(why, sizeof(why))) {
                snprintf(s_ble_notice, sizeof(s_ble_notice), "%s", why);
                return APP_REDRAW_PAGE;
            }
        }
    }

    (void)ctx;
    if (s_boot_pending) {
        s_boot_pending = false;
        pmu_selftest_prepare_powerdown();
        uint8_t req[2] = {0, 0};
        esp_err_t error = read_pico_pmu_cmd(PMU_CMD_HOST_REQUEST_RESET, req, sizeof(req));
        if (error != ESP_OK) ESP_LOGW(TAG, "BOOT PMU notice: %s", esp_err_to_name(error));
        REG_WRITE(RTC_CNTL_OPTION1_REG, RTC_CNTL_FORCE_DOWNLOAD_BOOT);
        esp_restart(); return APP_REDRAW_NONE;
    }
    if (s_upgrade_restart) { s_upgrade_restart = false; esp_restart(); return APP_REDRAW_NONE; }
    if (s_page == SETTINGS_UPGRADE) {
        if (s_upgrade_job != UPGRADE_JOB_NONE) return upgrade_start_pending();
        if (s_local_pending) {
            s_local_pending = false;
            esp_err_t error = pico_ota_install(PICO_OTA_UPDATE_PATH, s_upgrade_notice, sizeof(s_upgrade_notice));
            s_upgrade_restart = error == ESP_OK;
            return APP_REDRAW_PAGE;
        }
        pico_online_get_status(&s_update);
        if (s_update.state == PICO_UPDATE_READY && !s_update.busy) {
            if (pico_online_commit() == ESP_OK) { esp_restart(); return APP_REDRAW_NONE; }
            pico_online_get_status(&s_update);
        }
        uint32_t now = esp_timer_get_time() / 1000;
        app_redraw_t redraw = upgrade_status_redraw(now);
        if (redraw == APP_REDRAW_AREA) draw_upgrade_progress_delta(ctx->fb);
        return redraw;
    }
    if (!s_sync_pending) return APP_REDRAW_NONE;
    s_sync_pending = false;
    uint32_t utc = 0;
    read_pico_transfer_status_t network = {0};
    read_pico_transfer_get_status(&network);
    esp_err_t err = read_pico_transfer_sync_time(&utc);
    bool network_time_received = err == ESP_OK;
    if (network_time_received) {
        // 临时 WiFi 收尾可能耗时；写入 PMU 时取当前 S3 时间，避免回写旧秒数。
        // Temporary WiFi teardown takes time; seed the PMU from the current S3 clock.
        utc = (uint32_t)time(NULL);
        uint8_t payload[4] = {(uint8_t)utc, (uint8_t)(utc >> 8), (uint8_t)(utc >> 16), (uint8_t)(utc >> 24)};
        err = read_pico_pmu_cmd(PMU_CMD_TIME_SYNC, payload, sizeof(payload));
        if (err == ESP_OK) err = read_pico_pmu_cmd(PMU_CMD_TIME_GET, NULL, 0);
        if (err == ESP_OK) {
            const pmu_snapshot_t *pmu = read_pico_pmu_get();
            if (!pmu || !pmu->time_synced || pmu->unix_sec < utc || pmu->unix_sec - utc > 10)
                err = ESP_ERR_INVALID_RESPONSE;
        }
    }
    ESP_LOGI(TAG, "time sync network=%d ready=%d utc=%lu result=%s",
             network.mode, network.network_ready, (unsigned long)utc, esp_err_to_name(err));
    const char *notice = err == ESP_OK ? "WiFi 对时完成，内部时钟已接管" :
        network_time_received ? "已获取网络时间，内部时钟写入失败" :
        err == ESP_ERR_NOT_FOUND ? "请先在 WiFi 设置中配置网络" :
        err == ESP_ERR_INVALID_STATE ? "WiFi 尚未连接，请稍后再试" :
        err == ESP_ERR_TIMEOUT ? "网络对时超时，请检查网络后重试" :
        "网络对时失败，请检查网络后重试";
    snprintf(s_notice, sizeof(s_notice), "%s", notice);
    return APP_REDRAW_PAGE;
}

static EpdRect s_input_area;
static bool s_input_layout, s_input_settle;
static app_redraw_t profile_editor_paint(app_ctx_t *ctx, bool field) {
    ui_keyboard_update_t update = ui_keyboard_update(ctx->fb, UI_SYSTEM_KEYBOARD_TOP, (EpdRect){36, 243, 612, 82}, 28, false, NULL, field);
    s_input_area = update.area; s_input_layout = update.layout; s_input_settle = update.settle;
    return update.area.width ? APP_REDRAW_AREA : APP_REDRAW_NONE;
}
static app_redraw_t profile_editor_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (ev->type == UI_GESTURE_PRESS)
        return ui_keyboard_press(ev->x0, ev->y0, UI_SYSTEM_KEYBOARD_TOP, ctx->now_ms) ? profile_editor_paint(ctx, false) : APP_REDRAW_NONE;
    bool feedback = ev->type != UI_GESTURE_LONG_PRESS && ui_keyboard_release();
    if (ev->type == UI_GESTURE_SWIPE_L || ev->type == UI_GESTURE_SWIPE_R) {
        bool page = ui_keyboard_page(ev->type == UI_GESTURE_SWIPE_L ? 1 : -1);
        return (page || feedback) ? profile_editor_paint(ctx, false) : APP_REDRAW_NONE;
    }
    if (ev->type != UI_GESTURE_TAP) return feedback ? profile_editor_paint(ctx, false) : APP_REDRAW_NONE;
    int x = ev->x0, y = ev->y0;
    if (y < 160) {
        if (x < 160) { ui_keyboard_end(); s_page = s_editor_signature ? SETTINGS_MAIN : SETTINGS_PROFILE; return APP_REDRAW_PAGE; }
        if (x > 510) goto save_text;
    }
    if (ui_text_input_tap(&s_editor_input, (EpdRect){36, 243, 612, 82}, 28,
                          false, NULL, x, y)) return profile_editor_paint(ctx, true);
    ui_keyboard_result_t result = ui_keyboard_tap(x, y, UI_SYSTEM_KEYBOARD_TOP, esp_timer_get_time() / 1000);
    if (result == UI_KEYBOARD_DONE) goto save_text;
    return result == UI_KEYBOARD_CHANGED ? profile_editor_paint(ctx, false) : APP_REDRAW_NONE;
save_text:
    if (ui_keyboard_pending()) {
        snprintf(s_editor_notice, sizeof(s_editor_notice), "请先选择候选字");
        return APP_REDRAW_PAGE;
    }
    if (s_editor_signature) app_settings_set_status_signature(s_editor);
    else if (s_editor[0]) app_settings_set_device_name(s_editor);
    else { snprintf(s_editor_notice, sizeof(s_editor_notice), "设备名称不能为空"); return APP_REDRAW_PAGE; }
    const char *saved = s_editor_signature ? app_settings_status_signature() : app_settings_device_name();
    if (strcmp(saved, s_editor)) {
        snprintf(s_editor_notice, sizeof(s_editor_notice), "保存失败，请检查设置存储空间");
        return APP_REDRAW_PAGE;
    }
    ui_keyboard_end();
    s_page = s_editor_signature ? SETTINGS_MAIN : SETTINGS_PROFILE;
    return APP_REDRAW_PAGE;
}

// 越过阈值按段推进，一次手势只更新一次，松手不再播放惯性。
// Advance one discrete step after crossing the threshold, with one update per gesture and no release inertia.
static app_redraw_t scroll_gesture(const ui_gesture_event_t *ev, int *offset, int limit, bool *handled) {
    *handled = ev->type != UI_GESTURE_TAP || s_scroll_drag_consumed;
    if (ev->type == UI_GESTURE_PRESS) {
        s_scroll_drag_consumed = false;
        return APP_REDRAW_NONE;
    }
    if (ev->type == UI_GESTURE_TAP || ev->type == UI_GESTURE_CANCEL) {
        s_scroll_drag_consumed = false;
        return APP_REDRAW_NONE;
    }
    if (ev->type != UI_GESTURE_MOVE && ev->type != UI_GESTURE_SWIPE_U && ev->type != UI_GESTURE_SWIPE_D)
        return APP_REDRAW_NONE;
    if (ev->y0 < (s_page == SETTINGS_MAIN ? 160 : 190) || ev->y0 >= settings_viewport_end())
        return APP_REDRAW_NONE;
    if (s_scroll_drag_consumed) {
        if (ev->type != UI_GESTURE_MOVE) s_scroll_drag_consumed = false;
        return APP_REDRAW_NONE;
    }
    int dy = (int)ev->y - ev->y0, dx = (int)ev->x - ev->x0;
    int distance = abs(dy);
    if (ev->type == UI_GESTURE_MOVE && (distance < 108 || distance <= abs(dx))) return APP_REDRAW_NONE;
    int step = distance < 204 ? 204 : distance > 450 ? 450 : distance;
    bool up = ev->type == UI_GESTURE_SWIPE_U || (ev->type == UI_GESTURE_MOVE && dy < 0);
    int next = *offset + (up ? step : -step);
    if (limit < 0) limit = 0;
    if (next < 0) next = 0;
    if (next > limit) next = limit;
    if (ev->type == UI_GESTURE_MOVE) s_scroll_drag_consumed = true;
    if (next == *offset) return APP_REDRAW_NONE;
    *offset = next;
    s_scroll_present_pending = true;
    return APP_REDRAW_AREA;
}

static app_redraw_t reset_gesture(app_ctx_t *ctx,const ui_gesture_event_t *ev) {
    if(ev->type!=UI_GESTURE_TAP || s_reset_pending)return APP_REDRAW_NONE;
    int tab=settings_nav_hit(ev->x0,ev->y0);
    if(tab>=0){s_reset_confirm=false;ui_nav_request(ctx,tab);return APP_REDRAW_NONE;}
    if((ev->y0<190 && ev->x0<170)||ui_rect_hit((EpdRect){54,950,576,78},ev->x0,ev->y0)) {
        s_reset_confirm=false;s_page=SETTINGS_MAIN;return APP_REDRAW_PAGE;
    }
    if(ui_rect_hit((EpdRect){54,850,576,78},ev->x0,ev->y0)) {
        s_reset_notice[0]=0;
        if(s_reset_confirm)s_reset_pending=true;
        else s_reset_confirm=true;
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t on_gesture(app_ctx_t *ctx, const ui_gesture_event_t *ev) {
    if (s_page==SETTINGS_SYSTEM_FONT && s_font_sync_confirm) {
        if (ev->type!=UI_GESTURE_TAP) return APP_REDRAW_NONE;
        for (int i=0;i<2;++i) {
            if (!ui_rect_hit(system_font_sync_button(i),ev->x0,ev->y0)) continue;
            if (i) {
                app_settings_set_font_path(s_font_sync_path);
                if (strcmp(app_settings_font_path(),s_font_sync_path)) {
                    snprintf(s_notice,sizeof(s_notice),"保存失败，请重试");return APP_REDRAW_PAGE;
                }
            }
            s_notice[0]=0;s_font_sync_confirm=false;return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_PIN_ENTRY) {
        EpdRect dirty; ui_pin_result_t result = ui_pinpad_handle(&s_pinpad, ev, &dirty);
        if (result == UI_PIN_CANCEL) { pin_setup_close(); s_page = SETTINGS_LOCK_PIN; return APP_REDRAW_PAGE; }
        if (result == UI_PIN_COMPLETE) s_pin_pending = true;
        if (result == UI_PIN_NONE) return APP_REDRAW_NONE;
        ui_pinpad_paint_input(ctx->fb, &s_pinpad);
        guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl, &E0470_FOLLOW_WAVEFORM, MODE_DU, dirty));
        return APP_REDRAW_DONE;
    }
    if (s_page == SETTINGS_LOCK_PIN && ev->type == UI_GESTURE_TAP && lock_pin_available() &&
        (ui_rect_hit((EpdRect){36,406,612,70},ev->x0,ev->y0) ||
         (lock_pin_enabled() && ui_rect_hit((EpdRect){36,512,612,70},ev->x0,ev->y0)))) {
        if (ctx->now_ms < s_pin_retry_at) { snprintf(s_notice, sizeof(s_notice), "请等待后重试"); return APP_REDRAW_PAGE; }
        pin_setup_open(ctx, ev->y0 >= 512); return APP_REDRAW_PAGE;
    }

    if (s_page == SETTINGS_BOOT) {
        if (ev->type != UI_GESTURE_TAP || s_boot_pending) return APP_REDRAW_NONE;
        if (ev->y0 < 190 && ev->x0 < 170) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
        if (ui_rect_hit((EpdRect){60, 438, 564, 78}, ev->x0, ev->y0)) { s_boot_pending = true; return APP_REDRAW_PAGE; }
        int tab = settings_nav_hit(ev->x0, ev->y0);
        if (tab >= 0) ui_nav_request(ctx, tab);
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_UPGRADE_NOTES) {
        const int pages = upgrade_notes_pages();
        if (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D) {
            if (ev->type == UI_GESTURE_SWIPE_U && (int)s_notes_page + 1 < pages) {
                ++s_notes_page;
                return APP_REDRAW_PAGE;
            }
            if (ev->type == UI_GESTURE_SWIPE_D && s_notes_page > 0) {
                --s_notes_page;
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
        if (ev->y0 < 190 && ev->x0 < 170) { s_page = SETTINGS_MAIN; return APP_REDRAW_PAGE; }
        // 底部页码：左半区上一页、右半区下一页，点按和上下滑动都能翻。
        // Page footer: left half goes back a page, right half forward; swipes work as well.
        if (ev->y0 >= 900) {
            if (ev->x0 < 342 && s_notes_page > 0) {
                --s_notes_page;
                return APP_REDRAW_PAGE;
            }
            if (ev->x0 >= 342 && (int)s_notes_page + 1 < pages) {
                ++s_notes_page;
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        int tab = settings_nav_hit(ev->x0, ev->y0);
        if (tab >= 0) ui_nav_request(ctx, tab);
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_RAM_DIAG) {
        if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
        // 返回沿用其它二级页的左上角返回区；底栏点按仍走主页面路由。
        // Back keeps the children's top-left zone; bottom-bar taps still route roots.
        if (ev->y0 < 190 && ev->x0 < 170) {
            s_page = SETTINGS_MAIN;
            (void)read_pico_transfer_get_saved_wifi(s_main_wifi, &s_main_wifi_saved);
            settings_prepare_profile();
            return APP_REDRAW_PAGE;
        }
        int tab = settings_nav_hit(ev->x0, ev->y0);
        if (tab >= 0) { ui_nav_request(ctx, tab); return APP_REDRAW_NONE; }
        if (ui_rect_hit((EpdRect){36, 978, 612, 74}, ev->x0, ev->y0)) {
            app_ram_diag_reset();
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_UPGRADE) {
        if (ev->type != UI_GESTURE_TAP || s_local_pending || s_upgrade_restart) return APP_REDRAW_NONE;
        int y = ev->y0;
        if (y < 190 && ev->x0 < 170) {
            s_upgrade_job = UPGRADE_JOB_NONE;
            s_upgrade_offer_pending = false;
            if (s_upgrade_confirm) s_upgrade_confirm = false;
            else { pico_online_cancel_join(); s_page = SETTINGS_MAIN; }
            return APP_REDRAW_PAGE;
        }
        int tab = settings_nav_hit(ev->x0, y);
        if (tab >= 0) { s_upgrade_job = UPGRADE_JOB_NONE; pico_online_cancel_join(); ui_nav_request(ctx, tab); return APP_REDRAW_NONE; }
        if (s_upgrade_confirm) {
            bool accept = ui_rect_hit(upgrade_confirm_button(s_upgrade_online, true), ev->x0, y);
            if (accept || ui_rect_hit(upgrade_confirm_button(s_upgrade_online, false), ev->x0, y)) {
                s_upgrade_confirm = false;
                s_upgrade_offer_pending = false;
                if (accept) {
                    if (s_upgrade_online) {
                        upgrade_schedule(true, esp_timer_get_time() / 1000);
                    } else s_local_pending = true;
                }
                return APP_REDRAW_PAGE;
            }
            return APP_REDRAW_NONE;
        }
        if (ev->x0 < 60 || ev->x0 >= 624) return APP_REDRAW_NONE;
        if (y >= 550 && y < 612) {
            s_upgrade_notice[0] = 0;
            if (s_update.busy) { s_upgrade_job = UPGRADE_JOB_NONE; s_upgrade_offer_pending = false; pico_online_cancel_join(); }
            else if (s_update.state == PICO_UPDATE_AVAILABLE) { s_upgrade_confirm = true; s_upgrade_online = true; }
            else {
                upgrade_schedule(false, esp_timer_get_time() / 1000);
                return APP_REDRAW_PAGE;
            }
            pico_online_get_status(&s_update);
            upgrade_remember(esp_timer_get_time() / 1000);
            return APP_REDRAW_PAGE;
        }
        if (y >= 840 && y < 902 && !s_update.busy) {
            (void)pico_ota_inspect(PICO_OTA_UPDATE_PATH, &s_local_update);
            if (s_local_update.ready) { s_upgrade_confirm = true; s_upgrade_online = false; }
            else snprintf(s_upgrade_notice, sizeof(s_upgrade_notice), "%s", s_local_update.message);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if(s_page==SETTINGS_FACTORY_RESET)return reset_gesture(ctx,ev);
    if (s_page == SETTINGS_TEXT_EDIT) return profile_editor_gesture(ctx, ev);
    if (s_page == SETTINGS_MAIN || s_page == SETTINGS_BLUETOOTH || s_page == SETTINGS_BLE_SCAN ||
        s_page == SETTINGS_SHELF_STYLE) {
        int limit = SETTINGS_SCROLL_MAX;
        int *offset = &s_main_scroll;
        if (s_page == SETTINGS_SHELF_STYLE) {
            // 四张卡片一屏放不下：滚到末张卡片底边刚好落在底栏上方。
            // Four cards do not fit one screen: scroll until the last card's bottom meets the nav band.
            limit = 263 + SHELF_STYLE_CHOICES * 253 - 23 - settings_viewport_end() + 12;
            offset = &s_style_scroll;
        } else if (s_page != SETTINGS_MAIN) {
            int bottom = s_page == SETTINGS_BLUETOOTH ? ble_layout().content_bottom + s_ble_scroll : ble_scan_layout().content_bottom;
            limit = bottom - settings_content_end() + 12;
            offset = &s_ble_scroll;
        }
        bool handled;
        app_redraw_t redraw = scroll_gesture(ev, offset, limit, &handled);
        if (handled) return redraw;
    }

    if (s_page == SETTINGS_AVATAR && (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
        int pages = (s_wallpaper_count + 6) / 7;
        int old = s_wallpaper_page;
        if (ev->type == UI_GESTURE_SWIPE_U && s_wallpaper_page + 1 < pages) ++s_wallpaper_page;
        if (ev->type == UI_GESTURE_SWIPE_D && s_wallpaper_page > 0) --s_wallpaper_page;
        if (s_wallpaper_page == old) return APP_REDRAW_NONE;
        s_scroll_present_pending = true;
        return APP_REDRAW_AREA;
    }
    if (s_page == SETTINGS_WALLPAPER_PREVIEW && !s_wallpaper_confirm &&
        (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
        int next = s_wallpaper_selected + (ev->type == UI_GESTURE_SWIPE_U ? 1 : -1);
        if (next < 0 || next >= s_wallpaper_count) return APP_REDRAW_NONE;
        s_wallpaper_selected = next;
        bookmark_preview_prepare(ctx->fb);
        s_wallpaper_page = next / 8;
        return APP_REDRAW_PAGE;
    }
    if ((s_page == SETTINGS_SYSTEM_FONT || s_page == SETTINGS_WALLPAPER) &&
        (ev->type == UI_GESTURE_SWIPE_U || ev->type == UI_GESTURE_SWIPE_D)) {
        int *page = s_page == SETTINGS_SYSTEM_FONT ? &s_font_page : &s_wallpaper_page;
        int slots=s_page==SETTINGS_SYSTEM_FONT?system_font_layout().slots:8;
        int pages;
        if (s_page == SETTINGS_SYSTEM_FONT) {
            system_font_clamp_page(slots);
            pages = system_font_pages(slots);
        } else {
            pages = s_wallpaper_count > 0 ? (s_wallpaper_count + slots - 1) / slots : 1;
        }
        int old = *page;
        if (ev->type == UI_GESTURE_SWIPE_U && *page + 1 < pages) ++*page;
        if (ev->type == UI_GESTURE_SWIPE_D && *page > 0) --*page;
        if (*page == old) return APP_REDRAW_NONE;
        s_scroll_present_pending = true;
        return APP_REDRAW_AREA;
    }
    if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
    if (s_page == SETTINGS_WALLPAPER_PREVIEW && s_wallpaper_confirm) {
        if (ev->y0 >= 643 && ev->y0 < 711 && ev->x0 >= 358 && ev->x0 < 590) {
            const char *path = s_wallpapers[s_wallpaper_selected].path;
            if(s_bookmark_picker)app_settings_set_bookmark_path(path);
            else app_settings_set_wallpaper_path(path);
            if (!strcmp(s_bookmark_picker?app_settings_bookmark_path():app_settings_wallpaper_path(), path)) {
                app_settings_set_lock_style(s_bookmark_picker?3:1);
                s_page = SETTINGS_LOCK_STYLE;
                bookmark_preview_release();
            }
        }
        s_wallpaper_confirm = false;
        return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_TIME_EDIT) {
        if (ev->y0 < 190) { s_page = SETTINGS_TIME; return APP_REDRAW_PAGE; }
        if (ev->y0 >= 354 && ev->y0 < 597) {
            int field = (ev->x0 - 36) / 122;
            if (ev->x0 >= 36 && field >= 0 && field < 5 && (ev->x0 - 36) % 122 < 106) {
                if (ev->y0 < 416) time_adjust(field, 1);
                else if (ev->y0 >= 535) time_adjust(field, -1);
                else return APP_REDRAW_NONE;
                return APP_REDRAW_PAGE;
            }
        }
        if (ev->y0 >= 767 && ev->y0 < 845) {
            const bool saved = time_save();
            // 手动改时间可能正好跨过 21:00/07:00：保存后立刻按新时间重核夜间自动反色。
            // A manual clock change may cross the 21:00/07:00 boundary; re-check inversion at once.
            if (saved) {
                const bool want = app_settings_invert_effective();
                if (epd_get_inverted() != want) {
                    display_set_inverted(ctx->hl, want);
                    return APP_REDRAW_FULL;
                }
            }
            return APP_REDRAW_PAGE;
        }
        if (ev->y0 >= 874 && ev->y0 < 952) { s_page = SETTINGS_TIME; return APP_REDRAW_PAGE; }
        return APP_REDRAW_NONE;
    }
    int tab = settings_nav_hit(ev->x0, ev->y0);
    if (tab >= 0) { ui_nav_request(ctx, tab); return APP_REDRAW_NONE; }
    int y = ev->y0;
    if (s_page == SETTINGS_PROFILE) {
        if (y < 190) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
        if (y >= 266 && y < 350) { profile_editor_open(false); return APP_REDRAW_PAGE; }
        if (y >= 366 && y < 450) { wallpaper_ensure(false); s_page = SETTINGS_AVATAR; return APP_REDRAW_PAGE; }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_AVATAR) {
        if (y < 190) { s_page = SETTINGS_PROFILE; return APP_REDRAW_PAGE; }
        if (y >= 270 && y < 354) { app_settings_set_avatar_path(""); s_page = SETTINGS_PROFILE; return APP_REDRAW_PAGE; }
        if (y >= 374 && y < 1046) {
            int i = (y - 374) / 96, index = s_wallpaper_page * 7 + i;
            if (index >= 0 && index < s_wallpaper_count && (y - 374) % 96 < 80) {
                app_settings_set_avatar_path(s_wallpapers[index].path);
                s_page = SETTINGS_PROFILE;
                return APP_REDRAW_PAGE;
            }
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_WALLPAPER_PREVIEW) {
        if (y < 190) { bookmark_preview_release(); s_page = SETTINGS_WALLPAPER; return APP_REDRAW_PAGE; }
        if (s_wallpaper_preview_ok && y >= 194 && y < 1032) {
            s_wallpaper_confirm = true;
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_WALLPAPER && y < 190) {
        s_page = SETTINGS_LOCK_STYLE;
        return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_SHELF_STYLE) {
        if (y < 190) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
        for (int i = 0; i < SHELF_STYLE_CHOICES; ++i) {
            // 题头白带内的点按不算选项；横向也限定卡片范围。/ Taps in the header band are not choices; x is clamped to the card too.
            if (y >= 242 && y >= 263 + i * 253 - s_style_scroll && y < 493 + i * 253 - s_style_scroll &&
                y < settings_viewport_end() && ev->x0 >= 36 && ev->x0 < 648) {
                app_settings_set_shelf_style(s_shelf_style_ids[i]);
                s_page = SETTINGS_MAIN;
                return APP_REDRAW_PAGE;
            }
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_BLE_SCAN && y < 190) {
        ble_pt_scan_stop(); s_page = SETTINGS_BLUETOOTH; s_ble_scroll = 0; return APP_REDRAW_PAGE;
    }
    if (s_page != SETTINGS_MAIN && y < 190) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_LOCK_PIN) return APP_REDRAW_NONE;
    if (s_page == SETTINGS_AUTO_LOCK) {
        const uint8_t values[] = {1, 5, 10, 0};
        for (int i = 0; i < 4; ++i) if (ui_rect_hit((EpdRect){36, 272 + i * 112, 612, 92}, ev->x0, y)) {
            app_settings_set_auto_lock_minutes(values[i]);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }

    if (s_page == SETTINGS_WIFI) {
        if (y >= 408 && y < 478) {
            extern const app_desc_t app_transfer;
            app_transfer_request_wifi_setup();
            ctx->request_app = &app_transfer;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_SYSTEM_FONT) {
        system_font_layout_t l=system_font_layout();
        system_font_clamp_page(l.slots);
        if (ui_rect_hit(l.size,ev->x0,y)) {
            unsigned prior=app_settings_system_font_size();
            unsigned next=prior>=200?100:prior+10;
            app_settings_set_system_font_size(next);
            if (app_settings_system_font_size()!=next) {
                snprintf(s_notice,sizeof(s_notice),"保存失败，请重试");return APP_REDRAW_PAGE;
            }
            s_font_page=0;
            if (s_main_scroll>SETTINGS_SCROLL_MAX) s_main_scroll=SETTINGS_SCROLL_MAX;
            ui_text_set_system_scale(true);s_notice[0]=0;return APP_REDRAW_PAGE;
        }
        for (int slot=0;slot<l.slots;++slot) {
            if (!ui_rect_hit(system_font_item_rect(slot),ev->x0,y)) continue;
            int index=s_font_page*l.slots+slot;
            if (index>=system_font_items()) return APP_REDRAW_NONE;
            const ttf_font_item_t *item=index?ttf_font_item(index-1):NULL;
            if (index && !item) return APP_REDRAW_NONE;
            snprintf(s_font_sync_path,sizeof(s_font_sync_path),"%s",item?item->path:"");
            app_settings_set_system_font_path(s_font_sync_path);
            if (strcmp(app_settings_system_font_path(),s_font_sync_path)) {
                snprintf(s_notice,sizeof(s_notice),"保存失败，请重试");return APP_REDRAW_PAGE;
            }
            app_font_activate_system();s_notice[0]=0;
            s_font_sync_confirm=strcmp(app_settings_font_path(),s_font_sync_path)!=0;
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_MAIN_REFRESH) {
        for (int i = 0; i < 3; ++i) {
            if (!ui_rect_hit((EpdRect){36, 298 + i * 158, 612, 132}, ev->x0, y)) continue;
            app_settings_set_main_refresh_mode((app_main_refresh_mode_t)i);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_SYSTEM_SIZE) {
        for (int index = 0; index < 11; ++index) {
            EpdRect box = {36 + (index % 2) * 316, 298 + (index / 2) * 122, 296, 102};
            if (!ui_rect_hit(box, ev->x0, y)) continue;
            app_settings_set_system_font_size((uint8_t)(100 + index * 10));
            ui_text_set_system_scale(true);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_SYSTEM_CONTRAST) {
        if (y < 298 || y >= 878) return APP_REDRAW_NONE;
        int index = (y - 298) / 116;
        app_settings_set_system_contrast((uint8_t)(100 + index * 10));
        return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_LOCK_STYLE) {
        if (y >= 300 && y < 416) {
            wallpaper_ensure(false);
            s_page = SETTINGS_WALLPAPER;
            return APP_REDRAW_PAGE;
        }
        if (y >= 428 && y < 544) {
            app_settings_set_lock_style(0);
            return APP_REDRAW_PAGE;
        }
        if (y >= 556 && y < 672) {
            app_settings_set_lock_style(2);
            s_collage_prepare_pending = true;
            return APP_REDRAW_PAGE;
        }
        if(y>=684 && y<800){
            wallpaper_ensure(true);s_page=SETTINGS_WALLPAPER;
            return APP_REDRAW_PAGE;
        }
        if(y>=812 && y<928){
            app_settings_set_lock_style(4);
            return APP_REDRAW_PAGE;
        }
        if (y >= 1010 && y < 1078 && app_settings_lock_style() == 4) {
            app_settings_set_lock_clock_landscape(!app_settings_lock_clock_landscape());
            return APP_REDRAW_PAGE;
        }
        // 方向行与「当前壁纸」行同一位置：只有确实画了壁纸行时才响应，且不超过行底分隔线。
        // The direction row and the current-wallpaper row share one slot: hit it only when that
        // row is actually painted, and never past the divider under it.
        if (y >= 1010 && y < 1078 && app_settings_wallpaper_path()[0]) {
            wallpaper_ensure(false);
            s_page = SETTINGS_WALLPAPER;
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_WALLPAPER) {
        if (y >= 1028 && y < 1078) {
            app_settings_set_lock_clock_landscape(!app_settings_lock_clock_landscape());
            return APP_REDRAW_PAGE;
        }
        if (y < 292 || y >= 1028) return APP_REDRAW_NONE;
        int index = s_wallpaper_page * 8 + (y - 292) / 92;
        if (index >= s_wallpaper_count) return APP_REDRAW_NONE;
        s_wallpaper_selected = index;
        bookmark_preview_prepare(ctx->fb);
        s_wallpaper_confirm = false;
        s_page = SETTINGS_WALLPAPER_PREVIEW;
        return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_TIME) {
        if (y >= 407 && y < 477) {
            s_notice[0] = 0; s_sync_pending = true;
            snprintf(s_notice, sizeof(s_notice), "正在获取网络时间…");
            return APP_REDRAW_PAGE;
        }
        if (y >= 518 && y < 588) { time_open(); return APP_REDRAW_PAGE; }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_POWER_SLEEP) {
        if (y >= 278 && y < 402) {
            app_settings_set_staged_shutdown(false);
            return APP_REDRAW_PAGE;
        }
        if (y >= 414 && y < 538) {
            app_settings_set_staged_shutdown(true);
            return APP_REDRAW_PAGE;
        }
        if (y >= 692 && y < 804) {
            app_settings_set_wake_presses(1);
            return APP_REDRAW_PAGE;
        }
        if (y >= 816 && y < 928) {
            app_settings_set_wake_presses(2);
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_CONFIG) {
        if (y >= 561 && y < 644) {
            s_config_confirm = false;
            esp_err_t err = app_settings_backup_save();
            snprintf(s_notice, sizeof(s_notice), "%s",
                     err == ESP_OK ? "已保存到 TF 卡根目录" :
                     err == ESP_ERR_INVALID_STATE ? "未识别到 TF 卡，请插卡后重试" :
                     "保存失败，请检查 TF 卡剩余空间");
            return APP_REDRAW_PAGE;
        }
        if (y >= 681 && y < 764) {
            if (!s_config_confirm) {
                s_config_confirm = true;
                snprintf(s_notice, sizeof(s_notice), "恢复将覆盖当前设置，请再点按一次确认");
                return APP_REDRAW_PAGE;
            }
            s_config_confirm = false;
            esp_err_t err = app_settings_backup_restore();
            if (err == ESP_OK) {
                // 恢复的设置可能换了字体目录：立即重扫一次并标记目录已预热。
                // Restored settings may point at another font directory: rescan now and mark the
                // catalogue as warm.
                ttf_font_scan();
                s_font_catalog_warmed = true;
                app_font_activate_system();
                ui_text_set_system_scale(true);
                // 阅读记录恢复后令首页和书架重新取进度、时长与排序。
                // Rebuild home and shelf caches after restoring reading records.
                book_store_notify_changed();
                // 反色与繁简是显示解释：恢复后按新设置重建基准，再整屏重刷一次。
                // Inversion and script mode are display interpretations: rebuild the baseline and full-refresh once.
                display_set_inverted(ctx->hl, app_settings_invert_effective());
                zh_convert_set_mode(app_settings_zh_mode());
                // 字体/字号/繁简已换成恢复值，首页时钟的固定预览作废。
                // The restored font, size and script invalidate Home's fixed clock previews.
                ui_home_clock_preview_invalidate();
                app_home_cover_mode_changed();
                app_book_cover_mode_changed();
                book_lock_collage_invalidate();
            }
            char saved_ssid[33] = {0};
            bool wifi_saved = false;
            if (err == ESP_OK)
                (void)read_pico_transfer_get_saved_wifi(saved_ssid, &wifi_saved);
            snprintf(s_notice, sizeof(s_notice), "%s",
                     err == ESP_OK ? (wifi_saved ? "配置与阅读记录已恢复；WiFi 请重新连接" :
                                                   "配置与阅读记录已恢复") :
                     err == ESP_ERR_INVALID_STATE ? "未识别到 TF 卡，请插卡后重试" :
                     err == ESP_ERR_NOT_FOUND ? "未找到配置备份文件" :
                     err == ESP_ERR_INVALID_RESPONSE ? "配置文件损坏或版本不兼容" :
                     "恢复未完成，请重试");
            return err == ESP_OK ? APP_REDRAW_FULL : APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_BLUETOOTH) {
        const ble_layout_t l = ble_layout();
        if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
        // 版式给的是屏幕坐标（已减去滚动量），所以这里直接用 y 比，不再加 scroll。
        // The layout yields screen coordinates (scroll already subtracted), so compare y directly.
        const int ty = y;

        // 学习时轻点取消；识别结果轻点后返回开关。/ Tap to cancel learning or dismiss the received-key result.
        if (s_ble_learning) {
            s_ble_learning = 0;
            snprintf(s_ble_notice, sizeof(s_ble_notice), "已取消学习");
            return APP_REDRAW_PAGE;
        }
        if (s_ble_feedback[0] && ty >= 202 - s_ble_scroll && ty < 328 - s_ble_scroll) {
            s_ble_feedback[0] = 0;
            return APP_REDRAW_PAGE;
        }
        if (ty < 160 || ty >= settings_viewport_end()) return APP_REDRAW_NONE;

        if (l.toggle_top >= 0 && ty >= l.toggle_top && ty < l.toggle_top + 126) {
            const bool enable = !app_settings_ble_turner();
            if (enable) {
                // 开启前沿用 OTA/坚果云同级的回收序列，让蓝牙启动门槛拿到余量；并清掉上次
                // 失败/退避——这是用户明确发起的一次新尝试，不该被旧计数挡住。
                // Reclaim like OTA/cloud sync before enabling so the BLE gate has headroom, and
                // clear the previous failure/back-off: this is an explicit new attempt.
                ble_release_rebuildable_caches();
                ble_pt_reset_failure();
            }
            app_settings_set_ble_turner(enable);
            // 明确关掉时把失败计数和原因一起清掉：否则自锁之后用户没有重试的途径。
            // Switching it off explicitly clears the failure count and reason; without this a
            // self-locked stack leaves the user no way to try again.
            if (!enable) ble_pt_reset_failure();
            snprintf(s_ble_notice, sizeof(s_ble_notice), "%s",
                     enable ? "已开启，正在启动…" : "已关闭，蓝牙内存已释放");
            return APP_REDRAW_PAGE;
        }
        if (ty >= l.scan_entry_top && ty < l.scan_entry_top + BLE_ROW_H) {
            if (!app_settings_ble_turner()) {
                snprintf(s_ble_notice, sizeof(s_ble_notice), "请先开启蓝牙翻页器");
                return APP_REDRAW_PAGE;
            }
            // 栈是异步启动的：刚拨开开关就点扫描时它可能还没跑起来，旧代码在这里直接拒绝并
            // 说"请先开启蓝牙翻页器",用户只会以为搜索失败。允许进页，由 on_tick 的节拍重试
            // 在栈就绪时自动开始扫描。
            // The stack starts asynchronously: tapping scan right after enabling used to be
            // refused with "turn Bluetooth on first", which reads as a failed search. Let the page
            // open and start scanning from the on_tick retry once the stack is up.
            ble_release_rebuildable_caches();
            if (ble_pt_connected() || ble_pt_connecting()) {
                // 本模块同一时刻只服务一个外设：要扫描新设备就先断开旧链路；断开会清掉自动
                // 重连目标，不会在扫描时把链路又拉回来。
                // The module serves one peripheral at a time: disconnect the old link first to
                // discover new devices. Disconnecting clears the auto-reconnect target, so it
                // cannot pull the link back while scanning.
                ble_pt_disconnect();
                snprintf(s_ble_notice, sizeof(s_ble_notice), "已断开当前翻页器，开始扫描");
            } else s_ble_notice[0] = 0;
            s_ble_scan_retry_ms = 0;
            s_ble_scroll = 0;
            s_page = SETTINGS_BLE_SCAN;
            ble_pt_scan_start(BLE_PT_SCAN_FOREVER);
            return APP_REDRAW_PAGE;
        }
        for (int i = 0; i < 2; ++i) {
            const EpdRect btn = ble_button_rect(l.learn_top[i]);
            // 命中判定必须同时比 x：按钮的纵向范围几乎覆盖整行，只比 y 会让整行都算按钮。
            // The hit test needs the horizontal test too: the button's vertical span covers almost
            // the whole row, so comparing y alone makes the entire row count as the button.
            if (ev->x0 >= btn.x && ev->x0 < btn.x + btn.width && ty >= btn.y && ty < btn.y + btn.height) {
                if (!ble_pt_connected()) {
                    snprintf(s_ble_notice, sizeof(s_ble_notice), "请先连接翻页器再学习按键");
                    return APP_REDRAW_PAGE;
                }
                ble_pt_raw_t stale;
                while (ble_pt_pop_raw(&stale)) {}
                // 把此刻那一帧当基准：点「学习」时用户还没按键，外设发的就是静止帧。有些遥控器
                // 的静止帧带着非零常量，不这样标一下，那串常量会被当成一次按下学进去。
                // Pin the frame present now as the baseline: the user has not pressed yet, so what the
                // remote sends is its resting frame. Some remotes keep non-zero constants there, and
                // without this the constants get learned as if they were a press.
                ble_pt_learn_begin();
                s_ble_feedback[0] = s_ble_notice[0] = 0;
                s_ble_learning = i + 1;
                s_ble_scroll = 0;
                return APP_REDRAW_PAGE;
            }
        }
        // 已配对行：右侧按钮忘记，行本身连接。/ Bonded rows: the button forgets, the row connects.
        for (int i = 0; i < l.bond_rows && i < BLE_PT_MAX_BONDS; ++i) {
            const ble_pt_bond_t *bond = ble_pt_bond((uint8_t)i);
            if (!bond) continue;
            const EpdRect btn = ble_button_rect(l.bond_top[i]);
            if (ev->x0 >= btn.x && ev->x0 < btn.x + btn.width && ty >= btn.y && ty < btn.y + btn.height) {
                if (ble_pt_connected()) ble_pt_disconnect();
                ble_pt_forget(bond->addr);
                snprintf(s_ble_notice, sizeof(s_ble_notice), "已删除该配对");
                return APP_REDRAW_PAGE;
            }
            if (ty >= l.bond_top[i] && ty < l.bond_top[i] + BLE_ROW_H) {
                if (ble_pt_connected() || ble_pt_connecting()) ble_pt_disconnect();
                snprintf(s_ble_notice, sizeof(s_ble_notice),
                         ble_pt_connect(bond->addr) == ESP_OK ? "正在连接…" : "连接失败，请重试");
                return APP_REDRAW_PAGE;
            }
        }
        return APP_REDRAW_NONE;
    }
    if (s_page == SETTINGS_BLE_SCAN) {
        const ble_scan_layout_t l = ble_scan_layout();
        if (ev->type != UI_GESTURE_TAP) return APP_REDRAW_NONE;
        if (y < 160 || y >= settings_viewport_end()) return APP_REDRAW_NONE;
        const int ty = y + s_ble_scroll;
        // 选一台就连，连上后退回二级页。扫描在离页时停。
        // Picking one connects, then returns to level two; scanning stops on the way out.
        for (int i = 0; i < l.device_rows; ++i) {
            const ble_pt_device_t *dev = ble_scan_visible_at(i);
            if (!dev) continue;
            const int top = l.devices_top + i * BLE_ROW_H;
            if (ty < top || ty >= top + BLE_ROW_H) continue;
            ble_pt_scan_stop();
            if (ble_pt_connected() || ble_pt_connecting()) ble_pt_disconnect();
            snprintf(s_ble_notice, sizeof(s_ble_notice),
                     ble_pt_connect(dev->addr) == ESP_OK ? "正在连接…" : "连接失败，请重试");
            s_page = SETTINGS_BLUETOOTH;
            s_ble_scroll = 0;
            return APP_REDRAW_PAGE;
        }
        return APP_REDRAW_NONE;
    }
    if (y<160 || y>=UI_NAV_TOP || ev->x0<36 || ev->x0>=648) return APP_REDRAW_NONE;
    y+=s_main_scroll;
    if (y>=180 && y<180+settings_profile_height()) { s_page=SETTINGS_PROFILE;return APP_REDRAW_PAGE; }
    int row;
    if (y>=SETTINGS_WIRELESS_Y && y<SETTINGS_WIRELESS_Y+SETTINGS_WIRELESS_ROWS*SETTINGS_ROW_H) {
        row=(y-SETTINGS_WIRELESS_Y)/SETTINGS_ROW_H;
        if(row==0) {
            extern const app_desc_t app_transfer;app_transfer_request_wifi_setup();ctx->request_app=&app_transfer;return APP_REDRAW_NONE;
        }
        if(row==1) {
            s_page=SETTINGS_BLUETOOTH;s_ble_scroll=s_ble_learning=0;s_ble_notice[0]=s_ble_feedback[0]=0;
            ble_pt_raw_t unused;while(ble_pt_pop_raw(&unused)){}return APP_REDRAW_PAGE;
        }
        if(row==3) {
            // 坚果云同步是独立页面：切过去，返回键回到设置主页。
            // The sync page is a separate app; back returns to this settings root.
            extern const app_desc_t app_cloud;
            s_notice[0]=0;
            ctx->request_app=&app_cloud;
            return APP_REDRAW_NONE;
        }
        s_page=SETTINGS_TIME;return APP_REDRAW_PAGE;
    }
    if(y>=SETTINGS_DISPLAY_Y && y<SETTINGS_DISPLAY_Y+SETTINGS_DISPLAY_ROWS*SETTINGS_ROW_H) {
        row=(y-SETTINGS_DISPLAY_Y)/SETTINGS_ROW_H;
        if(row==0) {
            // 字体目录通常已由首页/设置主页空闲预热；仅当缓存仍为空时补扫一次，
            // 这样进入字体页不再把整次读卡压在第一帧上。
            // The catalogue is normally pre-warmed from Home or the settings root; scan only when
            // it is still empty so entering this page never puts a card walk on the first frame.
            if (ttf_font_count() == 0) { ttf_font_scan(); s_font_catalog_warmed = true; }
            s_font_page=0;s_notice[0]=0;s_font_sync_confirm=false;s_page=SETTINGS_SYSTEM_FONT;
        }
        else if(row==1)s_page=SETTINGS_SYSTEM_CONTRAST;
        else if(row==2)s_page=SETTINGS_MAIN_REFRESH;
        else if(row==3)app_settings_set_home_full_refresh(!app_settings_home_full_refresh());
        else if(row==4)s_page=SETTINGS_AUTO_LOCK;
        else if(row==5)s_page=SETTINGS_POWER_SLEEP;
        else if(row==6){
            // 反色三态：关闭 → 手动开启 → 夜间自动。夜间自动按 21:00–07:00 生效，时间无效时只看手动开关。
            // Inversion cycles off -> manual on -> night auto. Night auto runs 21:00-07:00 and
            // falls back to the manual switch when the clock is invalid.
            const int state = app_settings_inverted() ? 1 : app_settings_invert_night() ? 2 : 0;
            const int next = (state + 1) % 3;
            app_settings_set_inverted(next == 1);
            app_settings_set_invert_night(next == 2);
            display_set_inverted(ctx->hl, app_settings_invert_effective());
            snprintf(s_notice,sizeof(s_notice),"%s",next==1?"反色模式已开启":next==2?"夜间自动反色已开启（21:00–07:00）":"反色模式已关闭");
            return APP_REDRAW_FULL;
        }
        else {
            // 中文显示只有繁体/简体两种：点一次整体切换，正文与界面同时生效。
            // Script display has exactly two states; one tap switches the whole UI and body together.
            const app_zh_mode_t next = app_settings_zh_mode() == APP_ZH_TRADITIONAL
                ? APP_ZH_SIMPLIFIED : APP_ZH_TRADITIONAL;
            app_settings_set_zh_mode(next);
            zh_convert_set_mode(next);
            // 界面字形随繁简切换，首页时钟的固定预览需要重绘。
            // UI glyphs follow the script switch, so Home's fixed clock previews must be rebuilt.
            ui_home_clock_preview_invalidate();
            app_home_cover_mode_changed();
            app_book_cover_mode_changed();
            book_lock_collage_invalidate();
            snprintf(s_notice,sizeof(s_notice),"%s",next==APP_ZH_TRADITIONAL?"已切换为全部繁体":"已切换为全部简体");
            return APP_REDRAW_FULL;
        }
        return APP_REDRAW_PAGE;
    }
    if(y>=SETTINGS_PERSONAL_Y && y<SETTINGS_PERSONAL_Y+SETTINGS_PERSONAL_ROWS*SETTINGS_ROW_H) {
        row=(y-SETTINGS_PERSONAL_Y)/SETTINGS_ROW_H;
        if(row==0) {s_page=SETTINGS_SHELF_STYLE;s_style_scroll=0;}
        else if(row==1)s_page=SETTINGS_LOCK_STYLE;
        else if(row==2){s_page=SETTINGS_LOCK_PIN;s_notice[0]=0;}
        else if(row==4) app_settings_set_wake_presses(app_settings_wake_presses()==1?2:1);
        else profile_editor_open(true);
        return APP_REDRAW_PAGE;
    }
    if(y>=SETTINGS_MAINTENANCE_Y && y<SETTINGS_MAINTENANCE_Y+SETTINGS_MAINTENANCE_ROWS*SETTINGS_ROW_H) {
        row=(y-SETTINGS_MAINTENANCE_Y)/SETTINGS_ROW_H;
        if(row==4) {s_page=SETTINGS_FACTORY_RESET;s_reset_confirm=s_reset_pending=false;s_reset_notice[0]=0;}
        else if(row==0)upgrade_open();
        else if(row==1){s_page=SETTINGS_CONFIG;s_config_confirm=false;s_notice[0]=0;}
        else if(row==2){
            // 屏幕在刷新中途断电会停在半帧，常规差分刷新永远盖不掉那道条纹；点一下就整屏盲刷
            // 一遍，然后自己把当前页面（含底栏）推回面板。
            // A power cut mid-refresh leaves the panel half-driven, and an ordinary differential
            // refresh can never cover that stripe. One tap runs the blind full-screen pass, which
            // then pushes the current page -- navigation bar included -- back onto the panel.
            s_panel_repair_pending=true;
            snprintf(s_notice,sizeof(s_notice),"屏幕修复中…");
            return APP_REDRAW_PAGE;
        }
        else if(row==5){s_page=SETTINGS_RAM_DIAG;}
        else {s_boot_pending=false;s_page=SETTINGS_BOOT;}
        return APP_REDRAW_PAGE;
    }
    return APP_REDRAW_NONE;
}

static app_redraw_t on_key(app_ctx_t *ctx, int key) {
    s_reset_confirm=s_reset_pending=false;
    if(s_font_sync_confirm) {
        s_font_sync_confirm=false;s_notice[0]=0;
        if(key!=1)return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_PIN_ENTRY) { pin_setup_close(); s_page = SETTINGS_LOCK_PIN; return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_UPGRADE) {
        s_upgrade_job = UPGRADE_JOB_NONE;
        if (s_local_pending || s_upgrade_restart) return APP_REDRAW_NONE;
        pico_online_cancel_join(); s_upgrade_confirm = false;
    }
    if (s_page == SETTINGS_BLE_SCAN) {
        ble_pt_scan_stop();
        if (key != 1) { s_page = SETTINGS_BLUETOOTH; s_ble_scroll = 0; return APP_REDRAW_PAGE; }
    }
    if (key == 1) { ui_nav_request(ctx, 0); return APP_REDRAW_NONE; }
    if (s_page == SETTINGS_WALLPAPER_PREVIEW) {
        if (s_wallpaper_confirm) s_wallpaper_confirm = false;
        else { bookmark_preview_release(); s_page = SETTINGS_WALLPAPER; }
        return APP_REDRAW_PAGE;
    }
    if (s_page == SETTINGS_WALLPAPER) { s_page = SETTINGS_LOCK_STYLE; return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_AVATAR) { s_page = SETTINGS_PROFILE; return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_TEXT_EDIT) { ui_keyboard_end(); s_page = s_editor_signature ? SETTINGS_MAIN : SETTINGS_PROFILE; return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_PROFILE) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
    if (s_page == SETTINGS_TIME_EDIT) { s_page = SETTINGS_TIME; return APP_REDRAW_PAGE; }
    if (s_page != SETTINGS_MAIN) { s_page = SETTINGS_MAIN; (void)read_pico_transfer_get_saved_wifi(s_main_wifi,&s_main_wifi_saved); settings_prepare_profile(); return APP_REDRAW_PAGE; }
    ui_nav_request(ctx, 0);
    return APP_REDRAW_NONE;
}
static void settings_exit(app_ctx_t *ctx) {
    s_reset_confirm=s_reset_pending=false;
    bookmark_preview_release();s_bookmark_picker=false;
    s_font_sync_confirm=false;s_font_sync_path[0]=0;
    pin_setup_close();
    s_collage_prepare_pending = false;
    s_upgrade_job = UPGRADE_JOB_NONE;
    (void)ctx; ui_keyboard_end(); pico_online_cancel_join(); ble_pt_scan_stop(); s_ble_learning = 0;
    // 页面内存策略 Phase1：离开设置页归还壁纸/书封列表（24.6 KB PSRAM）与锁屏拼贴索引；
    // 下次进入按需重扫，不影响当前设置值。
    // Page memory policy phase 1: return the wallpaper/cover list (24.6 KB PSRAM) and the lock
    // collage index when leaving; both rebuild lazily and do not affect saved settings.
    free(s_wallpapers); s_wallpapers = NULL;
    s_wallpaper_count = 0; s_wallpaper_page = 0; s_wallpaper_selected = -1;
    book_lock_collage_invalidate();
}
static void on_before_lock(app_ctx_t *ctx) {
    s_reset_confirm=s_reset_pending=false;
    s_font_sync_confirm=false;s_font_sync_path[0]=0;
    if (s_page == SETTINGS_PIN_ENTRY) { pin_setup_close(); s_page = SETTINGS_LOCK_PIN; }
    s_upgrade_job = UPGRADE_JOB_NONE;
    (void)ctx; pico_online_cancel_join(); ble_pt_scan_stop(); s_ble_learning = 0;
    (void)ble_pt_stop(2000);
}
static bool no_menu_handle(app_ctx_t *ctx) { (void)ctx; return false; }
static void settings_media_lost(app_ctx_t *ctx) {
    bookmark_preview_release();
    (void)ctx; s_avatar_ready=s_avatar_pending=false; s_avatar_path[0]=0;
    // 卡离开后图片列表和字体目录缓存作废，等新卡挂载后的空闲再预热。
    // Drop the picture list and font catalogue caches with the card; the next mount re-warms them
    // when idle.
    s_wallpaper_count=0;s_wallpaper_page=0;s_wallpaper_selected=-1;s_wallpaper_list_png=false;
    s_font_catalog_warmed=false;s_media_warm_done=false;s_warm_idle_ms=-1;
}
static void settings_media_ready(app_ctx_t *ctx) {
    (void)ctx;
    s_wallpaper_count=0;s_wallpaper_page=0;s_wallpaper_list_png=false;
    s_font_catalog_warmed=false;s_media_warm_done=false;s_warm_idle_ms=-1;
    settings_prepare_profile();
}
static bool settings_edge_back(app_ctx_t *ctx) {
    (void)ctx;
    return s_page != SETTINGS_MAIN && !s_reset_pending && !s_local_pending &&
        !s_upgrade_restart && !s_pin_pending && !s_font_sync_confirm;
}
static bool settings_back_swipe_area(app_ctx_t *ctx,const ui_gesture_event_t *event) {
    (void)ctx;
    return s_page!=SETTINGS_TEXT_EDIT || event->y0<UI_SYSTEM_KEYBOARD_TOP;
}
static bool main_page_visible(app_ctx_t *ctx) { (void)ctx; return s_page == SETTINGS_MAIN; }
static bool settings_navigation_enabled(app_ctx_t *ctx) {
    (void)ctx;
    return !s_reset_pending && !s_local_pending && !s_upgrade_restart && !s_pin_pending && !s_boot_pending;
}
static bool settings_present(app_ctx_t *ctx, app_redraw_t redraw) {
    if (s_page == SETTINGS_PIN_ENTRY && (redraw == APP_REDRAW_PAGE || redraw == APP_REDRAW_FULL)) {
        display_main_transition_cancel(); render(ctx, ctx->fb);
        enum EpdDrawError pin_err = update_display_area_diff_with(
            ctx->hl, &E0470_WAVEFORM, MODE_GL16, (EpdRect){0,0,UI_LOCK_WIDTH,UI_NAV_REFRESH_END});
        guard_draw_result(ctx->hl, pin_err);
        // 反色下 PIN 页同样只在差分 GL16 上推屏，补一遍压黑清理避免背景留残影。
        // The PIN page is also pushed differentially under inversion; append a darken settle.
        if (pin_err == EPD_DRAW_SUCCESS && epd_get_inverted()) display_dark_settle(ctx->hl);
        return true;
    }
    if (redraw == APP_REDRAW_AREA && s_page == SETTINGS_TEXT_EDIT) {
        if (s_input_settle) {
            guard_draw_result(ctx->hl, update_display_area_full_with(ctx->hl, &E0470_WAVEFORM, MODE_GL16, s_input_area));
            s_input_settle = false;
            return true;
        }
        guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl,
            s_input_layout ? &E0470_WAVEFORM : &E0470_FOLLOW_WAVEFORM,
            s_input_layout ? MODE_GL16 : MODE_DU, s_input_area));
        return true;
    }
    if (redraw == APP_REDRAW_AREA && s_scroll_present_pending &&
        (s_page == SETTINGS_MAIN || s_page == SETTINGS_BLUETOOTH || s_page == SETTINGS_BLE_SCAN ||
         s_page == SETTINGS_SHELF_STYLE || s_page == SETTINGS_SYSTEM_FONT ||
         s_page == SETTINGS_WALLPAPER || s_page == SETTINGS_AVATAR)) {
        s_scroll_present_pending = false;
        render(ctx, ctx->fb);
        int top = s_page == SETTINGS_MAIN ? 160 : s_page == SETTINGS_SHELF_STYLE ? 242 : 190;
        EpdRect area = {0, top, UI_LOCK_WIDTH, settings_content_end() - top};
        // 只驱动变化像素，滚动次数不触发黑白清屏；题头与底栏保持稳定。
        // Drive changed pixels only; scroll counts never trigger a wipe, and header/nav stay stable.
        // 滚动已限定列表区域；取消主页替换许可，保留抗锯齿并去掉额外补白，不在松手后追加刷新。
        // Scroll already targets only the list: cancel main-profile substitution, retain AA and omit extra whitening, without a release refresh.
        display_main_transition_cancel();
        const EpdWaveform *wave=display_settings_scroll_waveform();
        enum EpdDrawError scroll_err = update_display_area_diff_with(ctx->hl,wave,MODE_GL16,area);
        guard_draw_result(ctx->hl, scroll_err);
        // 反色下列表滚动只驱动变化像素、深色底被 1k LUT 保持，滚动残影会留在列表背景上；
        // 每次滚动停下的 present 补一遍压黑清理（只压物理黑底，不驱动字形，无白闪）。
        // Under inversion list scrolling only drives changed pixels and the 1 KiB LUT holds the dark
        // ground, so scroll residue stays on the list background; append one darken settle on the
        // present where the scroll stops (presses only the physical black ground, never glyphs).
        if (scroll_err == EPD_DRAW_SUCCESS && epd_get_inverted()) display_dark_settle(ctx->hl);
        return true;
    }
    if (s_page != SETTINGS_UPGRADE) return false;
    if (redraw == APP_REDRAW_PAGE) {
        display_main_transition_cancel();
        render(ctx, ctx->fb);
        guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl, &E0470_WAVEFORM,
                          MODE_GL16, (EpdRect){0, 0, UI_LOCK_WIDTH, settings_content_end()}));
        return true;
    }
    if (redraw == APP_REDRAW_AREA) {
        guard_draw_result(ctx->hl, update_display_area_diff_with(ctx->hl, &E0470_FOLLOW_WAVEFORM,
                          MODE_DU, upgrade_progress_area()));
        return true;
    }
    return false;
}

const app_desc_t app_device_settings = {
    .binary_ui = false,
    .title = "设置 Settings", .detail = "显示、连接与设备", .enter_full = false,
    .owns_keys = true, .menu_handle_enabled = no_menu_handle,
    .main_page_visible = main_page_visible, .edge_back_enabled = settings_edge_back,
    .back_swipe_area=settings_back_swipe_area,
    .persistent_navigation=true,.navigation_enabled=settings_navigation_enabled,
    .on_enter = on_enter, .on_exit = settings_exit, .on_before_lock = on_before_lock, .render = render, .on_tick = on_tick, .on_gesture = on_gesture, .on_key = on_key,
    .present = settings_present, .on_media_lost=settings_media_lost, .on_media_ready=settings_media_ready,
};
