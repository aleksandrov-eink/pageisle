set(kiiko_selected_sources "sc7a20h.c")
idf_component_register(
    SRCS ${kiiko_selected_sources}
    INCLUDE_DIRS "include"
    REQUIRES esp_driver_gpio esp_driver_i2c
    PRIV_REQUIRES esp_timer freertos esp_hw_support
)

# 流畅性：-O3（触摸、编解码、PMU、传输等低延迟外设路径）。
# Smoothness: -O3 for the low-latency peripheral/decode paths.
if(NOT CMAKE_SCRIPT_MODE_FILE)
    component_compile_options(-O3)
endif()
