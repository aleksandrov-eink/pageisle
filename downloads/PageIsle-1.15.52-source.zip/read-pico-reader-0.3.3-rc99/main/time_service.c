/* SPDX-License-Identifier: Apache-2.0
 * 中文：S3 RTC 离线走时；在线每小时校准；开机空闲时每六小时尝试一次无线对时（用已保存 WiFi，
 * 扫到就校时，扫不到/失败立即关闭 WiFi，六小时后再试；**不在开机后立刻检测**；不常驻无线任务）。
 * English: S3 RTC keeps offline time; calibrate hourly while already online, or try a brief wireless
 * sync with the saved WiFi every six hours while powered on (no immediate check right after boot).
 * A missing network is not retried immediately: the radio is stopped and the next attempt is six
 * hours later. No resident radio task.
 */
#include "time_service.h"
#include <stdatomic.h>
#include <stdint.h>
#include <time.h>
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs.h"
#include "read_pico_transfer.h"
#include "sleep.h"

#define CLOCK_VALID_MIN 1704067200ULL
#define CLOCK_VALID_MAX 4102444799ULL
#define CLOCK_ONLINE_INTERVAL 3600ULL
#define CLOCK_OFFLINE_INTERVAL (6ULL * 3600)
// 每次尝试（成功或失败）之后的最短间隔：六小时，避免扫不到网络时反复唤醒 WiFi。
// Minimum gap after any attempt (success or failure): six hours, so a missing network never wakes
// the radio in a tight retry loop.
#define CLOCK_RETRY_US (6LL * 3600 * 1000000)
static atomic_bool s_running;
static bool s_loaded;
static uint64_t s_last_sync;
// 开机后不立刻检测：第一次自动尝试排到开机满六小时，之后每次尝试（成功/失败）间隔六小时。
// No immediate check after boot: the first automatic attempt is six hours after boot (and after
// every later attempt, success or failure).
static int64_t s_next_attempt_us = CLOCK_RETRY_US;

static void clock_worker(void *arg) {
    (void)arg;
    uint32_t utc = 0;
    esp_err_t err = read_pico_transfer_sync_time_auto(&utc);
    ESP_LOGI("clock", "background calibration: %s", esp_err_to_name(err));
    atomic_store(&s_running, false);
    vTaskDelete(NULL);
}

void app_time_service_poll(bool idle) {
    if (!idle) return;
    if (!s_loaded) {
        nvs_handle_t handle;
        if (nvs_open("kiiko_clock", NVS_READONLY, &handle) == ESP_OK) {
            if (nvs_get_u64(handle, "last_ntp", &s_last_sync) != ESP_OK) s_last_sync = 0;
            nvs_close(handle);
        }
        if (s_last_sync < CLOCK_VALID_MIN || s_last_sync > CLOCK_VALID_MAX) s_last_sync = 0;
        s_loaded = true;
    }
    uint32_t received;
    if (read_pico_transfer_take_time_sync(&received)) {
        // 只有真实网络成功才持久化；普通重启/手动设时间不能伪装成网络校准。
        // Persist only a real network success; reboot/manual edits do not count as calibration.
        s_last_sync = received;
        (void)app_sync_time_to_pmu();
        nvs_handle_t handle;
        if (nvs_open("kiiko_clock", NVS_READWRITE, &handle) == ESP_OK) {
            if (nvs_set_u64(handle, "last_ntp", s_last_sync) == ESP_OK) (void)nvs_commit(handle);
            nvs_close(handle);
        }
    }
    const int64_t monotonic = esp_timer_get_time();
    if (atomic_load(&s_running) || monotonic < s_next_attempt_us) return;
    read_pico_transfer_status_t status;
    read_pico_transfer_get_status(&status);
    bool online = status.state == READ_PICO_TRANSFER_READY &&
                  status.mode == READ_PICO_TRANSFER_MODE_STA && status.network_ready;
    if (!online && status.state != READ_PICO_TRANSFER_STOPPED) return;
    time_t now = time(NULL);
    uint64_t interval = online ? CLOCK_ONLINE_INTERVAL : CLOCK_OFFLINE_INTERVAL;
    if (now >= (time_t)s_last_sync && s_last_sync && (uint64_t)now - s_last_sync < interval) return;
    s_next_attempt_us = monotonic + CLOCK_RETRY_US;
    if (!online) {
        char ssid[33]; bool configured = false;
        if (read_pico_transfer_get_saved_wifi(ssid, &configured) != ESP_OK || !configured) return;
        // 无线对时是一次性短连：transfer 层在成功/失败后都会 esp_wifi_stop + deinit，
        // 扫不到网络也立即关掉 WiFi，然后这里等六小时再试。
        // The wireless attempt is a one-shot short connection: the transfer layer stops and
        // deinitializes WiFi on success and on failure, so a missing network leaves the radio off
        // and the next attempt is six hours later.
        ESP_LOGI("clock", "wireless sync attempt; next automatic attempt in 6h");
    }
    atomic_store(&s_running, true);
    // 仅对时期间保留任务栈；不创建常驻无线任务或页面缓存。
    // Keep a task stack only during calibration; no permanent radio task or page cache.
    if (xTaskCreate(clock_worker, "rtc_sync", 6144, NULL, 1, NULL) != pdPASS) {
        atomic_store(&s_running, false);
        ESP_LOGW("clock", "background calibration deferred: no task memory");
    }
}
