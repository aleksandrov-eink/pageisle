/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：图书应用向首页暴露的预热入口。
 * English: Book-app prewarm entry points exposed to the home page.
 */
#pragma once

#include "app.h"

/**
 * 首页空闲时预热书架：分批扫描书目、预解码首屏封面，进入图书时直接命中缓存。
 * Warm the shelf while the home page is idle: walk the book listing in small budgeted steps and
 * decode the first screen's covers ahead of time, so entering the book app hits the cache instead
 * of scanning and decoding on the spot.
 *
 * 调用约定 / Calling contract:
 * - 由首页 on_tick 的空闲分支反复调用；函数自身节流，不阻塞、不做长任务。
 *   Call it repeatedly from the home page's idle tick; the function throttles itself and never
 *   blocks or runs a long task.
 * - 触摸、按键、翻页或任何导航请求会立即让出，下一轮空闲继续；离开首页则放弃本次预热。
 *   Touch, keys, page changes or any navigation request yield immediately and resume when idle
 *   again; leaving the home page abandons this prewarm round.
 * - 只在没有打开图书时运行（阅读上下文未释放也不会运行），避免与正文抢 SD 与 PSRAM。
 *   It only runs when no book is open (not even a retained reader context), so it never competes
 *   with the body for SD or PSRAM.
 * - 未完成任务放弃时会把书架缓存标记为失效，真正进入书架自动回退到正常扫描。
 *   Abandoning an unfinished round invalidates the shelf cache, so the real shelf entry falls back
 *   to the normal scan on its own.
 */
void app_book_shelf_prewarm(app_ctx_t *ctx);
/// 自动恢复 SD 前的静默判断：SD 上的书仍打开时返回 false（book_txt/zip 持有 FILE*）。
/// Media-recovery gate: false while an SD book is open (book_txt/zip keeps a FILE handle).
bool app_book_media_idle(void);
