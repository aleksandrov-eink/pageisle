# 页屿 PageIsle 定制版 · 交付汇总（小纸 Pico，系统 1.15.72）

适用设备：RDP-G01-W（ESP32-S3 电子墨水屏，逻辑分辨率 684×1216，横屏 1216×684）。
系统名：**页屿 PageIsle**（对外品牌；固件包名、版本号、分区表仍是上游 0.3.3-rc99，未改动）。
本包是 **页屿系统 1.15.72**（2026-11-13）；**所有代码只做了编译、静态分析与宿主测试，未在真机上运行过**，真机结论以用户反馈为准。

## 一、最终固件

| 项目 | 值 |
|---|---|
| 版本 | 上游应用 0.3.3-rc99（页屿系统 **1.15.72**） |
| 应用镜像大小 | **3,712,992 字节** |
| ota_0 分区余量 | **481,312 字节（约 11.48%）** |
| sha256 | `5af05c65b7499dfbdd9cd5e3a3f4e1c68214d1ab91da87966950fdb18a8b0886` |

## 二、1.15.71 → 1.15.72 主要变化

- **竖排阅读设置重启后丢失修复（本版核心）**：阅读设置里的「竖排（从右到左）」以前会保存，但开机加载时被旧逻辑丢弃存值；现在开机恢复该设置，重启/深睡唤醒后仍保持竖排；关闭竖排仍正常持久化为横排。
- 只修复设置恢复逻辑，竖排排版/横屏竖排/触摸方向等行为与 1.15.71 相同；其余功能与 1.15.71 相同（分区表 / bootloader / OTA 布局未改；书、设置与阅读记录保留）。

## 三、刷机方式

三种方式任选，推荐第 1 种：

1. **单文件全量刷机（推荐）**：`usb-full-package/Pico-full-flash-1.15.72.bin`（bootloader + 分区表 +
   otadata + 应用合成镜像），一条命令：
   `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.72.bin`
   （16MB flash 约 1–2 分钟；分区表未变，书籍/NVS 设置保留）。
2. **USB 四文件全量包**：`usb-full-package/` 的
   `bootloader.bin / partitions.bin / ota_data_initial.bin / firmware.bin`，按同目录 `flash_args`
   分地址写入：`python -m esptool --chip esp32s3 -p COMx write_flash @flash_args`。
3. **TF 卡升级（预计被拒绝，属正常）**：`firmware/Pico-update.bin` 放 TF 根目录 → 设置 → 升级和恢复 →
   本地升级。因上游应用版本仍是 0.3.3-rc99，设备「同版本检查」会拒绝；请改用方式 1/2。

## 四、本版验收（竖排设置）

打开阅读设置 → 把「竖排（从右到左）」打开 → 确认正文竖排；退回书架/首页再进阅读仍竖排；重启或休眠唤醒后再进阅读仍竖排；关闭竖排后确认横排且重启仍横排。若仍会退回横排，请提供复现步骤（重启/休眠/换书）、是否用配置备份恢复，以及 115200 串口日志。详见 `docs/真机验收清单-1.15.72.md` 与 `docs/改版日志-1.15.72.md`。

## 五、文件清单

```
handover-1.15.72/
├─ firmware/Pico-update.bin              # TF 卡升级镜像（3,712,992 B；同版本检查会拒绝，备用）
├─ usb-full-package/                     # USB 完整刷机包
│  ├─ Pico-full-flash-1.15.72.bin        # 单文件合成刷机镜像（推荐，一条命令刷完）
│  ├─ firmware.bin / bootloader.bin / partitions.bin / ota_data_initial.bin
│  ├─ flash_args / manifest.json / SHA256SUMS.txt
├─ rollback-1.15.71/                     # 离线回退 1.15.71（上一正式版）
│  ├─ Pico-full-flash-1.15.71.bin / Pico-update.bin / 回退说明.txt / SHA256SUMS.txt
├─ rollback-1.15.53/                     # 离线回退 1.15.53（更早正式版）
├─ docs/                                 # 使用说明/变更清单/改版日志与刷机指南/0.81/验收清单/校验
├─ promo-fun/                            # 宣传图（沿用）
├─ README-HANDOVER.md                    # 本文件
└─ GitHub上传指南.md                     # 网页版上传步骤
```

## 六、校验

- `firmware/Pico-update.bin` / `usb-full-package/firmware.bin`：`5af05c65b7499dfbdd9cd5e3a3f4e1c68214d1ab91da87966950fdb18a8b0886`
- `usb-full-package/Pico-full-flash-1.15.72.bin`：`6ca0cd0ad52c81e695812554aa5e933c6ae39f38b476fde0a7134a4167553d89`（13,705,216 字节）
- USB 包内 `SHA256SUMS.txt` 覆盖 full-flash、bootloader、firmware、ota_data、partitions。

## 七、回退（重要）

- 回退到 **1.15.71 正式版**：`rollback-1.15.71/Pico-full-flash-1.15.71.bin`
  （13,705,216 字节，sha256 `ac552e5cd8fde665807ee6577514da5b8fc515f8e634ab50924a24507414ecd7`）；
  其单独 TF 镜像为 `rollback-1.15.71/Pico-update.bin`（3,712,976 字节，sha256 `4c98b123…a774c0d`）。
- 回退到 **1.15.53 正式版**：`rollback-1.15.53/Pico-full-flash-1.15.53.bin`；其 TF 镜像为 3,687,280 字节，sha256 `f7fc2253…1ece95bd`。

## 八、已知限制（如实说明）

- 本版**未真机验证**：编译 0 error、warning 与 1.15.71 基线同量（11 条历史遗留、无新增）；竖排修复只做了严格编译检查与静态分析，真机结论以用户反馈为准。
- 网页正式站/内测站与网页刷机 bootloader 沿用线上 `e49feb21…`；本交接包 USB 全量包使用本次全量构建的 `e5be0ad2…`（同源、功能等价；分区表与 OTA 数据一致）。
- TF 本地升级同版本检查可能拒绝，请优先使用单文件全量刷机。

## 九、源码

源码位于开发机的 `read-pico-reader-0.3.3-rc99` 目录；步骤见 `GitHub上传指南.md`。
