/* SPDX-License-Identifier: Apache-2.0
 * 中文：文字水波纹的柔和灰边，保留抗锯齿目标、驱动计数和周期清残影。
 * English: Soften gray-edge transients on text ripple turns, preserving antialiased targets,
 * pulse counts and periodic cleanup.
 * 冻结：仅白底到中灰提前最多两相回浅；黑/白端点、其他迁移、原表及帧时序不改。
 * 相同驱动计数不保证光学灰度相同；此调序需实屏对比深浅与残影。
 * Frozen: Advance at most two settling phases only for white-to-midgray pairs. Keep endpoints,
 * all other pairs, original tables and frame timing. Equal pulse counts do not guarantee equal
 * optical grays; validate this ordering on the panel against tone and ghosting.
 * 用户2026-11-01（移植上游 rc103）：新增 41 相普通/图文翻页整屏 GL16 与 41 相阅读水波纹；
 * 原 37 相文字序列保持不变，新增表 LUT 动态分配在 PSRAM、分配失败回退原表。
 * User 2026-11-01 (ported from upstream rc103): add the 41-phase whole-screen GL16 for
 * ordinary/image turns and the 41-phase reading ripple; the original 37-phase text sequence is
 * untouched and the new LUTs are allocated in PSRAM with an original-table fallback on failure.
 */
#include "display_reader_waveform.h"
#include "e0470_epaper_waveform.h"
#include "esp_heap_caps.h"
#include <stdbool.h>
#include <string.h>

static uint8_t s_data[E0470_GL16_FRAMES][16][4];
static const EpdWaveformPhases s_phases = {E0470_GL16_FRAMES, (const uint8_t*)s_data, NULL};
static const EpdWaveformPhases* s_ranges[] = {&s_phases};
static const EpdWaveformMode s_mode = {5, 1, s_ranges};
static const EpdWaveformMode* s_modes[] = {&s_mode};
static EpdWaveform s_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_modes};
static bool s_ready;

static void set_action(int phase, int to, int action) {
    // from=15 占该字节最低两位；其余三对不变。/ from=15 occupies only the lowest two bits.
    s_data[phase][to][3] = (uint8_t)((s_data[phase][to][3] & ~3u) | (unsigned)action);
}

const EpdWaveform* display_reader_text_waveform(void) {
    if (s_ready) return &s_waveform;
    const EpdWaveformPhases* original = e0470_waveform_phases(&E0470_TEXTTURN_WAVEFORM, MODE_GL16);
    if (!original || !original->luts || original->phases != E0470_GL16_FRAMES || original->phase_times)
        return &E0470_TEXTTURN_WAVEFORM;
    memcpy(s_data, original->luts, sizeof(s_data));
    for (int to = 1; to < 15; ++to) {
        int first_white = original->phases, last_black = -1;
        for (int f = 0; f < original->phases; ++f) {
            int action = e0470_phase_action(original, f, to, 15);
            if (action == 2 && first_white == original->phases) first_white = f;
            if (action == 1) last_black = f;
        }
        int prefix_black = 0, tail_white = 0;
        for (int f = 0; f < first_white; ++f)
            prefix_black += e0470_phase_action(original, f, to, 15) == 1;
        for (int f = last_black + 1; f < original->phases; ++f)
            tail_white += e0470_phase_action(original, f, to, 15) == 2;
        int moves = tail_white >= 4 && prefix_black >= 6 ? 2 :
                    tail_white >= 2 && prefix_black >= 4 ? 1 : 0;
        if (!moves) continue;
        // 交换动作而非删相；保留起点、末尾回浅及所有保持相，不增加第二次推屏。
        // Swap pulses instead of dropping phases; retain the start, final settling and holds.
        int rank = 0, moved = 0, white = last_black + 1;
        int target_rank = prefix_black - (moves == 2 ? 5 : 3);
        for (int f = 0; f < first_white && moved < moves; ++f) {
            if (e0470_phase_action(original, f, to, 15) != 1) continue;
            if (rank++ != target_rank) continue;
            while (white < original->phases && e0470_phase_action(original, white, to, 15) != 2) ++white;
            if (white == original->phases) break;
            set_action(f, to, 2); set_action(white++, to, 1);
            ++moved; target_rank += 2;
        }
    }
    s_waveform.temp_intervals = E0470_TEXTTURN_WAVEFORM.temp_intervals;
    s_ready = true;
    return &s_waveform;
}

// 普通/图文翻页：整屏全像素走厂商 GL16（右对齐、擦除+饱和+灰阶尾+定稿保持），把
// 等值“黑→黑”的擦白相去掉只留压黑相，并在厂商 3 相定稿保持之前插入 4 相“全屏擦白”
// （所有目标为白的像素，含本来也白的空白区），翻页后白底擦得更狠；其余迁移
// （灰阶、变黑、变白）完全按厂商原序列。得到 37+4=41 相。移植自上游 rc103。
// Ordinary/image turns: one whole-screen full-pixel vendor GL16 (right-aligned, erase +
// saturation + gray tail + settle holds). Equal black-on-black drops its erase phases and keeps
// the darken phases, and four whole-screen erase phases are inserted before the vendor's three
// settle holds so every white target (including already-white blanks) is erased harder after a
// turn. All other transitions stay vendor-original: 37+4 = 41 phases. Ported from upstream rc103.
// 表放 PSRAM 并在首次调用时只建一次；分配失败回退厂商 E0470_WAVEFORM（37 相），不伪造波形。
// The table is allocated in PSRAM once on first use; on allocation failure this returns the
// vendor E0470_WAVEFORM (37 phases) instead of fabricating a waveform.
#define READER_SOFT_TURN_SETTLE_EXTRA 4
static EpdWaveformPhases s_soft_phases;
static const EpdWaveformPhases* s_soft_ranges[] = {&s_soft_phases};
static const EpdWaveformMode s_soft_mode = {MODE_GL16, 1, s_soft_ranges};
static const EpdWaveformMode* s_soft_modes[] = {&s_soft_mode};
static EpdWaveform s_soft_waveform = {
    .num_modes = 1, .num_temp_ranges = 1, .mode_data = s_soft_modes
};

static void soft_set_action(uint8_t (*data)[16][4], int phase, int to, int from, int action) {
    const int shift = 6 - 2 * (from % 4);
    data[phase][to][from / 4] = (uint8_t)(
        (data[phase][to][from / 4] & ~(3u << shift)) | ((unsigned)action << shift)
    );
}

const EpdWaveform* display_reader_soft_turn_waveform(void) {
    if (s_soft_phases.luts) return &s_soft_waveform;
    const EpdWaveformPhases* gl = e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16);
    // 相数按本机 E0470_GL16_FRAMES=37 校验；不符说明表被改动，直接回退原表。
    // The phase count must match this panel's E0470_GL16_FRAMES = 37; otherwise the vendor table
    // changed and the original table is returned untouched.
    if (!gl || !gl->luts || gl->phase_times ||
        gl->phases != E0470_GL16_FRAMES ||
        gl->phases + READER_SOFT_TURN_SETTLE_EXTRA > 64) return &E0470_WAVEFORM;
    const int phases = gl->phases + READER_SOFT_TURN_SETTLE_EXTRA;
    // 厂商裁剪表尾部定稿保持相的动作全为 0；从末尾往回数出驱动段长度（本机为 3 相保持）。
    // The vendor trimmed table ends with all-zero settle holds; count them backwards to find the
    // drive length (three holds on this panel).
    int hold = 0;
    while (hold < gl->phases) {
        const int f = gl->phases - 1 - hold;
        int nonzero = 0;
        for (int to = 0; to < 16 && !nonzero; ++to)
            for (int from = 0; from < 16; ++from)
                if (e0470_phase_action(gl, f, to, from)) { nonzero = 1; break; }
        if (nonzero) break;
        ++hold;
    }
    if (hold < 1) return &E0470_WAVEFORM;
    const int drive = gl->phases - hold;
    const int extra = READER_SOFT_TURN_SETTLE_EXTRA;
    uint8_t (*data)[16][4] = heap_caps_malloc(
        (size_t)phases * 16 * 4, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!data) return &E0470_WAVEFORM;
    memcpy(data, gl->luts, (size_t)drive * 16 * 4);
    memset(data + drive, 0, (size_t)extra * 16 * 4);
    memcpy(data + drive + extra, gl->luts + (size_t)drive * 16 * 4,
           (size_t)hold * 16 * 4);
    // 等值黑→黑只保留压黑相，去掉擦白相（与上游一致）。
    // Equal black-on-black keeps only the darken phases and drops the erases (same as upstream).
    for (int f = 0; f < gl->phases; ++f)
        if (e0470_phase_action(gl, f, 0, 0) == 2) soft_set_action(data, f, 0, 0, 0);
    for (int i = 0; i < extra; ++i)
        for (int from = 0; from < 16; ++from) soft_set_action(data, drive + i, 15, from, 2);
    s_soft_phases = (EpdWaveformPhases){phases, (const uint8_t*)data, NULL};
    s_soft_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
    return &s_soft_waveform;
}

// 复用 Pico 原厂完整 DU（20 相，含末尾保持相）：不改表、不调脉宽、不冒用其他板型扫描。
// 速读黑白走这里；普通/图文翻页改走上面的 41 相软翻页表，水波纹走文件末尾的 41 相水波表。
// Reuse Pico's complete vendor DU (20 phases, including trailing holds): tables, pulse widths and
// board scan timing stay untouched. This is the Fast BW path; ordinary/image turns now use the
// 41-phase soft-turn table above and ripple uses the 41-phase water table at the end of this file.
const EpdWaveform* display_reader_fast_text_waveform(void) {
    const EpdWaveformPhases* original = e0470_waveform_phases(&E0470_FULL_WAVEFORM, MODE_DU);
    if (!original || !original->luts || original->phase_times ||
        original->phases != E0470_FULL_DU_FRAMES) return NULL;
    return &E0470_FULL_WAVEFORM;
}

// 速读黑白的准备：只把本轮的正文/页脚目标区域（逻辑坐标）按 50% 阈值改成纯黑白，
// 真实旧灰阶和区域外的像素一概不动；随后用原厂 DU 一次推屏，物理屏就只剩黑白两级，
// 省掉灰阶沉降时间。目标区域先按旋转映射到物理缓冲，再逐字节就地改写。
// Fast BW prepare: threshold only this turn's body/footer target area (logical coordinates) to
// pure black/white at 50%; real old grays and every pixel outside the area are left untouched.
// The vendor DU then pushes once and the panel only needs black/white, dropping gray settling.
// The target area is mapped to the physical buffer through the current rotation first, then
// rewritten in place byte by byte.
bool display_reader_fast_text_prepare(EpdiyHighlevelState* hl, EpdRect area) {
    if (!hl || !hl->front_fb || !hl->back_fb || hl->front_fb == hl->back_fb ||
        area.width <= 0 || area.height <= 0 || !display_reader_fast_text_waveform()) return false;
    const int pw = epd_width(), ph = epd_height();
    if (pw <= 0 || ph <= 0 || (pw & 1)) return false;
    enum EpdRotation rotation = epd_get_rotation();
    bool portrait = rotation == EPD_ROT_PORTRAIT || rotation == EPD_ROT_INVERTED_PORTRAIT;
    int lw = portrait ? ph : pw, lh = portrait ? pw : ph;
    int64_t right = (int64_t)area.x + area.width, bottom = (int64_t)area.y + area.height;
    int x = area.x < 0 ? 0 : area.x, y = area.y < 0 ? 0 : area.y;
    if (right > lw) right = lw;
    if (bottom > lh) bottom = lh;
    if (right <= x || bottom <= y) return false;
    int w = (int)right - x, h = (int)bottom - y;
    EpdRect phys;
    switch (rotation) {
        case EPD_ROT_LANDSCAPE: phys = (EpdRect){x, y, w, h}; break;
        case EPD_ROT_PORTRAIT: phys = (EpdRect){pw-y-h, x, h, w}; break;
        case EPD_ROT_INVERTED_LANDSCAPE: phys = (EpdRect){pw-x-w, ph-y-h, w, h}; break;
        case EPD_ROT_INVERTED_PORTRAIT: phys = (EpdRect){y, ph-x-w, h, w}; break;
        default: return false;
    }
    for (int row = phys.y; row < phys.y + phys.height; ++row) {
        uint8_t* p = hl->front_fb + (size_t)row * (pw / 2);
        int col = phys.x, end = col + phys.width;
        // 奇数起点先处理单像素；中间按每字节两像素整字节改写；末尾再补单像素。
        // Handle an odd left edge first, then whole bytes, then a trailing odd pixel.
        if (col & 1) { uint8_t v = p[col/2]; p[col++/2] = (uint8_t)((v & 15) | ((v & 0x80) ? 0xf0 : 0)); }
        for (; col + 1 < end; col += 2) {
            uint8_t v = p[col/2]; p[col/2] = (uint8_t)(((v & 8) ? 15 : 0) | ((v & 0x80) ? 0xf0 : 0));
        }
        if (col < end) { uint8_t v = p[col/2]; p[col/2] = (uint8_t)((v & 0xf0) | ((v & 8) ? 15 : 0)); }
    }
    return true;
}

// 阅读水波纹：基于上面已验证的 37 相柔和文字序列，在原有 3 相定稿保持之前插入 4 相
// “变白驱动”（所有目标为白的像素，含本来也白的空白区；from=15 已白不再推），得到
// 37+4=41 相。保留全部灰阶相位，不增加第二次推屏；与上游 rc103 一致。
// 若尾部 3 相不是纯等值保持（动作全 0）、相数不符或 PSRAM 分配失败，直接回退文字序列。
// Reading ripple: start from the proven 37-phase soft text sequence, then insert four white
// drives before the native three settle holds (every white target, including already-white
// blanks; from=15 is already white and gets no extra push) for 37+4 = 41 phases. Every gray
// phase is retained with no second scan pass, matching upstream rc103. If the three settling
// phases are not pure all-zero holds, the phase count differs, or the PSRAM allocation fails,
// the text sequence is returned unchanged.
#define READER_WATER_WHITE 4
#define READER_WATER_HOLDS 3
#define READER_WATER_PHASES (E0470_GL16_FRAMES + READER_WATER_WHITE)
static EpdWaveformPhases s_water_phases;
static const EpdWaveformPhases* s_water_ranges[] = {&s_water_phases};
static const EpdWaveformMode s_water_mode = {MODE_GL16, 1, s_water_ranges};
static const EpdWaveformMode* s_water_modes[] = {&s_water_mode};
static EpdWaveform s_water_waveform = {
    .num_modes=1, .num_temp_ranges=1, .mode_data=s_water_modes
};

const EpdWaveform* display_reader_water_waveform(void) {
    if (s_water_phases.luts) return &s_water_waveform;
    const EpdWaveform* source = display_reader_text_waveform();
    const EpdWaveformPhases* phases = e0470_waveform_phases(source, MODE_GL16);
    if (!phases || !phases->luts || phases->phase_times ||
        phases->phases != E0470_GL16_FRAMES) return source;
    const int drive = phases->phases - READER_WATER_HOLDS;
    // 尾部 3 相只允许等值维持：任一字节非 0 说明源表被改动，保留原表不插相。
    // Only equal holds are allowed in the three settling phases: any non-zero byte means the
    // source table changed, so keep it untouched instead of inserting phases.
    for (int f = drive; f < phases->phases; ++f)
        for (int i = 0; i < 64; ++i) if (phases->luts[f * 64 + i]) return source;
    uint8_t (*data)[16][4] = heap_caps_malloc(
        (size_t)READER_WATER_PHASES * 16 * 4, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!data) return source;
    memcpy(data, phases->luts, (size_t)drive * 64);
    memset(data + drive, 0, READER_WATER_WHITE * 64);
    memcpy(data + drive + READER_WATER_WHITE, phases->luts + (size_t)drive * 64,
           READER_WATER_HOLDS * 64);
    for (int f = drive; f < drive + READER_WATER_WHITE; ++f)
        for (int from = 0; from < 15; ++from)
            data[f][15][from / 4] |= (uint8_t)(2u << (6 - 2 * (from % 4)));
    s_water_phases = (EpdWaveformPhases){
        READER_WATER_PHASES, (const uint8_t*)data, NULL
    };
    s_water_waveform.temp_intervals = source->temp_intervals;
    return &s_water_waveform;
}
