/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 锁屏进睡、浅睡等待按键或拿起、软睡/关机拉掉 EN。
 *
 * Enter lock and sleep, light-sleep wait for key or pickup, and drop EN
 * for soft sleep / power-off.
 * 用户修订：票根从任意页面进入均用系统字体；浅睡唤醒恢复此前阅读字体，深睡由启动检查点恢复。
 * User revision: tickets use the system face from every page; light wake restores the previous reader face, while deep wake uses the startup checkpoint.
 * 用户修订：其他样式/自动锁屏先准备完整前缓冲，再清屏并做原 GC16 输出，缩短白屏等待。
 * User revision: other styles and idle locks prepare the complete front buffer before the original clear/GC16 output, shortening white-screen waits.
 * 用户修订：拼贴的新整帧缓存移到完整显示之后写入，密码层覆盖前提交。
 * User revision: persist new collage frames after complete presentation and before PIN overlays.
 * 用户修订：主动拼贴锁屏立即清白并显示圆锁，随后只用一次原GC16输出完整拼贴；取消占位和四步显影。
 * User revision: manual collage locks promptly present white and a round lock, then present the complete collage once with original GC16; remove placeholders and four-pass reveal.
 * 用户修订：合入官方 a2a63a6 的外设停用、IOE 收口与 CPU 浅睡保持；保留十分钟浅睡、密码和阅读检查点。
 * User revision: port official a2a63a6 peripheral/IOE parking and CPU light-sleep retention while preserving ten-minute light sleep, PIN and reader checkpoints.
 * 冻结：沿用实际后缓冲，不把圆锁当白色；不增加帧副本，自动休眠/其他样式/失败回退保留原流程。
 * Frozen: Retain true history including the badge, add no frame copy and preserve idle/other-style/failure recovery.
 */
#include "ui_avatar.h"
#include "book_cover_jobs.h"

#include "sleep.h"
#include "boot_state.h"
#include "lock_pin.h"
#include "lock_screen.h"
#include "read_pico_sd.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>

#include "app.h"
#include "app_font_context.h"
#include "book_cover.h"
#include "book_lock_collage.h"
#include "book_lock_bookmark.h"
#include "book_ticket.h"
#include "display.h"
#include "anti_fade.h"
#include "e0470_epaper_waveform.h"
#include "ota_online.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_sleep.h"
#include "esp_private/sleep_cpu.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "pmu_selftest.h"
#include "read_pico_board.h"
#include "read_pico_buzzer.h"
#include "ble_page_turner.h"
#include "read_pico_pmu.h"
#include "read_pico_transfer.h"
#include "timer_service.h"
#include "sc7a20h_lab.h"
#include "settings.h"
#include "ui_kit.h"
#include "ui_image_dither.h"
#include "ui_wallpaper.h"
#include "ui_lock_feedback.h"

static const char* TAG = "read_pico";
static bool s_lock_feedback_visible;

#define APP_LOCK_LIGHT_SLEEP_MS (10U * 60U * 1000U)
#define APP_LOCK_KEY_POLL_US (2LL * 1000 * 1000)
#define APP_LOCK_STUCK_IRQ_US (3LL * 1000 * 1000)
#define APP_LOCK_SLEEP_ERROR_LIMIT 5
// PMU 确认后仍未掉 EN 时恢复调用方，禁止无限等待。/ Restore the caller if EN stays high after acknowledgement instead of waiting forever.
#define HOST_EN_DROP_WAIT_MS 5000

void app_lock_feedback(EpdiyHighlevelState *hl) {
    s_lock_feedback_visible = false;
    if (!hl || app_settings_lock_style() != 2 || pico_online_busy()) return;
    read_pico_transfer_status_t transfer = {0};
    read_pico_transfer_get_status(&transfer);
    if (transfer.state == READ_PICO_TRANSFER_UPLOADING) return;
    uint8_t *framebuffer = epd_hl_get_framebuffer(hl);
    if (!framebuffer || epd_rotated_display_width() < 97 || epd_rotated_display_height() < 97) return;
    display_main_transition_cancel();
    // 原GC16清白适用于任意旧灰阶，不用只保证黑白端点的短DU擦整屏，无额外定时停留。
    // Calibrated GC16 whitens any prior gray; endpoint-only short DU must not erase a whole gray page.
    epd_hl_set_all_white(hl);
    if (update_display_full(hl) != EPD_DRAW_SUCCESS) return;
    EpdRect area = ui_lock_feedback_draw(framebuffer);
    s_lock_feedback_visible = update_display_area_diff_with(hl, &E0470_FOLLOW_WAVEFORM,
        MODE_DU, area) == EPD_DRAW_SUCCESS;
}

static bool draw_wallpaper(uint8_t *framebuffer) {
    const char *path = app_settings_wallpaper_path();
    return app_settings_lock_style() == 1 &&
        ui_wallpaper_prepare_lock(framebuffer,path);
}

// 极简时钟锁屏：白底、居中时分、下面日期、上面状态栏签名；不依赖卡上资源。
// 局刷只重绘时间那一块，整屏全刷每 20 分钟一次压残影。
// Minimal clock lock: white ground, centred HH:MM, date below, signature above; no card assets.
// Area updates redraw only the time block, with a full refresh every 20 minutes for residue.
#define LOCK_CLOCK_FULL_MINUTES 20

static bool lock_clock_now(struct tm *t) {
    time_t now = time(NULL);
    if (now < 1704067200) {
        const pmu_snapshot_t *pmu = read_pico_pmu_get();
        if (pmu && pmu->time_synced && pmu->unix_sec >= 1704067200) now = pmu->unix_sec;
    }
    if (now < 1704067200) return false;
    const time_t china = now + 8 * 3600;
    return gmtime_r(&china, t) != NULL;
}
// 大字（时/分）在旧尺寸上 +8px；横屏改用画布宽度取字号，避免沿用竖屏的高度比例偏小。
// Big digits (hour/minute) grow by 8px; landscape sizes derive from the canvas width instead of
// the portrait height ratio so the rotated clock keeps its presence.
static int lock_clock_hour_px(void) {
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    int px;
    if (w > h) {
        px = w / 10 + 8;
        if (px > 140) px = 140;
        if (px < 96) px = 96;
        return px;
    }
    px = h / 8 + 8;
    if (px > 158) px = 158;
    if (px < 88) px = 88;
    return px;
}
static int lock_clock_minute_px(void) {
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    int px;
    if (w > h) {
        px = w / 5 + 8;
        if (px > 268) px = 268;
        if (px < 150) px = 150;
        return px;
    }
    px = h / 4 + 8;
    if (px > 268) px = 268;
    if (px < 128) px = 128;
    return px;
}
// 横屏时钟把时间排成一行「时:分」，字号按画布宽度取，避免两行数字在横屏里又小又空；
// 竖屏仍是上下两行。签名和日期在横屏里分别让到顶部和底部，时间行不再顶到签名下缘。
// The landscape clock puts HH:MM on one row, sized from the canvas width, instead of two small
// stacked rows; portrait keeps the two-row layout. Signature and date move clear of the row.
static bool lock_clock_landscape(void) {
    return epd_rotated_display_width() > epd_rotated_display_height();
}
static int lock_clock_row_px(void) {
    const int w = epd_rotated_display_width();
    int px = w / 4;
    if (px > 300) px = 300;
    if (px < 160) px = 160;
    return px;
}
static int lock_clock_row_cy(void) {
    // 46%：横屏时分行再上移一点，底部日期与解锁提示留出更多空白。
    // 46%: move the landscape HH:MM row up a little, leaving more room below for the date.
    return epd_rotated_display_height() * 46 / 100;
}
static EpdRect lock_clock_row_area(void) {
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    const int px = lock_clock_row_px();
    int width = ui_text_fixed_width_px(px, "00:00") + 24;
    if (width > w - 40) width = w - 40;
    const int height = px + 8;
    int top = lock_clock_row_cy() - height / 2;
    if (top < 0) top = 0;
    if (top + height > h) top = h - height;
    return (EpdRect){w / 2 - width / 2, top, width, height};
}
// 两行时间行距：按两行数字的实际字面高度相加，再留一小段空隙；整体块居中在屏幕 47%
// 处。旧版固定 37%/61% 两行，间隔过大；现在竖屏两行中心距约 180px、横屏约 115px，
// 两行数字之间只留二三十像素的空隙，看起来是一组时间而不是两行分开的字。
// Two-line spacing: add the two digit heights, then a small gap, and centre the block at 47% of
// the screen. The old fixed 37%/61% anchors left a large hole; now the centres sit about 180px
// apart in portrait and 115px in landscape, with only a small gap between the digit rows.
static int lock_clock_spacing(void) {
    const int hour_px = lock_clock_hour_px();
    const int minute_px = lock_clock_minute_px();
    // 数字字面高度大约是字号的 0.72；两行各取一半相加，再留出 minute_px/8 的空隙。
    // Digit face height is about 0.72 em; take half from each row and add a small gap.
    int spacing = (hour_px + minute_px) * 36 / 100;
    int gap = minute_px / 8;
    if (gap < 16) gap = 16;
    return spacing + gap;
}
static int lock_clock_hour_cy(void) {
    const int h = epd_rotated_display_height();
    return h * 47 / 100 - lock_clock_spacing() / 2;
}
static int lock_clock_minute_cy(void) {
    const int h = epd_rotated_display_height();
    return h * 47 / 100 + lock_clock_spacing() / 2;
}
// 两行时间：上行小时、下行分钟；局刷区域同时覆盖两行，改点前后左右都清得干净。
// Two-line time: hours on top, minutes below; the area refresh covers both lines.
static EpdRect lock_clock_time_area(void) {
    if (lock_clock_landscape()) return lock_clock_row_area();
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    const int hour_px = lock_clock_hour_px();
    const int minute_px = lock_clock_minute_px();
    int width = (minute_px > hour_px ? minute_px : hour_px) * 2 + minute_px / 3;
    if (width > w - 40) width = w - 40;
    int top = lock_clock_hour_cy() - hour_px;
    int bottom = lock_clock_minute_cy() + minute_px * 2 / 3;
    if (top < 0) top = 0;
    if (bottom > h) bottom = h;
    return (EpdRect){w / 2 - width / 2, top, width, bottom - top};
}
static void lock_clock_draw_time(uint8_t *framebuffer) {
    struct tm now;
    if (!lock_clock_now(&now)) return;
    // 横屏：一行「时:分」，按画布宽度取大字，四周留白由行块矩形统一清掉。
    // Landscape: one HH:MM row sized from the canvas width; the row block clears its own margin.
    if (lock_clock_landscape()) {
        epd_fill_rect(lock_clock_row_area(), 0xff, framebuffer);
        char row[16];
        snprintf(row, sizeof(row), "%02d:%02d", now.tm_hour, now.tm_min);
        ui_text_fixed_vc(framebuffer, epd_rotated_display_width() / 2, lock_clock_row_cy(),
                         lock_clock_row_px(), row, EPD_DRAW_ALIGN_CENTER, false);
        return;
    }
    const int w = epd_rotated_display_width();
    const EpdRect area = lock_clock_time_area();
    epd_fill_rect(area, 0xff, framebuffer);
    char hour[8], minute[8];
    snprintf(hour, sizeof(hour), "%02d", now.tm_hour);
    snprintf(minute, sizeof(minute), "%02d", now.tm_min);
    ui_text_fixed_vc(framebuffer, w / 2, lock_clock_hour_cy(), lock_clock_hour_px(),
                     hour, EPD_DRAW_ALIGN_CENTER, false);
    ui_text_fixed_vc(framebuffer, w / 2, lock_clock_minute_cy(), lock_clock_minute_px(),
                     minute, EPD_DRAW_ALIGN_CENTER, false);
}
// 分钟局刷只覆盖分钟那一行：比两行整块小一半以上，刷新更快，刷屏挡住按键的窗口更短。
// Minute-only refresh area: less than half of the two-line block, so it lands faster and the
// window where the panel blocks key polling is shorter.
static EpdRect lock_clock_minute_area(void) {
    if (lock_clock_landscape()) return lock_clock_row_area();
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    const int minute_px = lock_clock_minute_px();
    int width = minute_px * 2 + minute_px / 3;
    if (width > w - 40) width = w - 40;
    int top = lock_clock_minute_cy() - minute_px * 3 / 5;
    // 分钟局刷矩形的上边不能压到小时行：白底填充会把小时数字的下缘切掉一块。
    // The minute refresh rect must not reach into the hour row, or its white fill clips the
    // bottom of the hour digits.
    const int hour_floor = lock_clock_hour_cy() + lock_clock_hour_px() / 2 + 6;
    if (top < hour_floor) top = hour_floor;
    int bottom = lock_clock_minute_cy() + minute_px / 2;
    if (top < 0) top = 0;
    if (bottom > h) bottom = h;
    if (bottom <= top) bottom = top + 1;
    return (EpdRect){w / 2 - width / 2, top, width, bottom - top};
}
static void lock_clock_draw_minute(uint8_t *framebuffer) {
    // 横屏的时间只有一行，分钟变化就重画这一行（区域已由 lock_clock_minute_area 给到）。
    // Landscape shows one row, so a minute change repaints that row; its area comes from the
    // matching lock_clock_minute_area().
    if (lock_clock_landscape()) {
        lock_clock_draw_time(framebuffer);
        return;
    }
    struct tm now;
    if (!lock_clock_now(&now)) return;
    const int w = epd_rotated_display_width();
    const EpdRect area = lock_clock_minute_area();
    epd_fill_rect(area, 0xff, framebuffer);
    char minute[8];
    snprintf(minute, sizeof(minute), "%02d", now.tm_min);
    ui_text_fixed_vc(framebuffer, w / 2, lock_clock_minute_cy(), lock_clock_minute_px(),
                     minute, EPD_DRAW_ALIGN_CENTER, false);
}
static bool draw_lock_clock(uint8_t *framebuffer) {
    if (!framebuffer) return false;
    struct tm now;
    if (!lock_clock_now(&now)) return false;
    const int w = epd_rotated_display_width();
    const int h = epd_rotated_display_height();
    if (w <= 0 || h <= 0) return false;
    epd_fill_rect((EpdRect){0, 0, w, h}, 0xff, framebuffer);
    // 小字（签名/日期）各 +6px，横屏把日期略上提，避开底部的解锁提示。
    // Small text (signature/date) grows by 6px; landscape lifts the date slightly to clear the
    // unlock hint at the bottom.
    const char *signature = app_settings_status_signature();
    if (signature && signature[0])
        ui_text_fixed_vc(framebuffer, w / 2, (w > h) ? h * 10 / 100 : h * 15 / 100, 36, signature,
                         EPD_DRAW_ALIGN_CENTER, false);
    lock_clock_draw_time(framebuffer);
    static const char *const weekdays[] = {"日", "一", "二", "三", "四", "五", "六"};
    char date[80];
    snprintf(date, sizeof(date), "%d年%d月%d日 星期%s",
             now.tm_year + 1900, now.tm_mon + 1, now.tm_mday, weekdays[now.tm_wday]);
    ui_text_fixed_vc(framebuffer, w / 2, (w > h) ? h * 82 / 100 : h * 81 / 100, 44, date,
                     EPD_DRAW_ALIGN_CENTER, false);
    return true;
}

static cst836u_handle_t s_tp;
static sc7a20h_handle_t s_acc;
static bool s_acc_was_on;

void app_sleep_bind(cst836u_handle_t tp, sc7a20h_handle_t acc) {
    s_tp = tp;
    s_acc = acc;
    // 没开 PM 时 IDF 不分配 CPU 保存区，浅睡里 CPU 不会掉电；这里手动申请一次。
    // Without PM, IDF never allocates CPU retention, so light sleep keeps the CPU powered; request it once here.
    esp_err_t err = sleep_cpu_configure(true);
    if (err != ESP_OK) ESP_LOGW(TAG, "CPU light-sleep power-down off: %s", esp_err_to_name(err));
}

// 触摸、加速度计都在常开 3V3 上，ESP 浅睡或 EN 拉低都不会断它们的电，必须主动送进最低功耗态。
// Touch and accelerometer sit on the always-on 3V3; neither light sleep nor EN low cuts them, so park them explicitly.
static void periph_suspend(bool host_off) {
    if (read_pico_buzzer_score_busy()) (void)read_pico_buzzer_score_stop();
    esp_err_t ioe = read_pico_ioe_sleep(host_off);
    if (ioe != ESP_OK) ESP_LOGW(TAG, "ioe sleep %s", esp_err_to_name(ioe));
    s_acc_was_on = sc7a20h_powered(s_acc);
    if (s_acc_was_on) (void)sc7a20h_power_down(s_acc);
    if (s_tp != NULL && cst836u_get_mode(s_tp) != CST836U_MODE_DEEPSLEEP) {
        esp_err_t err = cst836u_set_mode(s_tp, CST836U_MODE_DEEPSLEEP);
        if (err != ESP_OK) ESP_LOGW(TAG, "touch deepsleep %s", esp_err_to_name(err));
    }
}

// 深睡的触摸只认 TP_RST 复位；加速度计按睡前的配置重新上电。
// Deep-sleeping touch only wakes via TP_RST; the accelerometer comes back with its pre-sleep config.
static void periph_resume(void) {
    (void)read_pico_ioe_wake();
    if (s_tp != NULL && cst836u_get_mode(s_tp) == CST836U_MODE_DEEPSLEEP) {
        esp_err_t err = cst836u_wake(s_tp);
        if (err != ESP_OK) ESP_LOGW(TAG, "touch wake %s", esp_err_to_name(err));
    }
    if (s_acc_was_on) (void)sc7a20h_power_up(s_acc);
    s_acc_was_on = false;
}

// 单击提示只保留一个小区域；等待双击窗口结束才绘制，触摸仅临时唤醒三秒。
// Retain one small hint region; draw after the double-click window and wake touch for only three seconds.
static EpdiyHighlevelState *s_lock_hint_hl;
static struct {
    uint8_t *pixels;
    EpdRect area;
    uint32_t serial;
    int64_t pending_at, touch_until;
    bool touch_awake;
} s_lock_hint;

static uint8_t lock_hint_pixel(uint8_t *fb,int x,int y) {
    int px=x,py=y;
    switch(epd_get_rotation()) {
        case EPD_ROT_PORTRAIT:px=epd_width()-y-1;py=x;break;
        case EPD_ROT_INVERTED_LANDSCAPE:px=epd_width()-x-1;py=epd_height()-y-1;break;
        case EPD_ROT_INVERTED_PORTRAIT:px=y;py=epd_height()-x-1;break;
        default:break;
    }
    return epd_get_pixel(px,py,epd_width(),epd_height(),fb);
}

static void lock_hint_present(void) {
    epd_poweron();
    enum EpdDrawError result=update_display_area_diff_with(s_lock_hint_hl,&E0470_WAVEFORM,MODE_GL16,s_lock_hint.area);
    guard_draw_result(s_lock_hint_hl,result);
    epd_poweroff();
}

static void lock_hint_finish(bool restore) {
    if(s_lock_hint.pixels) {
        uint8_t *fb=epd_hl_get_framebuffer(s_lock_hint_hl);
        EpdRect r=s_lock_hint.area;
        for(int y=0;y<r.height;++y)for(int x=0;x<r.width;++x) {
            size_t i=(size_t)y*r.width+x;
            uint8_t v=(s_lock_hint.pixels[i/2]>>((i&1)*4))&15;
            epd_draw_pixel(r.x+x,r.y+y,(uint8_t)(v*17),fb);
        }
        if(restore)lock_hint_present();
        heap_caps_free(s_lock_hint.pixels);s_lock_hint.pixels=NULL;
    }
    if(s_lock_hint.touch_awake && s_tp) (void)cst836u_set_mode(s_tp,CST836U_MODE_DEEPSLEEP);
    s_lock_hint.touch_awake=false;s_lock_hint.pending_at=s_lock_hint.touch_until=0;
}

static void lock_hint_service(void) {
    if(!s_lock_hint_hl)return;
    int64_t now=esp_timer_get_time()/1000;
    uint32_t serial=read_pico_pmu_lock_key_serial();
    if(serial!=s_lock_hint.serial) {
        s_lock_hint.serial=serial;s_lock_hint.pending_at=now+650;
    }
    if(s_lock_hint.pending_at && now>=s_lock_hint.pending_at) {
        s_lock_hint.pending_at=0;s_lock_hint.touch_until=now+3000;
        if(!s_lock_hint.pixels) {
            uint8_t *fb=epd_hl_get_framebuffer(s_lock_hint_hl);
            const int w=epd_rotated_display_width(),h=epd_rotated_display_height();
            s_lock_hint.area=(EpdRect){(w-448)/2, w>h ? h-74 : h-196, 448, 72};
            if(fb && w>=448 && h>=268)
                s_lock_hint.pixels=heap_caps_calloc(1,448u*72u/2u,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
            if(s_lock_hint.pixels) {
                EpdRect r=s_lock_hint.area;
                for(int y=0;y<r.height;++y)for(int x=0;x<r.width;++x) {
                    size_t i=(size_t)y*r.width+x;
                    s_lock_hint.pixels[i/2]|=(lock_hint_pixel(fb,r.x+x,r.y+y)>>4)<<((i&1)*4);
                }
                ui_fill_round_rect(fb,r,28,UI_GRAY_WHITE);
                ui_draw_round_rect(fb,r,28,UI_GRAY_BLACK);
                ui_text_fixed_vc(fb,w/2,r.y+r.height/2,28,
                                 app_settings_wake_presses()==1?"单击电源键解锁":"双击电源键解锁",
                                 EPD_DRAW_ALIGN_CENTER,false);
                lock_hint_present();
            }
        }
        if(!s_lock_hint.touch_awake && s_tp && cst836u_wake(s_tp)==ESP_OK)s_lock_hint.touch_awake=true;
    }
    if(s_lock_hint.touch_until && now>=s_lock_hint.touch_until)lock_hint_finish(true);
    if(s_lock_hint.touch_awake && s_tp) {
        cst836u_touch_t touch={0};
        // 窗口内点屏保留同一提示，不重绘、不累计延时，也绝不触发解锁。
        // Screen taps retain this hint without redraws or extending the window, and can never unlock.
        (void)cst836u_read(s_tp,&touch);
    }
}

static bool lock_wait_key(void) {
    bool wake = app_settings_wake_presses() == 1
        ? read_pico_pmu_take_key_wakeup_single() : read_pico_pmu_take_key_wakeup();
    if(wake)return true;
    lock_hint_service();return false;
}

static void lock_arm_ioe_wakeup(void) {
    gpio_config_t io = {
        .pin_bit_mask = 1ULL << READ_PICO_IOE_INT_GPIO,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
    read_pico_clear_ioe_int();
    gpio_wakeup_enable((gpio_num_t)READ_PICO_IOE_INT_GPIO, GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
}

void app_lock_wait_key_idle(int timeout_ms) {
    int64_t start = esp_timer_get_time() / 1000;
    int64_t high_from = 0;
    while (esp_timer_get_time() / 1000 - start < timeout_ms) {
        read_pico_pmu_drain_events();
        read_pico_clear_ioe_int();
        bool held = false;
        if (read_pico_pmu_poll() == ESP_OK) {
            held = (read_pico_pmu_get()->key_state & 0x01) != 0;
        }
        bool int_high = gpio_get_level((gpio_num_t)READ_PICO_IOE_INT_GPIO) != 0;
        if (!held && int_high) {
            if (high_from == 0) high_from = esp_timer_get_time() / 1000;
            if (esp_timer_get_time() / 1000 - high_from >= 150) return;
        } else {
            high_from = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

app_wake_source_t app_last_wake_source(void) {
    return (app_wake_source_t)app_settings_last_wake();
}

static void pickup_ack(sc7a20h_handle_t acc) {
    sc7a20h_events_t ev;
    sc7a20h_read_events(acc, &ev);
    sc7a20h_ack_int(acc);
}

static bool pickup_ia(sc7a20h_handle_t acc) {
    sc7a20h_events_t ev;
    sc7a20h_aoi_src_t aoi;
    if (sc7a20h_read_events(acc, &ev) != ESP_OK) return false;
    sc7a20h_aoi_decode(ev.aoi1_src, &aoi);
    return aoi.ia;
}

// 第一次低电平不够：高通余波还会再拉高。要连续安静一段时间才进浅睡。
// A first low is not enough: high-pass ringing can rise again. Wait for a quiet stretch before light sleep.
static bool pickup_wait_quiet(sc7a20h_handle_t acc, int quiet_ms, int timeout_ms) {
    int64_t start = esp_timer_get_time() / 1000;
    int64_t low_from = 0;
    while (esp_timer_get_time() / 1000 - start < timeout_ms) {
        if (sc7a20h_int1_level(acc) == 0) {
            if (low_from == 0) low_from = esp_timer_get_time() / 1000;
            if (esp_timer_get_time() / 1000 - low_from >= quiet_ms) return true;
        } else {
            pickup_ack(acc);
            low_from = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    return false;
}

app_wake_source_t app_light_sleep_wait_timed(sc7a20h_handle_t acc, uint32_t timeout_ms) {
    bool covers_idle=book_cover_jobs_quiesce(2000);
    bool avatar_idle=ui_avatar_quiesce(2000);
    bool poll_only=!(covers_idle && avatar_idle);
    bool pickup = acc != NULL && app_settings_pickup_wake();
    bool acc_armed = false;
    const int64_t deadline_us = timeout_ms
        ? esp_timer_get_time() + (int64_t)timeout_ms * 1000 : 0;
    periph_suspend(false);
    lock_arm_ioe_wakeup();
    if (pickup) {
        sc7a20h_motion_cfg_t motion = SC7A20H_MOTION_DEFAULT();
        motion.ths_mg = 350;
        motion.duration = 3;
        sc7a20h_arm_pickup_wake(acc, &motion);
        acc_armed = true;
        pickup_ack(acc);
        if (!pickup_wait_quiet(acc, 400, 2000)) {
            pickup = false;
            ESP_LOGW(TAG, "pickup INT1 stuck high, key only");
        } else {
            sc7a20h_config_light_sleep_wakeup(acc);
            if (!pickup_wait_quiet(acc, 400, 1500)) {
                gpio_wakeup_disable(sc7a20h_int1_gpio(acc));
                pickup = false;
                ESP_LOGW(TAG, "pickup INT1 re-asserted, key only");
            } else {
                // 安静窗口里若 INT1 闪过，ESP 会留下高电平唤醒挂起，关掉再打开清掉。
                // If INT1 glitched in the quiet window, ESP keeps a high-level wake pending; disable then re-enable to clear it.
                gpio_wakeup_disable(sc7a20h_int1_gpio(acc));
                sc7a20h_config_light_sleep_wakeup(acc);
                if (sc7a20h_int1_level(acc) > 0) {
                    gpio_wakeup_disable(sc7a20h_int1_gpio(acc));
                    pickup = false;
                    ESP_LOGW(TAG, "pickup INT1 high at sleep, key only");
                } else {
                    ESP_LOGI(
                        TAG, "wait key GPIO%d or pickup GPIO%d",
                        READ_PICO_IOE_INT_GPIO, (int)sc7a20h_int1_gpio(acc)
                    );
                }
            }
        }
    } else {
        ESP_LOGI(TAG, "wait key on IOE_INT GPIO%d", READ_PICO_IOE_INT_GPIO);
    }

    app_wake_source_t wake = APP_WAKE_NONE;
    int64_t ioe_low_since_us = 0;
    unsigned sleep_errors = 0;
    esp_err_t last_sleep_error = ESP_OK;
    int64_t last_sleep_error_log_ms = 0;
    for (;;) {
        int64_t now_us = esp_timer_get_time();
        // 定时任务到点：不再等下一次按键/超时，立刻交给主循环切到提醒页。
        // A timer is due: stop waiting for a key/timeout and let the loop show the reminder page.
        timer_service_poll();
        if (timer_service_reminder_pending()) {
            wake = APP_WAKE_ALARM;
            ESP_LOGI(TAG, "lock wake by timer reminder");
            break;
        }
        // Check the deadline before every interrupt recovery path. A stuck-low
        // IO expander must never bypass the ten-minute PMU handoff forever.
        // 每次处理中断前先检查期限，避免 IO 扩展器低电平让票根永远停住。
        if (deadline_us && now_us >= deadline_us) {
            wake = APP_WAKE_TIMEOUT;
            ESP_LOGI(TAG, "lock light sleep timeout after %u ms", (unsigned)timeout_ms);
            break;
        }
        // The PMU event is authoritative even if the IOE edge was missed.
        // Timer wakeups below provide a bounded fallback poll for that case.
        // 即使漏掉 IOE 中断，也由定时唤醒轮询 PMU 按键事件。
        if (lock_wait_key()) {
            wake = APP_WAKE_KEY;
            break;
        }
        if(poll_only) {vTaskDelay(pdMS_TO_TICKS(40));continue;}
        read_pico_clear_ioe_int();
        if (gpio_get_level((gpio_num_t)READ_PICO_IOE_INT_GPIO) == 0) {
            if (!ioe_low_since_us) ioe_low_since_us = now_us;
            if (now_us - ioe_low_since_us >= APP_LOCK_STUCK_IRQ_US) {
                // 中断或浅睡异常只能回退到轮询，不能冒充双击解锁。/ Fall back to polling on IRQ/sleep faults, never synthesize an unlock.
                ESP_LOGW(TAG, "lock IOE_INT stuck low; retain lock and poll key");
                poll_only=true;
            }
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        ioe_low_since_us = 0;
        if (pickup && sc7a20h_int1_level(acc) > 0 && pickup_ia(acc)) {
            wake = APP_WAKE_PICKUP;
            ESP_LOGI(TAG, "pickup wake");
            break;
        }
        if (pickup && sc7a20h_int1_level(acc) > 0) {
            pickup_ack(acc);
            pickup_wait_quiet(acc, 400, 1500);
            continue;
        }
        int64_t sleep_us = APP_LOCK_KEY_POLL_US;
        if(s_lock_hint.pending_at || s_lock_hint.touch_until)sleep_us=100000;
        if (deadline_us) {
            int64_t remaining_us = deadline_us - esp_timer_get_time();
            if (remaining_us < sleep_us) sleep_us = remaining_us;
        }
        if (sleep_us <= 0) continue;
        esp_err_t timer_error = esp_sleep_enable_timer_wakeup((uint64_t)sleep_us);
        if (timer_error != ESP_OK) {
            ESP_LOGW(TAG, "lock sleep timer rejected: %s", esp_err_to_name(timer_error));
            if (++sleep_errors >= APP_LOCK_SLEEP_ERROR_LIMIT) {
                poll_only=true;
            }
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        int64_t t0 = esp_timer_get_time();
        esp_err_t sleep_error = esp_light_sleep_start();
        int64_t dt_ms = (esp_timer_get_time() - t0) / 1000;
        read_pico_clear_ioe_int();
        if (lock_wait_key()) {
            wake = APP_WAKE_KEY;
            break;
        }
        if (pickup && sc7a20h_int1_level(acc) > 0 && pickup_ia(acc)) {
            if (dt_ms < 80) {
                ESP_LOGW(TAG, "pickup ignored, sleep %lld ms", (long long)dt_ms);
                pickup_ack(acc);
                pickup_wait_quiet(acc, 400, 1500);
                continue;
            }
            wake = APP_WAKE_PICKUP;
            ESP_LOGI(TAG, "pickup wake");
            break;
        }
        if (pickup && sc7a20h_int1_level(acc) > 0) {
            pickup_ack(acc);
            pickup_wait_quiet(acc, 400, 1500);
        }
        if (sleep_error != ESP_OK) {
            int64_t now_ms = esp_timer_get_time() / 1000;
            if (sleep_error != last_sleep_error || now_ms - last_sleep_error_log_ms >= 30000) {
                ESP_LOGW(TAG, "lock light sleep rejected: %s, IOE_INT=%d",
                         esp_err_to_name(sleep_error),
                         gpio_get_level((gpio_num_t)READ_PICO_IOE_INT_GPIO));
                last_sleep_error_log_ms = now_ms;
            }
            last_sleep_error = sleep_error;
            if (++sleep_errors >= APP_LOCK_SLEEP_ERROR_LIMIT) {
                ESP_LOGE(TAG, "lock light sleep repeatedly rejected; retain lock and poll key");
                poll_only=true;
            }
            // A rejected sleep must not spin at full CPU speed behind the static e-paper image.
            vTaskDelay(pdMS_TO_TICKS(100));
        } else {
            last_sleep_error = ESP_OK;
            sleep_errors = 0;
        }
    }

    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
    gpio_wakeup_disable((gpio_num_t)READ_PICO_IOE_INT_GPIO);
    if (acc_armed) {
        gpio_wakeup_disable(sc7a20h_int1_gpio(acc));
        sc7a20h_events_t ev;
        sc7a20h_read_events(acc, &ev);
        sc7a20h_power_down(acc);
        sc7a20h_int1_begin(acc);
    }
    lock_hint_finish(wake!=APP_WAKE_KEY);
    periph_resume();
    app_settings_set_last_wake((uint8_t)(wake == APP_WAKE_TIMEOUT ? APP_WAKE_NONE : wake));
    return wake;
}

app_wake_source_t app_light_sleep_wait(sc7a20h_handle_t acc) {
    return app_light_sleep_wait_timed(acc, 0);
}

// 极简时钟锁屏的分钟循环：只留 PMU RTC 与屏幕，触摸/加速度计/IOE 一直停在最低功耗态。
// 每分钟局刷一次时分，每 20 分钟整屏全刷一次压残影；按键唤醒才返回 true。
// Minute loop for the clock lock: only the PMU RTC and panel stay active; touch/accelerometer/IOE
// stay parked. Area-refresh the time every minute and full-refresh every 20 minutes; true means a
// power key woke the device and the caller should unlock.
static bool lock_clock_take_key(void) {
    return app_settings_wake_presses() == 1
        ? read_pico_pmu_take_key_wakeup_single()
        : read_pico_pmu_take_key_wakeup();
}

static bool lock_clock_run(EpdiyHighlevelState *hl, uint8_t *framebuffer) {
    // 后台封面/头像任务没收尾时不进分钟循环：浅睡不能打断媒体 I/O，交给普通锁屏等待收尾。
    // Do not enter the minute loop while cover/avatar jobs are still touching media; the ordinary
    // lock wait already joins them before sleeping.
    if (!book_cover_jobs_quiesce(2000) || !ui_avatar_quiesce(2000)) return false;
    periph_suspend(false);
    lock_arm_ioe_wakeup();
    int minutes = 0;
    int last_minute = -1;
    int last_hour = -1;
    bool key = false;
    for (;;) {
        // 极简时钟锁屏同样要能看到定时任务：到点直接退出分钟循环，交给提醒页。
        // The minimal clock lock must notice timers too: leave the minute loop when one is due.
        timer_service_poll();
        if (timer_service_reminder_pending()) break;
        struct timeval tv;
        if (gettimeofday(&tv, NULL) || tv.tv_sec < 1704067200) break;
        int64_t to_minute = 60000 - ((int64_t)(tv.tv_sec % 60) * 1000 + (int64_t)tv.tv_usec / 1000);
        if (to_minute < 100) to_minute += 60000;  // 贴边时等下一分钟，避免 0 长度睡眠
        esp_sleep_enable_timer_wakeup((uint64_t)to_minute * 1000ULL);
        // 入睡前再确认一次：按键可能恰好在这轮刷新/计算期间按下。
        // Check once more before sleeping: the key may have arrived during this refresh/loop.
        if (lock_clock_take_key()) {
            key = true;
            break;
        }
        const esp_err_t sleep_error = esp_light_sleep_start();
        esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
        read_pico_clear_ioe_int();
        if (lock_clock_take_key()) {
            key = true;
            break;
        }
        // IOE 边沿已经把 MCU 唤醒但 PMU 事件稍晚到时，等一小段把这次按键读出来，
        // 不能立刻又睡回去把用户按键吞掉。
        // A GPIO edge can wake the MCU a little before the PMU event is readable; poll briefly
        // so the key is not swallowed by the next minute sleep.
        if (gpio_get_level((gpio_num_t)READ_PICO_IOE_INT_GPIO) == 0) {
            bool late = false;
            for (int i = 0; i < 20; ++i) {
                if (lock_clock_take_key()) {
                    late = true;
                    break;
                }
                vTaskDelay(pdMS_TO_TICKS(15));
            }
            if (late) {
                key = true;
                break;
            }
        }
        if (sleep_error != ESP_OK) {
            // 浅睡被拒绝时也必须继续看按键，否则锁屏会像死机一样叫不醒。
            // Even a rejected sleep must keep checking the key, or the lock looks dead.
            if (lock_clock_take_key()) {
                key = true;
                break;
            }
            // 浅睡被拒绝时不刷屏，稍等再试，避免静态画面后面空转耗电。
            // A rejected sleep must not spin at full CPU behind a static image.
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        // 用“墙上分钟”判断是否真的到点：IOE 非按键边沿等杂唤醒不刷新、不计数。
        // Use the wall-clock minute: spurious IOE edges neither repaint nor count a minute.
        struct timeval after;
        if (gettimeofday(&after, NULL) || after.tv_sec < 1704067200) break;
        const int now_minute = (int)((((int64_t)after.tv_sec + 8 * 3600) / 60) % (24 * 60));
        if (now_minute == last_minute) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        last_minute = now_minute;
        ++minutes;
        const int now_hour = now_minute / 60;
        const bool full = (minutes % LOCK_CLOCK_FULL_MINUTES) == 0;
        const bool hour_changed = now_hour != last_hour;
        last_hour = now_hour;
        epd_poweron();
        if (full || hour_changed) {
            // 跨整点/跨日整屏重画一次：分钟局刷只覆盖分钟行，小时行和日期会停在旧值。
            // Repaint the whole face on an hour/day change: the minute-only area does not cover
            // the hour row or the date.
            if (draw_lock_clock(framebuffer))
                guard_draw_result(hl, update_display_full(hl));
        } else {
            lock_clock_draw_minute(framebuffer);
            guard_draw_result(hl, update_display_area_diff_with(
                hl, &E0470_WAVEFORM, MODE_GL16, lock_clock_minute_area()));
        }
        epd_poweroff();
        // 刷屏期间按键无法轮询；留 400ms 窗口把刷新期间按下的一键/双击读出来，再清杂事件，
        // 否则电源键可能正好被刷屏吞掉，表现成“锁屏叫不醒”。
        // A refresh blocks key polling; give a short grace window so a single or double press
        // that happened during the refresh still unlocks instead of being dropped by the panel.
        bool unlocked = false;
        for (int i = 0; i < 20; ++i) {
            if (lock_clock_take_key()) {
                unlocked = true;
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(20));
        }
        if (unlocked) {
            key = true;
            break;
        }
        read_pico_pmu_drain_events();
    }
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
    gpio_wakeup_disable((gpio_num_t)READ_PICO_IOE_INT_GPIO);
    periph_resume();
    return key;
}

esp_err_t app_enter_host_sleep(app_sleep_mode_t mode) {
    if (mode != APP_SLEEP_OFF && mode != APP_SLEEP_DEEP) return ESP_ERR_INVALID_ARG;
    // 低优先级断电任务可能正在写 SY7636A，先等它收尾再走电源流程。
    // The low-priority power-off task may be writing SY7636A; let it finish before the power path.
    display_quiet_rails_off();
    // 产品页用 on_before_lock 保存并收齐后台；保留阅读内存以便交接失败仍可回到原页。
    // Product pages checkpoint/join in on_before_lock; retain reader state so a failed handoff can resume the same page.
    if (pico_online_busy() || !(book_cover_jobs_quiesce(2000) && ui_avatar_quiesce(2000)) || !read_pico_transfer_pause_for_sleep()) return ESP_ERR_INVALID_STATE;
    // 彻底关机时清掉 PMU RTC 闹钟，避免用户关机后到点又被闹钟开机。
    // A full power-off clears the PMU RTC alarm so the device cannot be powered back on by a timer.
    if (mode == APP_SLEEP_OFF) timer_service_pmu_alarm_off();
    (void)ble_pt_stop(2000);
    (void)app_sync_time_to_pmu();
    // 必须先断面板轨，再拉低 MODE，避免常开逻辑仍耗电。/ Drop panel rails before parking MODE on the always-on supply.
    pmu_selftest_prepare_powerdown();
    periph_suspend(true);
    esp_err_t err = ESP_FAIL;
    const unsigned attempts = mode == APP_SLEEP_OFF ? 1 : 3;
    for (unsigned attempt = 0; attempt < attempts; ++attempt) {
        err = mode == APP_SLEEP_OFF ? read_pico_pmu_power_off() : read_pico_pmu_report_sleep();
        ESP_LOGI(TAG, "%s attempt %u: %s", mode == APP_SLEEP_OFF ? "power off" : "SOFT_SLEEP",
                 attempt + 1, esp_err_to_name(err));
        if (err == ESP_OK) {
            vTaskDelay(pdMS_TO_TICKS(HOST_EN_DROP_WAIT_MS));
            err = ESP_ERR_TIMEOUT;
            ESP_LOGE(TAG, "EN still high after PMU ack");
            break;
        }
        if (attempt + 1 < attempts) vTaskDelay(pdMS_TO_TICKS(200));
    }
    // 失败不复位重试；恢复外设，交还锁屏/密码层，阅读恢复检查点仍由原入口处理。
    // Do not reset/retry on failure; restore peripherals to the lock/PIN caller, which retains checkpoint ownership.
    periph_resume();
    read_pico_transfer_resume_after_sleep();
    return err;
}

esp_err_t app_sync_time_to_pmu(void) {
    time_t now = time(NULL);
    if (now < 946684800 || now > 4102444799U) {
        ESP_LOGW(TAG, "skip PMU time sync: system clock invalid");
        return ESP_ERR_INVALID_STATE;
    }
    uint32_t seconds = (uint32_t)now;
    uint8_t payload[4] = {
        (uint8_t)(seconds & 0xff),
        (uint8_t)((seconds >> 8) & 0xff),
        (uint8_t)((seconds >> 16) & 0xff),
        (uint8_t)((seconds >> 24) & 0xff),
    };
    esp_err_t err = read_pico_pmu_cmd(PMU_CMD_TIME_SYNC, payload, sizeof(payload));
    ESP_LOGI(TAG, "PMU time sync before power action: %s", esp_err_to_name(err));
    return err;
}

void app_restart_host(void) {
    (void)app_sync_time_to_pmu();
    pmu_selftest_prepare_powerdown();
    esp_err_t err = read_pico_pmu_action(PMU_ACTION_HOST_NORMAL_RESTART, 250, 0x5052);
    ESP_LOGI(TAG, "normal restart: %s", esp_err_to_name(err));
    if (err != ESP_OK) esp_restart();
    while (true) vTaskDelay(pdMS_TO_TICKS(1000));
}

// 防泛白/防反黑重推：不重绘锁屏，只把 framebuffer 里已画好的帧用全像素 GL16 重推一遍——
// 白底吃 GL16 的 15→15 白推、黑字回纯黑，不压黑、不整屏闪，抑制强光下慢慢泄漏的电荷
// （用户反馈票根锁屏久置发灰/发黑，且要求不要靠整屏全刷压）。
// Anti-fade re-drive: no repaint; re-drive the painted lock frame with full-pixel GL16 so the white
// ground gets the 15->15 white push and black text returns to pure black, without a black erase or a
// whole-screen flash (users report the ticket lock fading/darkening when left alone, and rejected a
// periodic full flash as the fix).
static void lock_face_anti_fade(EpdiyHighlevelState *hl) {
    if (!hl) return;
    guard_draw_result(hl, update_display_anti_fade(hl));
    epd_poweroff();
    ESP_LOGI(TAG, "lock anti-fade GL16 white push");
}

// 深睡前记下锁屏帧保存时的墙钟秒；唤醒时与当前时间比较，只有睡够防褪色间隔才重推。
// RTC memory survives deep sleep; record the wall clock so a wake-up only re-drives a frame that
// slept long enough to fade.
static RTC_DATA_ATTR uint32_t s_lock_frame_unix;
static RTC_DATA_ATTR bool s_lock_frame_valid;

void enter_lock_and_sleep(
    EpdiyHighlevelState* hl, int64_t* ignore_until_ms, sc7a20h_handle_t acc, cst836u_handle_t touch,
    bool reader_background
) {
    bool feedback_visible = s_lock_feedback_visible;
    s_lock_feedback_visible = false;
    // 锁屏会直接调用 epd_poweroff；先等低优先级断电任务收尾，避免两路同时写 SY7636A。
    // The lock face calls epd_poweroff directly; wait for the low-priority power-off task first so
    // two paths never touch SY7636A at the same time.
    display_quiet_rails_off();
    // 夜间自动反色：锁屏画面也按当前昼夜窗口建立，避免 21:00 后/07:00 前锁屏仍是白底。
    // Night auto-inversion: build the lock face with the current window so a 21:00 lock is dark too.
    if (app_settings_invert_night() && epd_get_inverted() != app_settings_invert_effective()) {
        display_set_inverted(hl, app_settings_invert_effective());
    }
    // Refuse to interrupt an active upload. The caller repaints its page when
    // this function returns, and the user can lock again after the transfer.
    bool radio_paused = read_pico_transfer_pause_for_sleep();
    if (!radio_paused) {
        pico_boot_clear_resume();
        ESP_LOGW(TAG, "lock postponed while transfer is busy");
        return;
    }
    uint8_t* framebuffer = epd_hl_get_framebuffer(hl);
    // 主动拼贴在白底圆锁上准备最终画面；其他入口仍保留旧页面，只改RAM。
    // Prepare manual collages behind the white lock badge; other entries keep their prior page while drawing RAM.
    uint8_t lock_style = app_settings_lock_style();
    // 时间锁屏选择横屏时，锁屏全过程（绘制、每分钟刷新、解锁提示）都用横屏逻辑画布；
    // 退出锁屏前恢复调用前的方向，主界面和阅读页不受影响。
    // When the clock lock is set to landscape, the whole lock (face, minute refresh and unlock
    // hint) uses the rotated canvas; the previous rotation is restored before returning.
    const bool clock_landscape = lock_style == 4 && !lock_pin_enabled() &&
                                 app_settings_lock_clock_landscape();
    const int prior_rotation = (int)epd_get_rotation();
    // 锁屏与 PIN 键盘都按工厂竖屏排版（键盘和命中区硬编码 684x1216）：先从阅读横屏/
    // 倒置竖屏归一，再按设置决定时间锁屏是否横屏；退出时统一恢复调用前方向。
    // Lock and PIN panels are laid out for factory portrait (keypad/hit boxes hard-coded at
    // 684x1216): normalise first, then let the clock setting choose landscape; the caller
    // rotation is restored on exit.
    epd_set_rotation(clock_landscape ? EPD_ROT_LANDSCAPE : EPD_ROT_INVERTED_PORTRAIT);
    // 透明书封保留当前页面作为底图，不清白、不重排阅读页，也不读取旧阅读快照。
    // Keep the current page beneath the PNG; no white reset, reader reflow or old reader snapshot.
    if (lock_style != 3) epd_hl_set_all_white(hl);
    else memcpy(framebuffer,hl->back_fb,(size_t)epd_width()*epd_height()/2);
    bool ticket = lock_style == 0;
    bool system_lock = ticket || lock_style == 2 || lock_style == 4 || lock_pin_enabled();
    app_lock_font_t lock_font = {0};
    if (system_lock) app_font_begin_lock(&lock_font);
    // 阅读票根独占锁屏画布：始终先画最近书籍封面，再叠票根；自定义壁纸只属于壁纸模式。
    // Ticket mode owns the lock canvas: book cover first, ticket on top. Custom wallpaper is wallpaper-only.
    bool lock_drawn = ticket
        ? book_ticket_draw(framebuffer, reader_background)
        : lock_style == 2 ? book_lock_collage_prepare(framebuffer) :
          lock_style == 3 ? book_lock_bookmark_draw(framebuffer,app_settings_bookmark_path()) :
          lock_style == 4 ? draw_lock_clock(framebuffer) : draw_wallpaper(framebuffer);
    if (!lock_drawn) {
        ui_lock_fallback_draw(framebuffer);
    }
    // 反色模式下壁纸保持正常灰阶：壁纸先按正常极性画好，再把整块画布预反相一次，
    // 扫描出口的反相会把它翻回原图（深睡保留的锁屏帧同样保存为可显示帧）。
    // In inverted mode the wallpaper must stay a normal photo: draw it normally, then
    // pre-invert the whole canvas so the scan-time inversion cancels out.
    if (lock_style == 1 && lock_drawn && epd_get_inverted() &&
        !ui_wallpaper_lock_display_ready())
        display_invert_area(framebuffer, (EpdRect){0, 0, epd_rotated_display_width(),
                                                   epd_rotated_display_height()});
    enum EpdDrawError result = EPD_DRAW_SUCCESS;
    if (feedback_visible) result = update_display_full(hl);
    if (!feedback_visible || result != EPD_DRAW_SUCCESS) {
        // 反馈成功时不再重复清白；GC16从真实圆锁历史输出。自动/其他样式/失败保留原清屏。
        // A successful badge needs no second white clear; GC16 uses its true history. Idle/other/fault paths retain original clearing.
        epd_poweron();
        epd_clear();
        result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    }
    if (lock_style == 2 && lock_drawn && result == EPD_DRAW_SUCCESS) book_lock_collage_cache_commit(framebuffer);
    if (lock_style == 1 && lock_drawn && result == EPD_DRAW_SUCCESS) ui_wallpaper_cache_commit(framebuffer);
    // 锁屏入口只在“真实锁图成功显示”后写缓存（rc100 时机）：密码层、兜底图、浅睡提示都不得覆盖。
    // Persist only a successfully displayed real lock face at the lock entry (rc100 timing); the PIN
    // layer, fallback faces and light-sleep hints must never overwrite it.
    if (lock_drawn && result == EPD_DRAW_SUCCESS && lock_screen_save(framebuffer))
        (void)pico_boot_mark_frame_cached();

    app_lock_wait_key_idle(800);
    // 极简时钟：每分钟局刷、每 20 分钟整屏全刷；这段时间只保留 PMU RTC 与屏幕，
    // 触摸/加速度计/IOE 都停在最低功耗态，按键仍由 IOE 中断唤醒。
    // Minimal clock: minute area updates and a 20-minute full refresh; only the PMU RTC and the
    // panel stay awake, while touch/accelerometer/IOE stay parked and the key still wakes via IOE IRQ.
    const bool clock_lock = lock_style == 4 && lock_drawn && result == EPD_DRAW_SUCCESS &&
                            !lock_pin_enabled();
    // 锁屏先浅睡，十分钟后进入深睡；按键唤醒使用已保存的页面检查点。
    // Locks light-sleep first, enter deep sleep after ten minutes and wake through the saved page checkpoint.
    ESP_LOGI(TAG, "lock LIGHT clock=%d", (int)clock_lock);
    epd_poweroff();
    s_lock_hint_hl=hl;s_lock_hint.serial=read_pico_pmu_lock_key_serial();
    app_wake_source_t wake = APP_WAKE_KEY;
    if (lock_pin_enabled()) {
        lock_screen_authenticate(hl, touch, acc, false);
    } else if (clock_lock) {
        if (!lock_clock_run(hl, framebuffer)) {
            // 时间失效或浅睡持续失败：退回普通锁屏等待，按键仍可唤醒。
            // Time lost or sleep kept failing: fall back to the ordinary key wait; the key still wakes.
            wake = app_light_sleep_wait_timed(NULL, APP_LOCK_LIGHT_SLEEP_MS);
        }
    } else {
        // 有定时任务时保持“定时浅睡唤醒”，ESP 计时比 PMU RTC 准，到点才提示；没有任务时
        // 完全沿用原来的十分钟浅睡后转深睡，不额外增加睡眠循环。
        // With a timer task keep timed light-sleep wakeups because the ESP timer is more accurate
        // than the PMU RTC; without one the original ten-minute handoff to deep sleep is unchanged.
        timer_service_arm_pmu_alarm();
        // 票根/壁纸/拼贴锁屏：前十分钟浅睡期间按防泛白间隔把锁屏帧用全像素 GL16 白推一遍，
        // 避免强光下电荷泄漏让画面在入睡前就变灰；不压黑不整屏闪，之后照旧交深睡。
        // Ticket/wallpaper/collage locks: during the first ten light-sleeping minutes re-drive the
        // lock frame with a full-pixel GL16 white push at the anti-fade interval so strong-light
        // leakage cannot fade it before deep sleep (no black erase, no whole-screen flash); the
        // ten-minute deep-sleep handoff is unchanged.
        const int64_t lock_entry_ms = esp_timer_get_time() / 1000;
        const int64_t lock_deep_at_ms = lock_entry_ms + APP_LOCK_LIGHT_SLEEP_MS;
        const unsigned lock_af = anti_fade_minutes();
        const int64_t lock_af_ms = (int64_t)lock_af * 60000;
        (void)anti_fade_due(lock_entry_ms, lock_entry_ms, true);
        for (;;) {
            timer_service_poll();
            if (timer_service_reminder_pending()) {
                wake = APP_WAKE_ALARM;
                break;
            }
            const uint32_t deadline = timer_service_deadline_ms();
            uint32_t slice = APP_LOCK_LIGHT_SLEEP_MS;
            if (deadline != 0 && deadline < slice) slice = deadline;
            const int64_t now = esp_timer_get_time() / 1000;
            if (lock_deep_at_ms > now && lock_deep_at_ms - now < (int64_t)slice)
                slice = (uint32_t)(lock_deep_at_ms - now);
            if (lock_af_ms > 0 && lock_af_ms < (int64_t)slice) slice = (uint32_t)lock_af_ms;
            if (slice == 0) slice = 1;
            wake = app_light_sleep_wait_timed(NULL, slice);
            if (wake != APP_WAKE_TIMEOUT) break;
            timer_service_poll();
            if (timer_service_reminder_pending()) {
                wake = APP_WAKE_ALARM;
                break;
            }
            const int64_t after = esp_timer_get_time() / 1000;
            const bool last_slice = deadline == 0 &&
                (!lock_af || after + 1000 >= lock_deep_at_ms);
            if (!last_slice && lock_af && anti_fade_due(after, lock_entry_ms, false))
                lock_face_anti_fade(hl);
            if (deadline != 0) continue;
            if (!lock_af || after >= lock_deep_at_ms) break;  // 无任务：十分钟后深睡 / no task: deep sleep after ten minutes
        }
    }
    while (wake == APP_WAKE_TIMEOUT) {
        // PMU SOFT_SLEEP drops the ESP rail while keeping its RTC alive. A short
        // power-key press boots the host; the e-paper keeps this lock image.
        // 深睡前把最近的定时任务写进 PMU RTC 闹钟，到点由 PMU 给主机上电。
        // Arm the nearest timer in the PMU RTC alarm before deep sleep so it can power the host on.
        timer_service_arm_pmu_alarm();
        if(lock_drawn && result==EPD_DRAW_SUCCESS && !lock_pin_enabled() && lock_screen_save(framebuffer))
            (void)pico_boot_mark_frame_cached();
        // 记录锁屏帧入睡时刻，唤醒时据此决定是否重推（防褪色）。
        // Stamp the frame before deep sleep; a wake-up uses it to decide whether to re-drive.
        const time_t stamp = time(NULL);
        s_lock_frame_valid = stamp >= 1704067200 && stamp <= 4102444799LL;
        if (s_lock_frame_valid) s_lock_frame_unix = (uint32_t)stamp;
        app_enter_host_sleep(APP_SLEEP_DEEP);
        wake=app_light_sleep_wait_timed(NULL,APP_LOCK_LIGHT_SLEEP_MS);
    }
    if ((int)epd_get_rotation() != prior_rotation) epd_set_rotation((enum EpdRotation)prior_rotation);
    pico_boot_clear_resume();
    s_lock_hint_hl=NULL;
    if (system_lock) app_font_end_lock(&lock_font);
    read_pico_transfer_resume_after_sleep();

    // 参考帧和屏幕都归零，回到主循环后由当前页自己画一遍，不必知道是哪一页。
    // Zero the reference frame and the panel; the current page redraws after the loop resumes, without knowing which page it is.
    read_pico_pmu_drain_events();
    epd_poweron();
    epd_clear();
    epd_hl_set_all_white(hl);
    read_pico_pmu_drain_events();
    if (ignore_until_ms) {
        *ignore_until_ms = esp_timer_get_time() / 1000 + APP_LOCK_IGNORE_BOOT_MS;
    }
    ESP_LOGI(TAG, "unlocked");
}

/* ---- 深睡锁屏恢复服务（S8/rc100） / Deep-wake lock resume service ---- */
// 不阻塞等卡：每次只检查一次挂载状态。挂载就绪且缓存校验通过时，只把缓存恢复进 framebuffer
// 并把 back 基准同步成它，绝不推屏——面板上仍是深睡前的锁屏原画；恢复失败/无卡则返回 -1，
// 由 app_main 走原来的「清白 + 锁屏兜底」路径，保证 back 基准始终有定义。
// Never block on the card: each call checks the mount once. When the card is ready and the cached
// art validates, only the framebuffer and its back baseline are restored -- nothing is pushed, so
// the panel keeps its pre-sleep lock image. A failure or absent card returns -1 and app_main uses
// the original clear + fallback lock-face path, so the back baseline is always defined.
static EpdiyHighlevelState *s_boot_lock_hl;
static int lock_resume_service(void) {
    if (!s_boot_lock_hl) return -1;
    read_pico_sd_info_t info;
    if (read_pico_sd_get_info(&info) == ESP_ERR_NOT_FINISHED) return 0;
    EpdiyHighlevelState *hl = s_boot_lock_hl;
    if (!info.mounted) { s_boot_lock_hl = NULL; return -1; }
    uint8_t *fb = epd_hl_get_framebuffer(hl);
    if (!lock_screen_restore(fb)) { s_boot_lock_hl = NULL; return -1; }
    memcpy(hl->back_fb, fb, (size_t)epd_width() * epd_height() / 2);
    s_boot_lock_hl = NULL;
    // 防泛白/防反黑：深睡期间面板一直显示这张锁屏原画，强光下电荷泄漏会让它变灰/发黑。
    // 睡够防泛白间隔（或时间未知）时，用全像素 GL16 把整屏白推一遍恢复白底与黑字；
    // 不压黑、不整屏闪；短睡仍保留面板原画、立即显示，不额外重推。
    // Anti-fade: the panel holds this lock frame all through deep sleep and charge leaks under
    // strong light; when the sleep lasted a full anti-fade interval (or time is unknown), re-drive
    // the frame with a full-pixel GL16 white push to restore the white ground and black text -- no
    // black erase and no whole-screen flash. Short sleeps keep the retained image and show it
    // instantly without a re-drive.
    const unsigned af = anti_fade_minutes();
    const time_t wake_now = time(NULL);
    bool stale = true;
    if (af && s_lock_frame_valid && wake_now >= 1704067200 && wake_now <= 4102444799LL) {
        const int64_t slept = (int64_t)wake_now - (int64_t)s_lock_frame_unix;
        stale = slept < 0 || slept >= (int64_t)af * 60;
    }
    s_lock_frame_valid = false;
    if (stale) lock_face_anti_fade(hl);
    ESP_LOGI(TAG, "lock resume: retained frame restored%s",
             stale ? " with anti-fade re-drive" : " without a repaint");
    return 1;
}
bool app_lock_resume_frame(EpdiyHighlevelState *hl) {
    s_boot_lock_hl = hl;
    return hl != NULL && lock_resume_service() == 1;
}
int app_lock_resume_poll(void) { return lock_resume_service(); }

void app_lock_boot_gate(EpdiyHighlevelState *hl, cst836u_handle_t touch, sc7a20h_handle_t acc) {
    s_lock_hint_hl=hl;s_lock_hint.serial=0;
    if (!lock_pin_enabled()) {
        if(pico_boot_has_resume()) {
            pico_boot_ready();pico_boot_hold_resume();
            // 深睡唤醒后不再无限等待（这是“开机困难”的来源）：电源键本身已唤醒设备。
            // 但“双击开机”仍然有效：最多再等 2 秒第二击，超时按单击恢复，避免误触直接进系统。
            // Never wait forever on the retained frame, but honour the double-press setting with a
            // bounded 2 s window for the second press.
            if (app_settings_wake_presses() > 1) {
                for (int i = 0; i < 100; ++i) {
                    if (read_pico_pmu_take_key_wakeup()) break;
                    vTaskDelay(pdMS_TO_TICKS(20));
                }
            }
            vTaskDelay(pdMS_TO_TICKS(100));
            read_pico_pmu_drain_events();
        }
        s_lock_hint_hl=NULL;return;
    }
    // 卡挂载有界等待仅为了字体/锁屏图；没有卡仍必须验证。上限压到 1 秒（原 3 秒）：
    // 慢卡/无卡不再拖长开机，缓存读不到时按样式重画或小锁兜底，密码校验不等待。
    // Bound the mount wait for the face/art only and cap it at one second (was three): a slow or
    // absent card no longer stretches boot; a missed cache redraws the style face or the small lock,
    // and authentication never waits.
    read_pico_sd_info_t info;
    for (unsigned i = 0; i < 50 && read_pico_sd_get_info(&info) == ESP_ERR_NOT_FINISHED; ++i)
        vTaskDelay(pdMS_TO_TICKS(20));
    app_lock_font_t saved; app_font_begin_lock(&saved);
    uint8_t *fb = epd_hl_get_framebuffer(hl);
    if (!lock_screen_restore(fb)) {
        // 冷启动丢失锁屏缓存时没有当前页面，用干净底图并继续密码校验。
        // A cold start with no retained art has no current page; use a clean base and keep authentication.
        if (app_settings_lock_style() == 3) memset(fb,255,(size_t)epd_width()*epd_height()/2);
        bool drawn = app_settings_lock_style() == 0 ? book_ticket_draw(fb, false) :
            app_settings_lock_style() == 2 ? book_lock_collage_draw(fb) :
            app_settings_lock_style() == 3 ? book_lock_bookmark_draw(fb,app_settings_bookmark_path()) :
            app_settings_lock_style() == 4 ? draw_lock_clock(fb) : draw_wallpaper(fb);
        if (!drawn) ui_lock_fallback_draw(fb);
    }
    lock_screen_authenticate(hl, touch, acc, true);
    s_lock_hint_hl=NULL;
    app_font_end_lock(&saved);
}
