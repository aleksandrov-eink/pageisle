/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 小纸 Pico 板级：I2C、IOE、SY7636A、EPD 总线与电源轨。
 *
 * Read Pico board: I2C, IO expander, SY7636A, EPD bus and rails.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "driver/i2c_master.h"
#include "epd_board.h"
#include "esp_err.h"
#include "fca9555.h"
#include "sy7636a.h"
#include "sdkconfig.h"

#ifdef __cplusplus
extern "C" {
#endif

#define READ_PICO_I2C_PORT ((i2c_port_t)CONFIG_READ_PICO_I2C_PORT)
#define READ_PICO_I2C_FREQ_HZ CONFIG_READ_PICO_I2C_FREQ_HZ
/// FCA9555 INT#，原理图接到 ESP32-S3 IO41。GPIO41 不是 RTC 脚，只能浅睡唤醒。
/// / FCA9555 INT# on ESP32-S3 IO41. GPIO41 is not RTC, so light-sleep wake only.
#define READ_PICO_IOE_INT_GPIO CONFIG_READ_PICO_IOE_INT_GPIO
/// CST836U INT，原理图 TXD0 / GPIO43。开漏低有效，FPC 侧有 10k 上拉。
/// / CST836U INT on TXD0 / GPIO43. Open-drain, active-low, 10k pull-up on the FPC.
#define READ_PICO_TP_INT_GPIO CONFIG_READ_PICO_TP_INT_GPIO

#define READ_PICO_PRODUCT_NAME "kiikoread"
#define READ_PICO_DEVICE_NAME "kiikoread"
/// 芯片平放实测 -5,-119,-1005；转到设备坐标后屏幕朝上约为 +Z。
/// / Chip at rest on the bench: -5,-119,-1005. Device frame is about +Z face-up.
#define READ_PICO_ACCEL_ZERO_X_MG 119
#define READ_PICO_ACCEL_ZERO_Y_MG 5
#define READ_PICO_ACCEL_ZERO_Z_MG 1005

extern const EpdBoardDefinition epd_board_read_pico;

i2c_master_bus_handle_t read_pico_i2c_bus(void);
sy7636a_handle_t read_pico_sy7636a(void);
fca9555_handle_t read_pico_fca9555(void);

typedef struct {
    uint16_t ioe_input;
    uint16_t ioe_output;
    uint16_t ioe_invert;
    uint16_t ioe_config;
    int ioe_int_level;
    sy7636a_status_t sy;
    bool sy_live;
    bool rails_on;
} read_pico_status_t;

#define READ_PICO_I2C_DEV_N 5

typedef struct {
    const char* name;
    uint8_t addr;
    bool online;
} read_pico_i2c_dev_t;

typedef struct {
    read_pico_i2c_dev_t dev[READ_PICO_I2C_DEV_N];
    int offline_n;
    bool all_online;
} read_pico_i2c_census_t;

/// 轨已上电后再拍。SY7636A 在 EN 低时不应答。
/// / Take after the rails are up. SY7636A NACKs while EN is low.
void read_pico_i2c_census_take(void);
const read_pico_i2c_census_t* read_pico_i2c_census(void);

esp_err_t read_pico_get_status(read_pico_status_t* status);
/// 只读 IN/OUT + INT#，CFG/INV 走缓存。不唤醒 SY7636A。
/// / Read IN/OUT + INT# only; CFG/INV come from cache. Does not wake SY7636A.
esp_err_t read_pico_get_ioe_status(read_pico_status_t* status);
/// 连读 8 寄存器，刷新 CFG/INV 缓存。底栏「读取」和进页用。
/// / Sequential 8-register read; refreshes CFG/INV cache. Footer Read and page enter.
esp_err_t read_pico_get_ioe_status_full(read_pico_status_t* status);
int read_pico_ioe_int_level(void);
/// 读取低有效卡座 CD；通信失败时不改输出，调用方不得将失败解释为拔卡。
/// / Read active-low slot CD; leave output untouched on failure, which is not card removal.
esp_err_t read_pico_sd_detect(bool* present);
/// 简化检测；通信失败返回 false。挂载与拔卡判断应使用 checked detect。
/// / Convenience detection returns false on I/O failure; mounting and removal use checked detect.
bool read_pico_sd_present(void);
bool read_pico_rails_on(void);
/// 刷新结束后释放 MODE/XOE/VCOM_EN，保留高压轨与原电压；已经中性时不访问 I2C，失败返回 false 供重试。
/// Release MODE/XOE/VCOM_EN after output, retaining HV rails and voltage settings; neutral state does no I2C, false requests a retry.
bool read_pico_epd_release_drive(void);
/// 分段断电第一段：撤驱动/VCOM_EN 并写 ON_OFF=0（快，轨已掉电）；放电后调 finish 只拉低 EN。
/// 两段之间重新推屏会先按正常顺序拉低 EN 再完整上电，finish 见到轨已重建则保持 EN。
/// First power-off stage: release drive/VCOM_EN, write ON_OFF=0 (fast; rails fall). After the
/// discharge wait call finish() to lower EN. A new output in between drops EN the normal way and
/// powers on completely; finish() keeps EN up when it sees the rails already rebuilt.
void read_pico_epd_power_cut_begin(void);
void read_pico_epd_power_cut_finish(void);
/// 两段之间等待的放电时间，来自 SY7636A 配置（poweroff_hold_ms）。
/// Discharge wait between the stages, from the SY7636A config (poweroff_hold_ms).
uint16_t read_pico_epd_poweroff_hold_ms(void);

/// 翻转 VCOMCTL：1=外部 VCOM_EN，0=自动时序。
/// / Toggle VCOMCTL: 1=external VCOM_EN, 0=auto timing.
esp_err_t read_pico_toggle_vcomctl(void);

/// 拉低再放开触摸芯片的 RST（挂在 FCA9555 上）。触摸进了深度睡眠后不再应答 I2C，
/// 只有这条路能把它叫回来。返回后调用方还要等芯片启动完成。
/// / Pulse the touch RST on the FCA9555. After deep sleep the chip ignores I2C;
/// this is the only wake. Caller must wait for boot after return.
esp_err_t read_pico_touch_reset(void);
/// high=false 拉低复位，high=true 放开。扩展口页要分两帧画脉冲时用。
/// / high=false asserts RST, high=true releases. IOE page draws the pulse in two frames.
esp_err_t read_pico_tp_rst(bool high);

/// 读一遍 9555 输入。INT# 不锁存，输入稳定后会自行松开；浅睡前/醒后都要调。
/// / Read 9555 inputs. INT# is not latched and releases once inputs are stable;
/// call before light sleep and after wake.
void read_pico_clear_ioe_int(void);

/// 睡前收口 9555：悬空的 Port1 推高；host_off 时 CW_INT 也改输出低，关机期间 INT# 不再被 PMU 事件拉低。浅睡不能用 host_off，按键唤醒要靠 CW_INT。
/// Park the 9555 before sleep: drive unconnected Port1 high; with host_off, CW_INT turns output-low so PMU events cannot pull INT# while off. Never use host_off for light sleep; key wake needs CW_INT.
esp_err_t read_pico_ioe_sleep(bool host_off);
/// 恢复运行时的方向配置并清 INT#。/ Restore running directions and clear INT#.
esp_err_t read_pico_ioe_wake(void);

#ifdef __cplusplus
}
#endif
