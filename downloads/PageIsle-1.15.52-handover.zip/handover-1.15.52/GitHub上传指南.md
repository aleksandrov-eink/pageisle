# GitHub 上传指南（网页版，无需命令行）

本机当前**没有安装 git / GitHub CLI**，也没有你的 GitHub 账号凭据。所以「我直接帮你 push」
需要你配合做两件事之一；如果只是发布固件给别人下载，**完全用网页点几下就行**，推荐方式 A。

---

## 方式 A：只发布固件 + 说明（纯网页，最简单，推荐）

适合：让别人下载升级包、看改版日志，不需要源码仓库。

1. 浏览器打开 https://github.com 并登录。
2. 右上角 **+** → **New repository**：
   - Repository name：例如 `kiikoread-pico`
   - 选 Public 或 Private（发布给别人下载就选 Public）
   - **不要**勾选 “Add a README file”（保持空仓库）
   - 点 **Create repository**
3. 进入仓库后，点右侧 **Releases** → **Create a new release**（或 Draft a new release）。
4. 填写：
   - **Choose a tag**：输入 `v0.3.3-rc99`，点 “Create new tag”；
   - **Release title**：`页屿 PageIsle 0.3.3-rc99 定制版`;
   - 描述框：可以把 `docs/改版日志与刷机指南.md` 的内容粘贴进去（或只写几行摘要）。
5. 向下找到 **Attach binaries by dropping them here or selecting them**，把这些文件拖进去：
   - `firmware/Pico-update.bin`（TF 卡升级镜像）
   - `usb-full-package/` 整个目录可以打包成 zip 再拖（Windows 右键 → 压缩为 ZIP）
   - `docs/改版日志与刷机指南.md`
   - （可选）`README-HANDOVER.md`
6. 点 **Publish release**。发布后别人就能在 Releases 页面直接下载。

> GitHub 网页单文件上传上限 25MB、Release 附件上限 2GB，本包的固件与文档都远小于上限。

---

## 方式 B：连源码一起放到仓库（网页上传，或装 GitHub Desktop）

源码约 1200+ 个文件，**不建议用网页“上传文件”一个个拖**（网页一次最多 100 个文件）。

推荐用 **GitHub Desktop**（图形界面，登录后不用敲命令）：

1. 网页新建空仓库（同上，不要 README）。
2. 下载安装 GitHub Desktop：https://desktop.github.com/ ，用你的 GitHub 账号登录。
3. GitHub Desktop → **File → Add local repository** → 选择源码文件夹
   （开发机上的 `read-pico-reader-0.3.3-rc99`；如果需要，我可以先把它复制到一个干净目录并
   排除 `build/` 编译产物）。
   - 若提示不是 git 仓库，选 **create a repository** 在该目录初始化；
4. 左下角填写提交说明（如 `页屿 PageIsle 0.3.3-rc99 定制版源码`），点 **Commit to main**。
5. 顶部 **Publish repository** → 选择刚建的仓库 → Publish。
6. 之后在 GitHub 网页 Releases 页面按方式 A 上传固件即可。

> 注意：源码里 `build/`、`managed_components/`、`.devcontainer` 等可以按需排除；
> `managed_components` 是 IDF 依赖，想保留可一起提交（文件较多但 GitHub 能接受）。

---

## 方式 C：让我（助手）直接帮你 push

前提：这台机器没有 git，需要先装 Git for Windows（或 GitHub Desktop 自带的 git），并且你愿意
把**临时访问令牌**发给我。

步骤：

1. 网页创建空仓库，例如 `https://github.com/你的用户名/kiikoread-pico`。
2. 网页右上头像 → **Settings** → 左侧最下 **Developer settings** →
   **Personal access tokens** → **Fine-grained tokens** → **Generate new token**：
   - Repository access：**Only select repositories** → 选刚建的那个仓库；
   - Permissions → Repository permissions → **Contents: Read and write**（其余保持 No access）；
   - Expiration：选 **7 days**（或最短）。
   - 生成后复制 `github_pat_...` 开头的令牌。
3. 把下面信息发我：
   - 仓库地址（`https://github.com/用户名/仓库名.git`）
   - 临时令牌
   - 是否允许我在这台机器上安装/使用 git（需要联网下载）
4. 我完成后会在回复里告诉你「已推送」，请你**立刻回到网页 Revoke 这个令牌**。

安全提醒：

- 令牌只授权**单个仓库 + Contents 读写**，不要给全账号权限；
- 令牌会出现在对话记录里，所以务必用**临时令牌**并在推送完成后立即撤销；
- 如果不方便给令牌，用方式 A / B 自己点几下最安全。

---

## 我这边可以提前准备好的东西

已放在交付目录 `handover-0.3.3-rc99/`：

- `firmware/Pico-update.bin` — TF 卡升级镜像
- `usb-full-package/` — USB 完整刷机包（含 SHA256SUMS）
- `docs/改版日志与刷机指南.md`、`使用说明.txt`
- `README-HANDOVER.md` — 本交付汇总（可直接作为仓库 README）
- 本文件 `GitHub上传指南.md`

如果你选方式 C，告诉我仓库地址 + 临时令牌即可；如果选方式 A/B，直接按上面步骤操作，
遇到哪一步卡住把页面截图发我，我按你的页面继续指导。
