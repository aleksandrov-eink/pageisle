# BLE HID 主机（蓝牙翻页器）。依赖 NimBLE 主机与 BT 控制器，都是 IDF 自带组件。
# BLE HID host (Bluetooth page-turner). Needs the NimBLE host and the BT controller, both
# bundled with ESP-IDF.
set(kiiko_selected_sources "src/ble_page_turner.c")
idf_component_register(
    SRCS ${kiiko_selected_sources}
    INCLUDE_DIRS "include"
    REQUIRES bt nvs_flash esp_timer read_pico
)

# 流畅性：-O3（触摸、编解码、PMU、传输等低延迟外设路径）。
# Smoothness: -O3 for the low-latency peripheral/decode paths.
if(NOT CMAKE_SCRIPT_MODE_FILE)
    component_compile_options(-O3)
endif()
