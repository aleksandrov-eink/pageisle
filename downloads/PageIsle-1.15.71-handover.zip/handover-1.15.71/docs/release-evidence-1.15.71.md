# 页屿 1.15.71 · 内测站（Pico beta）发布证据

- 时间：2026-11-13 18:49–19:10（本机）；Pages 构建完成 2026-11-13T10:59:28Z（UTC，Asia/Shanghai 18:59:28）。
- 授权与目标（Lead m00580/m00680）：只发 **内测 beta** 通道，Pico beta 1.15.71（蓝牙翻页器连接修复）；**stable 保持 1.15.70、Metalio 1.15.68 不动**；不碰正式站/Release、Metalio 包、OTA feed、其他仓库。
- 发布方式：**GitHub Git Data API**（`api.github.com`）；本网络 git clone/push pack 仍不可用，沿用 1.15.70 的 API 发布链路。`beta/metalio/**` 为远端权威保护区，永不写入。

## 发布结果

- commit：**`8f54be808cab6d6355b230fe5e22d59daa07c8f9`**
- tree：`55bdec95ba9f57d08066a2f47fec8605827aa1fc`
- parent：`73611891e7704e7251f80ed52c10f126bcaadf1d`（1.15.70 stable 发布提交）
- 差异：**8 changed / 0 added / 0 deleted / 105 unchanged**；`EXPECT_IGNORED` 仅 `beta/metalio/docs/使用说明.txt`（历史漂移，保留远端、不写不改）。
- 提交文案：页屿内测通道：Pico 页屿系统 1.15.71 内测上线（蓝牙翻页器连接修复：过期配对缓存清理重试/明文 HID 回退/状态区分/blept 日志）；正式站 stable 保持 1.15.70 不动；Metalio S31 页屿自定义 1.15.68 保持在线不变。
- Pages build：status=**built**，commit=`8f54be80…`，created `2026-11-13T10:58:58Z`，updated `2026-11-13T10:59:28Z`，duration 30,615 ms。
- compare API 复核：8 files modified、0 added/deleted、无 `beta/metalio`、无 removed files。

## 构建（ck4f）

- ck4 第一次重建为**增量**（仅 9 个 ninja 步骤）：3,712,976 B / sha `8af055664e273cf949bf4c3cbd75f44193527418a64c1e927532327c2e7a47c4`，0 error / 0 warning（历史 warning 文件未重编），证据留 `evidence\ck4-incr`。
- 为满足“11 条既有 warning + 全量干净产物”，清空后重跑 **ck4f 全量构建**（最终采用）：
  - 构建目录：`C:\dshb\b169\build`；镜像 `C:\dshb\b169\src`；工作树 `...\src2\read-pico-reader-0.3.3-rc99`
  - 结果：**rc=0 / 0 error / 11 warning（与历史 11 条集合一致，0 新增）**；duration 235s（总脚本 285.3s）；freeze **FROZEN_OK**；mirror 4931 文件 **IDENTICAL**
  - 产物：**3,712,976 B，sha256 `4c98b123ee22bd362248337bf7726a73006fc6afa5259e0842e14c480a774c0d`**
  - ota_0 槽 4,194,304 B，余量 **481,328 B（11.48%）**；内嵌 1.15.71 + 2026-11-13（二进制中 `1.15.71`×1、`2026-11-13`×1）
  - ck4 增量 vs ck4f 全量仅 **71 字节 / 5 段**（112-113、115-116、118-119、0xb0-0xcf、0x38a7af-0x38a7cf；app_desc 时间戳 + 尾部摘要），与 ck2/ck2f 同规律
  - 报告/日志：`logs\ck4f-report-20261113-185129.md`、`logs\ck4f-20261113-185149-ninja.log`、`logs\ck4f-20261113-185149-configure.log`；证据 `evidence\ck4f\`（Read_Pico.bin/report/ninja/configure）

## 发布前本地准备（PREPARE_OK）

- 脚本补丁：`prep_11571_patch.py` → `PATCH_11571_OK`；备份 `backup\release\scripts-pre-11571\20261113-185650`（4 脚本 + patch-record.md）。改：`prepare_dual_site.py`（LOCAL=`local-test-11571-dual`、PICO_VERSION=1.15.71）、`prepare_beta_site.py`（VERSION=1.15.71）、`verify_live_11555.py`（beta 4c98…/3,712,976 + 1.15.71 断言；stable 保持 ck3f 5e374698…/3,707,056）、`check_local_site.py`（stable 保持 ck3f，beta/local 改 1.15.71/ck4）。
- 站点准备：`prep_11571_run.py` → **PREPARE_OK**（A/B/C/D 全部 PASS）；备份 `backup\release\site-pre-beta-11571\20261113-185653`；checkpoint `logs\prepare-real-11571-20261113-185653-checkpoint.md`；prepare 日志 `logs\prepare-real-11571-20261113-185653.log`；树哈希 `logs\site-tree-sha256-11571-20261113-185653.txt`。
- site-beta 固件：firmware.bin/Pico-update.bin = ck4f 4c98…/3,712,976；bootloader 保留线上 **e49feb21…**（见下）；partitions `edba9d92…`、ota_data `7d2c7ac4…` 与线上相同；manifest 3 段（0/32768/65536、`new_install_prompt_erase=true`、version 0.3.3-rc99、name 含 1.15.71）；SHA256SUMS.txt 5 行。
- 文档：从 handover-1.15.70 docs + Lead 章节生成 beta 三份 docs；改版日志新增 **0.80 节（页屿系统 1.15.71 · 蓝牙翻页器连接修复）**，插在 0.79 前；三份 header 均更新为 1.15.71/3,712,976/481,328/4c98…；0.80 含 6 步蓝牙验收与 `blept:` 重点日志行、回退说明。
- 本地双设备预览包：`_deliver\local-test-11571-dual`（Pico 4c98…；Metalio 1.15.68；SHA256SUMS 3 行）。
- handover：`_deliver\handover-1.15.71-ghost`（17 files / 21,439,011 B）：
  - firmware/Pico-update.bin = 4c98…/3,712,976；usb-full-package/Pico-full-flash-1.15.71.bin 13,705,216 B，sha `ac552e5cd8fde665807ee6577514da5b8fc515f8e634ab50924a24507414ecd7`
  - docs 6 个：使用说明.txt、变更清单-从原始版到最终版.md、改版日志-1.15.71.md（Lead 章节原文 1,880 B）、真机验收清单-1.15.71.md（章节验收步骤 2,070 B）、改版日志与刷机指南.md、蓝牙翻页器验收卡.md；README-1.15.71.md；SHA256SUMS.txt 2 行。
- **bootloader 决策**：ck4f 全量构建的 bootloader 为 `d9cc36e7…`，与线上 1.15.70 beta 的 `e49feb21…` 不同（全量构建的时间/元数据差异，源码未变）。为避免无谓改动 web 刷机 bootloader、让本次 diff 保持 8 项，**site-beta 保留线上旧 bootloader e49feb21…** 并重写 SHA256SUMS；handover ghost 的 USB 全量包仍用 ck4f bootloader `d9cc36e7…`（同源全量构建，功能等价）。
- **Metalio 漂移保护**：线上 `beta/metalio/docs/使用说明.txt`（56,738 B，blob `56641398…`）与本地 57,039 B（blob `2376a7ae…`）不同；另两份 Metalio docs 字节相同。发布脚本只把该项列入 IGNORED，远端保持；Metalio 未写。

## 本次线上实际变更（8 项）

1. `index.html`：root 双设备卡 Pico beta 显示“页屿系统 1.15.71 · 3,712,976 字节”+ ck4f sha；stable 仍 1.15.70 + ck3f sha。
2. `beta/firmware/firmware.bin`：3,707,056 → **3,712,976 B**，sha `4c98b123…a774c0d`。
3. `beta/firmware/Pico-update.bin`：同上 sha。
4. `beta/firmware/SHA256SUMS.txt`：5 行（firmware/Pico-update 4c98…；bootloader e49feb21…；partitions edba9d92…；ota_data 7d2c7ac4…）。
5. `beta/firmware/manifest.json`：443 B，name `页屿 PageIsle 内测版 1.15.71`、version 0.3.3-rc99、3 段 0/32768/65536、erase=true。
6. `beta/docs/使用说明.txt`：1.15.71/0.80/4c98…。
7. `beta/docs/变更清单-从原始版到最终版.md`：1.15.71/ck4f 数字。
8. `beta/docs/改版日志与刷机指南.md`：1.15.71/0.80/蓝牙翻页器连接修复。

未变：`beta/metalio/**`（PROTECTED）、`beta/firmware/bootloader.bin`（e49feb21…）、`beta/firmware/partitions.bin`、`beta/firmware/ota_data_initial.bin`、`firmware/**`（stable）、`metalio/**`（1.15.68）、其他 downloads/历史归档。

## 线上验证

| 检查 | 结果 |
|---|---|
| 远端 main ref（API） | `8f54be808cab6d6355b230fe5e22d59daa07c8f9` ✅ = 发布提交 |
| Pages build | status=built，commit=`8f54be80…`，updated `2026-11-13T10:59:28Z` ✅ |
| compare API | 8 files modified / 0 added / 0 deleted，无 `beta/metalio/` ✅ |
| `verify_live_11555.py` | **LEAD_LIVE_OK：52 checks / 0 problems** ✅（日志 `logs\verify-live-11571-20261113-190900.log`） |
| `check_local_site.py` | **LOCAL_SITE_OK：82 passed / 0 failed** ✅（日志 `logs\check-local-11571-20261113-190900.log`） |
| `final_verify_11571.py` | **FINAL_VERIFY_OK：33/33** ✅（JSON `final-verify-11571-20261113-190722.json`；树哈希 `site-tree-sha256-11571-final-20261113-190722.txt`） |
| beta 固件（线上实测） | firmware.bin = Pico-update.bin = **3,712,976 B / `4c98b123…a774c0d`** ✅ |
| beta manifest（线上） | 443 B，name 含 1.15.71、3 段、erase=true，blob `cf29dcbb…` ✅ |
| beta bootloader/partitions/ota（线上） | e49feb21… / edba9d92… / 7d2c7ac4…（均未变） ✅ |
| stable 固件（线上） | `firmware/Pico-update.bin` = **3,707,056 B / `5e374698…412473`**（1.15.70 未变） ✅ |
| root 双设备卡 | 同时显示 beta 1.15.71 + 4c98…、stable 1.15.70 + 5e374698… ✅ |
| Metalio feed | `metalio/update.json` version **1.15.68**、app sha `d6d21744…`（未变） ✅ |
| 历史下载 | 旧 1.15.53 三归档可访问（未删） ✅ |

- 入口：站点 `https://aleksandrov-eink.github.io/pageisle/`；beta 页 `https://aleksandrov-eink.github.io/pageisle/beta/`。
- 本地树聚合 sha256：site 46 files `476f102afce6a59b17769386c75575e0f34566bb1511fefac67582d375c67924`；site-beta 33 `a111d2f0063bccb2d4d7bd5d4d5a7952419fca0ec09afd7a47d9627c5eceb34b`；site-beta-metalio 35 `5a9adf73d4ff7210a8da27455be9620452c0e9b16d8813375ad5e7f8eb0f8f22`；local-test-11571-dual 6 `a516921af973740a718c4a1d2abb25b10f43d9499457408593dd229f0142fef4`；handover-1.15.71-ghost 17 `8a91d6800dd3163a191e1b1efdeb3eaf410a78504ed475017d6a0797957dab5c`。

## 回退与限制

- **回退**：内测用户可回 1.15.70（网页 beta 历史包/USB 全量包或 1.15.70 handover 的 Pico-update.bin）；同版本 TF 本地升级会被版本比较拒绝，需用网页/USB 全量。stable 正式站仍 1.15.70，不受影响。
- **限制**：本次只验证站点内容/固件字节/构建静态检查，**未经真机验证**；蓝牙翻页器连接修复需用户真机按“设置→蓝牙翻页器→重新扫描/连接→阅读页按键”验证；失败时按 0.80 节提供 115200 `blept:` 日志。
- 未改：正式站 stable、正式 Release、Metalio 包/feed、OTA feed（仍 1.15.68 rc107 口径）、`flash/`、wegooo-cell/read-pico-reader。
- token：发布/复核用的 `C:\dshb\work\gh_token.txt` 已在完成后**删除**（未打印内容）。
- 可清理项：增量构建备份目录 `C:\dshb\b169\build_incr_ck4`（保留 ck4f 为 `b169\build`）；临时脚本 `_tmp_test_docs_11571.py`、`_tmp_test_patch_11571.py`、`_tmp_remote_check_11571.py` 已删除。

## 本地留证

- 构建：`evidence\ck4f\`、`evidence\ck4-incr\`；报告 `logs\ck4f-report-20261113-185129.md`、`logs\ck4-report-20261113-184943.md`。
- 站点准备：`logs\prepare-real-11571-20261113-185653-checkpoint.md`、`logs\prepare-real-11571-20261113-185653.log`、`logs\site-tree-sha256-11571-20261113-185653.txt`；备份 `backup\release\site-pre-beta-11571\20261113-185653`、`backup\release\scripts-pre-11571\20261113-185650`。
- 发布：`publish-api-diff-20261113-185824.json`（dry-run 8/1/0）；API apply/compare 输出见本次会话记录。
- 验证：`logs\verify-live-11571-20261113-190900.log`、`logs\check-local-11571-20261113-190900.log`、`final-verify-11571-20261113-190722.json`、`site-tree-sha256-11571-final-20261113-190722.txt`。
- 包：`_deliver\handover-1.15.71-ghost\`、`_deliver\local-test-11571-dual\`。

> 口径：本证据仅证明「构建产物 / 本地准备 / 站点内容与固件字节正确上线」，**不代表真机已验证**。
