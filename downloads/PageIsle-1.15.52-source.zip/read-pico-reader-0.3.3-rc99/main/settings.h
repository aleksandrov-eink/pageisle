/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * NVS 里的用户设置：睡眠档、字体路径、上次唤醒/开机原因、拿起唤醒开关。
 *
 * User settings in NVS: sleep mode, font path, last wake/boot reason,
 * pickup-wake switch.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

/// 默认深睡。浅睡：按键回原页；拿起唤醒默认关。软睡：SOFT_SLEEP 拉低 EN，再短按开机。关机：EN=0，长按开机。
/// Default is deep. Light: key returns to the page; pickup-wake defaults off. Soft sleep: SOFT_SLEEP drops EN, then a short press boots. Off: EN=0, long-press to boot.
typedef enum {
    APP_SLEEP_LIGHT = 0,
    APP_SLEEP_DEEP = 1,
    APP_SLEEP_OFF = 2,
} app_sleep_mode_t;

void app_settings_init(void);
app_sleep_mode_t app_settings_sleep_mode(void);
void app_settings_set_sleep_mode(app_sleep_mode_t mode);
const char* app_sleep_mode_name(app_sleep_mode_t mode);
/// 电源菜单“关机”：false 为彻底断电，true 为先浅睡 10 分钟再由 PMU 软睡断电。
/// Power-menu shutdown: false powers fully off; true light-sleeps for 10 minutes, then PMU soft-sleeps.
bool app_settings_staged_shutdown(void);
void app_settings_set_staged_shutdown(bool staged);
/// 电源键开机次数：1 单击开机，2 双击开机；默认 2，放在包里不易误开机。
/// Power-key boot presses: 1 boots on a single press, 2 needs a double click; defaults to 2 so a bag cannot wake it.
uint8_t app_settings_wake_presses(void);
void app_settings_set_wake_presses(uint8_t presses);
/// 首页进入时强制整屏全刷；默认关闭（浅色主页首帧仍会做内容区 GC16 复位，不依赖此开关）。
/// Full refresh when entering Home; off by default (the light-mode first Home frame still runs a
/// content-area GC16 reset, independent of this switch).
bool app_settings_home_full_refresh(void);
void app_settings_set_home_full_refresh(bool enabled);
/// 全局反色显示（显示设置）；只换像素解释方式，不改帧缓冲内容。
/// Global inverted display (display settings); only the pixel interpretation changes, not the framebuffer.
bool app_settings_inverted(void);
void app_settings_set_inverted(bool enabled);
/// 强光防泛白/防反黑（实验项，默认关闭）：每次刷屏后尽快撤掉面板供电，不在强光下长时间保留
/// 高压电场。断电在低优先级任务里执行（含约 500ms 放电等待，不阻塞主循环/不吞输入）。默认关闭是
/// 因为 600ms 阈值会让连续翻页每页多一次上下电；需要时用 NVS sun_fix=1 开启做真机 A/B。
/// Sunlight fading fix (experimental, off by default): drop panel power soon after every update
/// instead of holding HV rails in strong light. The cut runs in a low-priority task (its ~500 ms
/// discharge wait never blocks the main loop or swallows input). Off by default because the 600 ms
/// threshold adds one power cycle per page during continuous turns; enable with NVS sun_fix=1 for a
/// real-device A/B.
bool app_settings_sun_fade_fix(void);
void app_settings_set_sun_fade_fix(bool enabled);
/// 夜间自动反色：21:00–07:00（北京时间）整屏反色；时间无效时只按手动开关。
/// Night auto-inversion: inverted from 21:00 to 07:00 (China time); manual state alone when time is invalid.
bool app_settings_invert_night(void);
void app_settings_set_invert_night(bool enabled);
/// 反色最终状态（手动开启或夜间时段），所有需要“是否反色”的调用都用它。
/// Effective inversion (manual on or night window); every caller asking "is inverted" uses this.
bool app_settings_invert_effective(void);
/// 全局繁简显示：只有全部繁体 / 全部简体两种；默认简体，只转换显示，不改文件与进度。
/// Global script display: only all-Traditional or all-Simplified; Simplified is the default.
/// Conversion is display-only and never rewrites files or progress.
typedef enum {
    APP_ZH_TRADITIONAL = 1, ///< 全部显示繁体 / Show everything in Traditional
    APP_ZH_SIMPLIFIED = 2,  ///< 全部显示简体 / Show everything in Simplified
} app_zh_mode_t;
app_zh_mode_t app_settings_zh_mode(void);
void app_settings_set_zh_mode(app_zh_mode_t mode);
/// 首页组件默认书夹；选择与每日目标均掉电保存。/ Persist the Home widget and daily goal across power loss.
typedef enum {
    APP_HOME_FOLDER = 0, APP_HOME_CLOCK = 1, APP_HOME_ASTERISK = 2,
    // 3为旧组件的保留编号，不能重排已有配置。/ ID 3 is retired; preserve existing persisted IDs.
    APP_HOME_MOON = 4, APP_HOME_KEHAI = 5, APP_HOME_DALI = 6, APP_HOME_CAT = 7, APP_HOME_HOUSE = 8, APP_HOME_COMPONENT_COUNT = 9
} app_home_component_t;
app_home_component_t app_settings_home_component(void);
esp_err_t app_settings_set_home_component(app_home_component_t component);
uint8_t app_settings_home_goal_minutes(void);
/// 首页右下模块：0 日历、1 待办、2 本月统计。
/// Home right panel: 0 calendar, 1 to-do, 2 monthly stats.
uint8_t app_settings_home_panel(void);
/// 首页右下模块是否被双击锁定（锁定后长按不再切换）。
/// Whether the home right-bottom panel is locked by a double tap.
bool app_settings_home_panel_locked(void);
void app_settings_set_home_panel_locked(bool locked);
void app_settings_set_home_panel(uint8_t panel);
esp_err_t app_settings_set_home_goal_minutes(uint8_t minutes);
/// 主页刷新模式，只控制四个主页面；默认普通。/ Main-tab refresh mode; ordinary by default.
typedef enum {
    APP_MAIN_REFRESH_NORMAL = 0, ///< 普通灰阶 / Ordinary grayscale
    APP_MAIN_REFRESH_FAST = 1,   ///< 黑白快刷与灰阶亚克力 / Monochrome fast with gray acrylic
    APP_MAIN_REFRESH_WATER = 2,  ///< 水波纹灰阶 / Staggered grayscale
} app_main_refresh_mode_t;
app_main_refresh_mode_t app_settings_main_refresh_mode(void);
void app_settings_set_main_refresh_mode(app_main_refresh_mode_t mode);
/// 绘制主页面黑白资源时使用，其他两种模式保留灰阶。/ Used to render monochrome resources; the other modes retain grayscale.
bool app_settings_main_fast_refresh(void);
/// 无操作自动锁屏分钟数：0 关闭，1/5/10。/ Idle lock timeout: off, 1/5/10 minutes.
uint8_t app_settings_auto_lock_minutes(void);
void app_settings_set_auto_lock_minutes(uint8_t minutes);
const char *app_settings_device_name(void);
void app_settings_set_device_name(const char *name);
const char *app_settings_avatar_path(void);
void app_settings_set_avatar_path(const char *path);
const char *app_settings_status_signature(void);
void app_settings_set_status_signature(const char *signature);
/// 空路径表示固件内建字体；非空为 SD 上的 TTF。/ Empty path is the built-in font; non-empty is a TTF on the SD card.
const char* app_settings_font_path(void);
void app_settings_set_font_path(const char* path);
/// 系统界面字体；空值使用内建思源黑体并从 TF 卡补字。/ UI font; empty uses built-in Source Han Sans with SD fallback.
const char* app_settings_system_font_path(void);
void app_settings_set_system_font_path(const char* path);
/// 系统字号 100..200%，每档 10%。/ System UI size 100..200%, in 10% steps.
uint8_t app_settings_system_font_size(void);
void app_settings_set_system_font_size(uint8_t percent);
/// 系统界面灰阶对比度，100..140%。/ System UI grayscale contrast, 100..140%.
uint8_t app_settings_system_contrast(void);
void app_settings_set_system_contrast(uint8_t percent);
/// 锁屏样式和壁纸路径。/ Lock style and wallpaper image path.
/// 锁屏：0阅读票根、1壁纸、2书架拼贴、3透明书封。/ Lock: ticket (0), wallpaper (1), collage (2), PNG cover (3).
uint8_t app_settings_lock_style(void);
/// 时间锁屏（极简时钟）是否横屏显示（真旋转）。/ Whether the clock lock is shown landscape.
bool app_settings_lock_clock_landscape(void);
void app_settings_set_lock_clock_landscape(bool on);
void app_settings_set_lock_style(uint8_t style);
const char* app_settings_bookmark_path(void);
void app_settings_set_bookmark_path(const char *path);
const char* app_settings_wallpaper_path(void);
void app_settings_set_wallpaper_path(const char* path);
/// 上次浅睡唤醒源（app_wake_source_t），掉电也保留。/ Last light-sleep wake source (app_wake_source_t); kept across power loss.
uint8_t app_settings_last_wake(void);
void app_settings_set_last_wake(uint8_t src);
/// 最近一次非 0 的 PMU wake_reason。STATUS 报 0 时用这个回显。/ Last non-zero PMU wake_reason. Used when STATUS reports 0.
uint8_t app_settings_last_boot(void);
void app_settings_set_last_boot(uint8_t reason);
/// 浅睡拿起唤醒。默认关；有加速度计也不会自动开。/ Light-sleep pickup wake. Defaults off; an accelerometer does not turn it on.
bool app_settings_pickup_wake(void);
void app_settings_set_pickup_wake(bool on);
/// 阅读默认字号，18..90，默认 48。/ Default reading size, 18..90, initially 48.
/// Reading stroke weight -2..2: thin, lighter, native, heavier, bold.
int8_t app_settings_book_weight(void);
#define APP_BOOK_WEIGHT_SUBSTEPS 16
#define APP_BOOK_WEIGHT_FINE_MAX 32
/// 一档为1/16像素，旧像素值继续兼容。/ One step is 1/16 pixel; legacy pixel values remain compatible.
int8_t app_settings_book_weight_fine(void);
bool app_settings_set_book_weight_fine(int8_t steps);
bool app_settings_set_book_weight(int8_t level);
/// 阅读抗锯齿默认开启；关闭只改变字形边缘，不改变排版或图片。/ Reading AA defaults on; disabling affects glyph edges, not layout or images.
bool app_settings_book_antialias(void);
bool app_settings_set_book_antialias(bool enabled);
uint8_t app_settings_book_px(void);
/// 无效字号恢复 48。/ Invalid sizes fall back to 48.
void app_settings_set_book_px(uint8_t px);
/// Reading backgrounds are selected from /sdcard/pictures; empty means white.
const char *app_settings_book_background_path(void);
bool app_settings_set_book_background_path(const char *path);
/// 阅读时每 5/10/15/30 页全刷；0 关闭周期全刷，手动全刷仍可用。默认 10（浅色残影修复）。
/// Full-screen cleanup every 5/10/15/30 turns; 0 disables periodic cleanup only. Defaults to 10
/// (light-mode ghosting fix).
uint8_t app_settings_reader_full_pages(void);
void app_settings_set_reader_full_pages(uint8_t pages);
/// 阅读翻页效果：0普通，1水波纹；S31额外提供2速读黑白。/ Reader turn effect:0 ordinary,1 ripple; S31 additionally supports2 fast BW.
uint8_t app_settings_reader_turn_effect(void);
void app_settings_set_reader_turn_effect(uint8_t effect);
/// 阅读正文里短按电源键翻下一页；默认关闭。/ Short power press turns forward only in reader body; off by default.
bool app_settings_reader_power_turn(void);
void app_settings_set_reader_power_turn(bool on);
/// 沉浸全屏时隐藏阅读状态栏。/ Hide the reader status bar in immersive full screen.
bool app_settings_reader_immersive(void);
void app_settings_set_reader_immersive(bool on);
/// 阅读时跳过书内插图页；原图仍保留在 EPUB 中。/ Skip inline illustrations while reading without changing the EPUB.
bool app_settings_reader_hide_images(void);
void app_settings_set_reader_hide_images(bool on);
/// 使用书内自带 TTF（EPUB @font-face 或包内字体）；默认开启，关掉后正文回到系统字体。
/// Use embedded book TTFs (CSS @font-face or a packaged face); on by default. Turning it off
/// puts body text back on the system face.
bool app_settings_book_fonts(void);
void app_settings_set_book_fonts(bool on);
/// 竖排正文（自上而下成列、列序自右向左）；默认关闭，只影响正文排版与插图分页。
/// Vertical body text (columns run down, ordered right to left); off by default, and only the
/// body layout and illustration pagination are affected.
bool app_settings_book_vertical(void);
void app_settings_set_book_vertical(bool on);

/// Adaptive reading direction: the body page follows the device orientation.
/// Off by default and confined to the reader body page.
bool app_settings_reader_adaptive(void);
void app_settings_set_reader_adaptive(bool on);
/// 长按正文：true 划线，false 打开目录。默认 true。
/// Long-press on the body: true highlights, false opens the directory. Defaults to true.
bool app_settings_reader_long_press_highlight(void);
void app_settings_set_reader_long_press_highlight(bool on);
typedef enum {
    APP_READER_KEY_PREV, ///< 上一页 / Previous page
    APP_READER_KEY_NEXT, ///< 下一页 / Next page
    APP_READER_KEY_TOOLS, ///< 阅读工具栏 / Reader toolbar
    APP_READER_KEY_FULLSCREEN, ///< 切换全屏 / Toggle full screen
    APP_READER_KEY_HOME, ///< 返回主页（本次开书来源） / Return to the opening origin
    APP_READER_KEY_REFRESH, ///< 手动全刷 / Manual full refresh
    APP_READER_KEY_NONE, ///< 不操作 / No action
    APP_READER_KEY_COUNT
} app_reader_key_action_t;
/// 三个短按功能，0/1/2对应左/中/右；长按独立配置。/ Short actions indexed left/middle/right, with a separate hold action.
app_reader_key_action_t app_settings_reader_key_action(unsigned key);
/// 仅验证按键与动作范围，不强制工具栏映射；3代表中键长按。/ Validate key/action ranges without requiring a toolbar mapping; 3 means middle hold.
bool app_settings_reader_key_action_allowed(unsigned key, app_reader_key_action_t action);
/// 返回是否成功保存；失败不改变映射。/ Return successful persistence, leaving the mapping unchanged on failure.
bool app_settings_set_reader_key_action(unsigned key, app_reader_key_action_t action);
/// 中键长按，默认手动全刷；与短按独立保存。/ Middle hold defaults to full refresh and persists independently.
app_reader_key_action_t app_settings_reader_hold_action(void);
bool app_settings_set_reader_hold_action(app_reader_key_action_t action);
/// 一次提交整套推荐设置，1为翻页，2为首页/全屏/工具栏。/ Commit preset 1 (page turns) or 2 (Home/full screen/tools) together.
void app_settings_set_reader_key_preset(unsigned preset);
/// 旧长按设置API保留用于历史备份兼容。/ Retained legacy hold APIs for historical backup compatibility.
bool app_settings_reader_hold_refresh(void);
void app_settings_set_reader_hold_refresh(bool on);
/// 上1/3与下2/3轻点分区；默认左右各半。/ Upper 1/3 and lower 2/3 tap regions; default horizontal halves.
bool app_settings_reader_vertical_turn(void);
void app_settings_set_reader_vertical_turn(bool on);

/// 手势动作：阅读页可绑定到触屏手势的动作集合，与三键动作分开，免得动到已保存的键位数据。
/// Gesture actions: what a touch gesture can do in the reader. Kept apart from the key actions
/// so the persisted key mapping and its backup format never move.
typedef enum {
    APP_GESTURE_ACTION_PREV = 0, ///< 上一页 / Previous page
    APP_GESTURE_ACTION_NEXT, ///< 下一页 / Next page
    APP_GESTURE_ACTION_TOOLS, ///< 阅读工具栏 / Reader toolbar
    APP_GESTURE_ACTION_FULLSCREEN, ///< 切换全屏 / Toggle full screen
    APP_GESTURE_ACTION_HOME, ///< 返回主页 / Return to the opening origin
    APP_GESTURE_ACTION_REFRESH, ///< 手动全刷 / Manual full refresh
    APP_GESTURE_ACTION_TOC, ///< 打开目录 / Open the table of contents
    APP_GESTURE_ACTION_HIGHLIGHT, ///< 划线（长按语义） / Highlight with hold semantics
    APP_GESTURE_ACTION_NONE, ///< 不操作 / No action
    APP_GESTURE_ACTION_COUNT
} app_gesture_action_t;

/// 手势槽位。轻点留给原有分区翻页，因此不在此列。
/// Gesture slots. Plain taps stay with the existing zone page turns and are not a slot.
typedef enum {
    APP_GESTURE_DOUBLE_TAP = 0, ///< 双击中间 / Double tap in the middle
    APP_GESTURE_LONG_PRESS, ///< 长按正文 / Long press on the body
    APP_GESTURE_SWIPE_UP, ///< 上滑 / Swipe up
    APP_GESTURE_SWIPE_DOWN, ///< 下滑 / Swipe down
    APP_GESTURE_SWIPE_LEFT, ///< 左滑 / Swipe left
    APP_GESTURE_SWIPE_RIGHT, ///< 右滑 / Swipe right
    APP_GESTURE_TWO_FINGER_TAP, ///< 双指轻点 / Two-finger tap
    APP_GESTURE_COUNT
} app_gesture_slot_t;

/// 取某槽位的动作；非法槽位返回 APP_GESTURE_ACTION_NONE。
/// Read a slot's action; an invalid slot reads as APP_GESTURE_ACTION_NONE.
app_gesture_action_t app_settings_gesture_action(app_gesture_slot_t slot);
/// 保存某槽位动作；成功时预设编号回到 0（自定义）。失败不改映射。
/// Persist one slot; success drops the preset id to 0 (custom). Failure changes nothing.
bool app_settings_set_gesture_action(app_gesture_slot_t slot, app_gesture_action_t action);
/// 当前预设：0 自定义，1..4 预设。/ Current preset: 0 custom, 1..4 predefined.
uint8_t app_settings_gesture_preset(void);
/// 应用预设 1..4 并保存（0 表示只把预设编号清回自定义，不改映射）。
/// Apply and persist preset 1..4 (0 only clears the preset id back to custom).
bool app_settings_set_gesture_preset(uint8_t preset);
/// 名称表；越界返回空串。/ Display names; out-of-range reads as an empty string.
const char *app_settings_gesture_slot_name(app_gesture_slot_t slot);
const char *app_settings_gesture_action_name(app_gesture_action_t action);
const char *app_settings_gesture_preset_name(uint8_t preset);

/// 坚果云 WebDAV 配置上限。/ Jianguoyun WebDAV configuration limits.
#define APP_CLOUD_USER_MAX 96
#define APP_CLOUD_SECRET_MAX 96
#define APP_CLOUD_DIR_MAX 192
/// 坚果云连接配置；folder 为相对服务器根目录，空串或 "/" 表示根。
/// Jianguoyun settings; folder is relative to the server root, empty or "/" means the root.
typedef struct {
    char user[APP_CLOUD_USER_MAX];
    char password[APP_CLOUD_SECRET_MAX];
    char folder[APP_CLOUD_DIR_MAX];
} app_cloud_config_t;
/// 读取配置；未配置时返回 false 并清零 out。密码以混淆形式存 NVS，不参与设置备份。
/// Read the configuration; false with a cleared out when unset. The secret is stored obfuscated
/// in NVS and deliberately stays out of the settings backup.
bool app_settings_cloud_get(app_cloud_config_t *out);
/// 保存配置；空 user 或空 password 视为清除。返回持久化结果。
/// Persist the configuration; an empty user or password clears it. Returns the NVS result.
esp_err_t app_settings_cloud_set(const app_cloud_config_t *config);
/// 是否已保存账号与应用密码。/ Whether an account and app password are stored.
bool app_settings_cloud_configured(void);
/// 清除账号、密码与目录。/ Forget the account, password and directory.
void app_settings_cloud_clear(void);

/// 书架排序偏好重启后保持。/ Persist the shelf's recent-reading sort across restarts.
bool app_settings_shelf_recent_sort(void);
void app_settings_set_shelf_recent_sort(bool on);
/// 蓝牙翻页器：启用 BLE HID 主机，好让蓝牙翻页器连上并翻页；默认关闭。
/// 关掉会把整个 BLE 栈拆掉，把 NimBLE 占的内存还回去。
/// Bluetooth page-turner: bring up the BLE HID host so a remote can pair and turn pages; off
/// by default. Turning it off tears the whole stack down and returns NimBLE's memory.
bool app_settings_ble_turner(void);
void app_settings_set_ble_turner(bool on);
/// 字间距默认0px，31档以0居中。/ Default 0px, centered among 31 tracking stops.
#define APP_BOOK_TRACK_MIN (-15)
#define APP_BOOK_TRACK_MAX 15
#define APP_BOOK_TRACK_COUNT (APP_BOOK_TRACK_MAX-APP_BOOK_TRACK_MIN+1)
/// 字间距索引0..30对应-15..+15px，每档1px。/ Tracking indices 0..30 map to -15..+15px, in 1px steps.
uint8_t app_settings_book_tracking(void);
void app_settings_set_book_tracking(uint8_t index);
/// 普通正文首行缩进 0..3 字，默认两字。/ First-line indent: 0..3 em, default 2.
uint8_t app_settings_book_indent(void);
void app_settings_set_book_indent(uint8_t em);
/// 正文首行缩进微调，-100..100像素，默认0；无缩进时不生效。/ First-line adjustment in pixels, -100..100 (default 0); ignored with no indent.
int8_t app_settings_book_indent_adjust(void);
void app_settings_set_book_indent_adjust(int8_t px);
/// 正文阅读线：0 无，1 虚线，2 点线。/ Body reading guides: none, dashed or dotted.
uint8_t app_settings_book_reading_line(void);
void app_settings_set_book_reading_line(uint8_t style);
/// 阅读线相对默认位置 -8..+8 像素，2 像素一步，默认 0。/ Guide offset in 2 px steps.
int8_t app_settings_book_reading_line_offset(void);
void app_settings_set_book_reading_line_offset(int8_t offset_px);
/// 阅读行高百分比，100..150。/ Reader line-height percentage: 100..150.
uint8_t app_settings_book_line_spacing(void);
void app_settings_set_book_line_spacing(uint8_t percent);
/// 阅读页左右边距，0..48 像素。/ Reader horizontal margin: 0..48 pixels.
uint8_t app_settings_book_margin(void);
void app_settings_set_book_margin(uint8_t px);
/// 阅读页上下边距，0..48 像素，UI 档位 0/6/.../48；与左右边距独立。
/// Reader vertical margin: 0..48 pixels in UI stops of 6, independent of the horizontal one.
uint8_t app_settings_book_margin_v(void);
void app_settings_set_book_margin_v(uint8_t px);
/// 段距11档，25%居中，0..100%。/ Eleven paragraph-gap stops centered on 25%, spanning 0..100%.
#define APP_BOOK_PARAGRAPH_COUNT 11
uint8_t app_settings_book_paragraph_value(uint8_t level);
uint8_t app_settings_book_paragraph_level(uint8_t percent);
uint8_t app_settings_book_paragraph_spacing(void);
void app_settings_set_book_paragraph_spacing(uint8_t percent);
/// 书架样式：1 深色书轨、2 亚克力、5 列表、6 液态玻璃；旧3/4安全回退2，缺省仍为2。
/// Shelf styles: rail (1), acrylic (2), list (5), liquid glass (6); retired IDs 3/4 fall back to 2, default stays 2.
uint8_t app_settings_shelf_style(void);
void app_settings_set_shelf_style(uint8_t style);
/// 固定 TF 根目录：/sdcard/books 与 /sdcard/fonts；旧配置/备份不能修改。/ Fixed TF roots, unaffected by legacy settings/backups.
const char* app_settings_books_dir(void);
const char* app_settings_fonts_dir(void);
/// TF卡内自定义目录，持久化成功后才更改当前路径。/ Custom SD roots change only after persistence succeeds.
bool app_settings_set_books_dir(const char* path);
bool app_settings_set_fonts_dir(const char* path);

/// 将设置、阅读记录和 WiFi 凭据保存到 TF 卡根目录；备份含明文密码，需妥善保管。
/// Save settings, reading records and WiFi credentials to TF root; keep the plaintext-secret backup private.
esp_err_t app_settings_backup_save(void);
/// 校验备份后恢复 NVS；缺失的外部字体或壁纸回退到内建资源。
/// Validate before restoring NVS; missing external assets fall back safely.
esp_err_t app_settings_backup_restore(void);