/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include "epdiy.h"
#include <stdbool.h>

/// 柔和文字序列：白底到中灰的少量回浅脉冲提前；具体阅读模式由板级出口选择。
/// Soft text phases advance a few gray-edge settling pulses; board output selects the reading modes that use them.
const EpdWaveform* display_reader_text_waveform(void);

/// 普通/图文翻页：厂商 GL16 37 相派生 41 相（等值黑→黑去掉擦白相，定稿 3 相保持前插 4 相
/// 全屏擦白）；整屏全像素输出用。LUT 首次调用分配在 PSRAM，失败回退厂商 E0470_WAVEFORM。
/// Ordinary/image turns: vendor GL16 (37 phases) derived to 41 (equal black-on-black drops its
/// erase phases; four whole-screen erase phases are inserted before the three settle holds) for
/// whole-screen full-pixel output. The LUT is allocated in PSRAM on first use; allocation failure
/// falls back to the vendor E0470_WAVEFORM.
const EpdWaveform* display_reader_soft_turn_waveform(void);

/// 阅读水波纹：柔和文字序列 37 相 + 定稿保持前 4 相变白 = 41 相；尾部 3 相非纯等值保持、
/// 相数不符或 PSRAM 分配失败时回退柔和文字序列（37 相）。
/// Reading ripple: soft text phases (37) plus four changed-white phases before settling = 41;
/// falls back to the soft text sequence (37) when the settling tail is not pure holds, the phase
/// count differs or the PSRAM allocation fails.
const EpdWaveform* display_reader_water_waveform(void);

/// 速读黑白：复用原厂完整 DU 表（20 相，含末尾保持相），不改表、不调脉宽。
/// Fast BW: the vendor's complete DU table (20 phases, trailing holds included), tables and pulse widths untouched.
const EpdWaveform* display_reader_fast_text_waveform(void);

/// 速读黑白准备：把本轮正文/页脚目标区域（逻辑坐标）按 50% 阈值改成纯黑白，
/// 真实旧灰阶与区域外像素保持不动；返回 false 时调用方回退普通 GL16 差分。
/// Fast BW prepare: threshold this turn's body/footer target area to pure BW at 50%, leaving real
/// old grays and outside pixels untouched; false means the caller falls back to plain GL16 diff.
bool display_reader_fast_text_prepare(EpdiyHighlevelState* hl, EpdRect area);
