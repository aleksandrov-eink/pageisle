# 11522 / issue #24：书架删不了书（P0-2）+ 部分书不进“最近阅读”（P0-4）

- 分析对象：`read-pico-reader-0.3.3-rc99`，产品版本 1.15.21（源码 626 KB 级 app_book.c）。
- 方法：**纯静态代码审查**（grep + 分段精读调用链）+ 单文件 `syntax_check.py` 语法检查。
- 结论等级：**仅代码分析 + 语法检查**。本报告不声称任何真机验证；设备没有可用日志，用户反馈也没有日志，
  因此根因均以源码调用链与返回值为证据，改动均为可回退的小步修改。
- 独占写范围：`main/apps/app_book.c`、`main/book/book_store.c/.h`、`main/apps/app_dashboard.c`
  （Lead 已补充授权 app_dashboard.c；`main/apps/app_home.c` 是「概览 Overview」页，与“最近阅读”无关，未改）。

---

## 一、P0-2 书架删不了书

### 1.1 调用链（书架上所有删除入口最终都落到同一个函数）

```
书架 MANAGE 视图（书架长按书籍 → s_view = MANAGE）
  → manage_action() 点“删除文件” → s_delete_confirm = true
  → manage_action() 点“确认删除” → manage_apply()            app_book.c
      → book_store_delete(s_managed.path, &removed)          book_store.c
批量（管理 → BULK）
  → batch_action() 二次确认 → batch_apply()                  app_book.c
      → book_store_delete(item.path, &removed)               book_store.c
```

`book_store_delete()` 成功时返回 `book_progress_forget()` 的结果；即“删文件”和“清进度”是一个返回码，
任何一步失败都会让 `manage_apply()` 走失败提示分支。

### 1.2 根因 A：删除白名单只接受“书根的直接子文件”，而书架收录范围大得多

旧实现（改动前 `main/book/book_store.c` 的 `book_store_delete`）：

- 只识别三类前缀：配置的 books 目录、legacy `/sdcard/book`、`/flash/books`；
- 取 `name = path + root_len + 1`（相对路径）后，用下面的循环**逐字符拒绝 `/`**：

```c
for (const unsigned char* p = (const unsigned char*)name; *p; ++p) {
    if (*p < 32 || *p == 127 || *p == '/' || *p == '\\' || *p == ':') return ESP_ERR_INVALID_ARG;
}
```

也就是说，`book_store_delete()` 只允许删除书根下的**直接**普通文件，任何带子目录的相对路径一律
`ESP_ERR_INVALID_ARG` 且 `*removed = false`。

但书架本身明确会收录这两类“非直接子文件”的书：

1. **书根多级目录**：`app_book.c` 的书架扫描是递归的（`BOOK_SCAN_DEPTH_LIMIT 12`，
   `shelf_walk_step()` 对 `S_ISDIR` 下钻），分类（二级书架）与云同步目录都是 books 下的一级目录；
2. **卡内任意位置读过的书**：`shelf_backfill_read_books()` / `shelf_backfill_visit()` 会把
   `book_progress_list()` 里“文件仍在、大小一致、格式支持”的记录补上书架（README/更新日志也写明
   “从文件管理打开并保存进度的 TXT/EPUB 可以位于 TF 卡任意位置”，见 docs/CHANGELOG.md:385）。

于是这些书在书架/分类/云同步里能点开、能管理，但一删除就命中 `ESP_ERR_INVALID_ARG`：

- 单本 MANAGE：`manage_apply()` 中 `removed == false` → `delete_retry_discard()`，`err != ESP_OK`
  → 提示 **“文件删除失败，请检查存储后重试”**，书仍在列表；
- 批量 BULK：`batch_apply()` 计 `failed++`，提示 **“成功 0 本，失败 N 本”**，所选保留。

**高命中场景**：云同步下载固定保存到 `books/云同步/`（`app_cloud.c:1326`），二级书架是 books 的子目录，
因此凡是使用云同步或分类目录的用户，这批书全部“删不掉”；用文件管理打开过的书也一样。
这与用户主诉“书架删不了书”完全吻合，且无需特殊卡/特殊日志即可复现。

### 1.3 根因 B：删除成功但进度清理失败时，已删条目会“还留在列表里”

`book_store_delete()` 末尾 `return book_progress_forget(path);`：文件已删（`*removed = true`）但
NVS 清理失败（空间吃紧/记录占用/瞬时写错误）时仍返回错误。此时：

- `manage_apply()`：把对应 `s_shelf[i].removed = true` 后 `return`（**没有**重排/过滤），
  返回书架时 `s_visible_count` 没变，渲染循环按 `s_shelf[i]` 照旧画出这本书；
- `batch_apply()`：失败项 `item.removed = true` 被保留在 `s_shelf`，随后 `sort_shelf()` 也不会排除它，
  因为 `shelf_matches()` / `compare_books()` / 渲染循环都不看 `removed`；
- 下一次扫描时 `scan_shelf_finish()` 会把内存里的 retry 条目重新插回 `s_shelf`（`entry.removed = true`），
  `sort_shelf()` 仍可能把它排在可见区——于是书架又出现一本“文件已经不存在”的书，点进去才提示
  “文件已删除，进度清理失败，请重试”。
- 另外，retry 队列只在内存里保留（注释也写明“保留到本次开机结束”），但**没有执行器**：
  除用户手动点进 MANAGE 重试外，任何路径都不会再调用 `book_progress_forget()`；开机后队列丢失，
  进度记录与 last 可能一直残留。

这解释了“删除后列表仍显示 / 无法真正删除”的另一半。

### 1.4 修复内容

#### `main/book/book_store.c`（+ `.h`）

- 新增 `delete_relative_path_valid()`（145 行起）、`delete_book_suffix()`（167 行）与共用
  `delete_impl()`（180 行起），两个公开入口在 254/258 行。
  - 逐段校验相对路径：拒绝空段、`.`、`..`、`\`、`:`、控制字符、单段 >255 字节、结尾 `/`；
  - 严格模式（`nested=false`）额外拒绝任何 `/`，保持原“直接子文件”契约；
  - 书籍后缀白名单不变（TXT / EPUB / MD / MARKDOWN，大小写不敏感）。
- 内部共用 `delete_impl(path, nested, removed)`：
  - `nested=false`：配置 books 目录 / legacy `/sdcard/book` / `/flash/books` 的**直接子文件**，
    行为与返回码与改动前逐条一致（原 `book_store_delete` 契约、host 测试不变）；
  - `nested=true`：书根**任意层级**，或已挂载 `/sdcard` / `/flash` 上的真实书籍文件
    （对应“文件管理任意位置读过的书”）；根仍必须是目录、目标仍必须是普通文件（symlink/目录拒绝）、
    媒体未挂载仍返回 `ESP_ERR_INVALID_STATE`，`.rename-backup` 处理逻辑保留（无“复活”回归）。
- 导出两个入口：`book_store_delete()`（冻结契约，保持给内部/恢复路径）与新增
  `book_store_delete_shelf()`（书架删除）。`app_book.c` 的两处书架删除改调后者。
- 文件头说明与 `book_store.h` 的 API 注释同步更新。

#### `main/apps/app_book.c`

- 7438 `shelf_matches()`：`removed` 条目一律不匹配 → 分页/批量/渲染/封面预热共用同一可见性口径，
  已删文件的 retry 占位不会再显示成普通书。
- 7554 新增 `delete_retry_flush()`：进入图书应用时、以及书架扫描收尾前，自动对 retry 条目补做
  `book_progress_forget()`，成功即释放；删除真正收尾。
- 7838 `scan_shelf_finish()`：在把 retry 条目插回 `s_shelf` 前先 `delete_retry_flush()`，
  已清理成功的条目不再回列表。
- 10199 `on_enter()`：进入图书应用先自动补清一次（覆盖“本次开机内多次切页”的遗留）。
- 8231 `manage_apply()` 失败分支：若文件已删（`s_file_removed`），立即 `sort_shelf()` 重排，
  返回书架时看不到已删课本；清理交给 `delete_retry_flush()` 后续自动补做。
- 8211 / 9775：单本 `manage_apply()` 与批量 `batch_apply()` 的删除改调 `book_store_delete_shelf()`，
  覆盖书根多级目录与卡内任意位置的书。
- 7276-7280 `open_book_impl()`：打开成功后若首次进度写入失败，立即再调一次 `save_progress()`，
  避免“一次瞬时失败 → 这本书永远不进首页最近阅读”（同时服务 P0-4）。

### 1.5 兼容性、风险与需要 Lead 决策的测试同步

- **安全性**：新增的“卡内任意位置”分支只接受已挂载媒体上、后缀白名单内的普通文件，且逐段拒绝
  `..`/反斜杠/冒号/控制字符，不能越出 `/sdcard`、`/flash`；老行为中“越界路径/非书籍后缀/目录/
  符号链接/未挂载”仍然全部拒绝。风险面：带进度记录、后缀为书籍格式的文件可被书架删除；这些路径
  只可能来自本机书架扫描或本机 NVS 进度，且需要用户在 MANAGE 二次确认，风险可接受（报告 Lead 知悉）。
- **host 测试**：`book_store_host_test.c` 覆盖的旧“直接子文件”契约**保持不变**（`book_store_delete`
  仍是严格模式），该测试无需修改、应继续通过。
- **host 测试需要同步（tools/ 不在我的写权限内，请 Lead 处理）**：
  `tools/book_ui_host_test.py` 抽取了 `app_book.c` 的 `on_enter()` 等函数并编译；本次在 `on_enter()`
  中新增调用 `delete_retry_flush()`，因此：
  1. 第 394-395 行的抽取名字列表需要加入 `"delete_retry_flush"`（它只依赖该测试已模拟的
     `book_progress_forget()` 与已声明的 `s_delete_retries`）；
  2. 第 721 行 `assert(...&&s_shelf[0].removed)` 依赖“removed retry 条目排第一”。现在
     `shelf_matches()` 把 removed 条目排到列表末尾（可见列表不再包含它），该断言应改为遍历
     `s_count` 找到该 path 的条目再断言 `removed`；语义（失败项保留在 s_shelf 供重试）不变。
  该测试不在 `.github/workflows/build.yml` 的 CI 任务里，但属于 `tools/run_book_management_tests.sh`
  的手工回归，建议一并更新。
- 书架可见性/分页/批量选择口径统一后，`select_page()` 不再把 removed 条目算进当前页；
  失败项仍可用“清除勾选”处理后重试。

---

## 二、P0-4 部分书不进“最近阅读”

“最近阅读”的真实数据源是 `main/apps/app_dashboard.c`（首页 Home：`s_current` 继续阅读卡 +
`s_recent[6]` + “最近阅读书夹”组件），不是 `main/apps/app_home.c`（那是「概览 Overview」）。

### 2.1 数据链

```
阅读页 save_progress()                         app_book.c
  → pending_flush() → book_progress_save()     写 NVS 进度（rp_books）+ 持久序号
                    → book_progress_set_last_path()  仅当 p->path == s_latest_path
首页 app_dashboard.c on_enter()
  → book_progress_last_path() → s_current（继续阅读卡）
  → book_progress_list() → recent_visit()/consider_book() → s_recent[6]（按持久序号）
  → folder_books() → “最近阅读书夹”（最多 3 本，要求 has_progress）
```

### 2.2 根因 A：进度版本变化时只刷新旧槽位，新增的“最近阅读”记录永远补不进来

旧 `on_enter()` 的缓存判定（app_dashboard.c 旧 993 行）：

```c
if (same && !changed) {                                   // 目录/存储/SD/last 路径都没变
    if (s_cached_progress_revision != progress_revision) refresh_progress();
    s_scan_pending = false;
}
```

旧 `refresh_progress()`（旧 275-283 行）只对**已经在 `s_current`/`s_recent` 里的 7 个槽位**重新
`book_progress_load()`，**从不调用 `book_progress_list()` 把新记录补进列表**。

因此只要“某本书有了进度记录、但 last 路径没变”，它就不会出现在首页最近阅读，直到下次
last 路径变化 / 存储版本变化 / 重启 / 换卡触发全量 `scan_books()`。现实触发路径：

1. **云同步进度写回**：`book_progress_sync.c:868` `book_progress_save(row->path, ...)` 直接写回本机
   进度；只调 `book_progress_notify_changed()`（875 行），不动存储版本、不改 last 路径。
2. **文件管理改名/移动非当前书**：`app_files.c:199-209 migrate_book_state()` 对新路径
   `book_progress_save(new_path)`；只有 `was_last` 时才更新 last 路径。被改名/移动的书若不是“最后一本”，
   新增的进度路径在主页面缓存视角里就是“新书”。
3. 清进度后重新打开同一本书（进度重建但 last 已经是该路径时）等边界。

用户感知：**“打开/阅读部分书后，首页最近阅读不出现它们”**，且具有“部分/随机、过一段时间或重启后
又出现”的特征——与缓存门槛的触发条件一致。

### 2.3 根因 B：首页停留期间进度变化不触发任何刷新

`on_tick()` 只处理 `s_scan_pending`（SD 探测/换卡）和时钟/封面，没有检查进度版本。后台云同步在
首页停留期间写回进度后，页面会一直显示进入时的旧列表，`present()` 用的还是旧 `s_recent`。

### 2.4 修复内容（`main/apps/app_dashboard.c`）

- 175 行：为 `restore_cover_cache()` 增加前置声明（进度刷新后要按路径重新绑定封面）。
- 278-310 `refresh_progress()`：
  - 保留原有 7 槽位进度刷新；
  - 追加一次 `book_progress_list(recent_visit, NULL)`：新进度记录经 `consider_book()` 按持久序号
    插到正确位置（`consider_book` 自带去重，不会重复插入）；
  - 为新条目补 title / EPUB 缓存元数据；
  - `restore_cover_cache()` 按路径重新绑定旧封面像素，并将书夹拼贴（`s_folder`）作废重建。
- 1107-1115 `on_tick()`：HOME_ROOT 下发现 `book_progress_revision()` 变化 → 更新缓存版本、
  `refresh_progress()`、返回 `APP_REDRAW_PAGE`，首页自愈为最新列表（不会自触发循环：刷新只读 NVS）。

### 2.5 附带修复（打开成功路径的写入可靠性，app_book.c:7276-7280）

`open_book_impl()` 打开成功后 `pending_mark_latest(s_path); save_progress();`。若首次 NVS 写失败
（空间回收、掉电缓存等瞬时错误），旧实现只等阅读页 15 s 定时重试；用户若立刻退出，首页只看 last 路径，
这本书就可能“进不了最近阅读”。新增“失败立即再试一次”，降低瞬时失败对用户可见性的影响。

### 2.6 未解决/需要真机确认的边界（不臆造改动）

- **NVS 容量**：`boards/pico/partitions.csv` 的 nvs 分区仅 `0x5000`（20 KiB），同时存设置（65 个键）、
  书签、书名、收藏、启动检查点以及每本书的进度记录。书籍/书签非常多时，`book_progress_save()` 可能
  返回 `ESP_ERR_NVS_NOT_ENOUGH_SPACE`，这类书的进度/最近阅读会写不进去。静态审查无法确认用户设备的
  NVS 占用；如果有日志，建议先抓 `book_progress: progress persistence: ...` 告警确认。本次未改
  NVS 分区表（不在我的写权限内，属 Lead/发布层决策）。
- **条数上限**：`s_recent[6]` 与书夹 3 本是既有产品设计（书夹文案“三本最近阅读”），不算缺陷；
  未改动。
- 打开失败（格式不支持/内存不足/文件不可读）本来就不该进最近阅读：`open_book_impl()` 失败路径
  `pending_discard()` 已处理，未改。

---

## 三、验证

| 项 | 结果 |
|---|---|
| `syntax_check.py main/book/book_store.c` | exit 0 |
| `syntax_check.py main/apps/app_book.c` | exit 0（仅 1 条既有警告 `reader_panel_action` 内 `remove_rect` unused，未触碰该函数） |
| `syntax_check.py main/apps/app_dashboard.c` | exit 0 |
| 真机 | **未验证**（无真机；不得声称通过） |
| 整机构建 | 由 Lead 统一 `idf.py build` |

## 四、真机待验项（按优先级）

1. **云同步/子目录书删除**：`books/云同步/`、二级分类目录里的书 → 管理 → 删除所选 → 确认；
   预期：文件从卡中消失、书架条目消失、重新扫描不复活、重启后不复现。
2. **卡内非书根书删除**：文件管理打开卡内其他目录的 TXT/MD → 返回书架（应被补录）→ 删除；
   预期：同上。
3. **删除失败的提示**：拔卡/USB 读卡占用中删除 → 应提示失败且不误删；插回后可重试成功。
4. **最近阅读补录**：连接云同步做一次进度写回（或被改名/移动的非当前书）后回首页；
   预期：该书出现在首页最近阅读/书夹，无需重启。
5. **首页自愈**：停留在首页时后台云同步写回进度；预期：页面自动更新为新列表（一次整页刷新）。
6. **既有功能不回归**：根目录书删除、清进度、移出书架、收藏、最近排序、续读卡/阅读统计书夹；
   删除单个文件后管理页“已选/失败/成功”计数正确。
7. 长时间使用（NVS 接近满）后阅读新书是否仍出现在最近阅读；如仍偶发，抓
   `book_progress: progress persistence:` 告警反馈（对应 2.6 的 NVS 容量风险）。

## 五、改动文件清单

- `main/book/book_store.c`：新增 `delete_impl` 共用实现与 `book_store_delete_shelf()`；原
  `book_store_delete()` 严格契约保持不变；路径/后缀校验重写。
- `main/book/book_store.h`：新增 `book_store_delete_shelf()` 声明，`book_store_delete` 契约注释澄清。
- `main/apps/app_book.c`：删除调用改 `book_store_delete_shelf`；`delete_retry_flush` 自动重试、
  removed 可见性过滤、删除失败即时重排、打开成功路径进度立即重试。
- `main/apps/app_dashboard.c`：最近阅读记录补录 + 封面/书夹重建 + 首页 on_tick 进度版本自愈。
- 本报告。
