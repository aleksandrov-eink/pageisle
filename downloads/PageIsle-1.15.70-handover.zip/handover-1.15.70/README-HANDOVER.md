# 页屿 PageIsle 定制版 · 交付汇总（小纸 Pico，系统 1.15.70）

适用设备：RDP-G01-W（ESP32-S3 电子墨水屏，逻辑分辨率 684×1216，横屏 1216×684）。
系统名：**页屿 PageIsle**（对外品牌；固件包名、版本号、分区表仍是上游 0.3.3-rc99，未改动）。
本包是 **页屿系统 1.15.70**（2026-11-12）；**所有代码只做了编译、静态分析与宿主测试，未在真机上运行过**，真机结论以用户反馈为准。

## 一、最终固件

| 项目 | 值 |
|---|---|
| 版本 | 上游应用 0.3.3-rc99（页屿系统 **1.15.69**） |
| 应用镜像大小 | **3,707,056 字节** |
| ota_0 分区余量 | **487,248 字节（约 11.62%）** |
| sha256 | `5e374698a3c78618098102a0d28f7ab3a9e2293611d118b7b9b97e49cf412473` |

## 二、1.15.69 → 1.15.70 主要变化

- **文字残影低闪微调（本版核心）**：普通·高清 / 水波纹·高清都按用户真机反馈做了「每页纯白像素补推 + 翻页表黑→白补白相」；
  水波·高清约 **+44ms/页**，**未新增整屏闪烁**；新逻辑均为编译宏可回退（详见 `docs/改版日志与刷机指南.md` 0.79 节）。
- **蓝牙翻页器**：1.15.69 已修复（P0 用户真机已通过），本版未改动。
- 其余与 1.15.69 相同（分区表 / bootloader / OTA 布局未改；书、设置与阅读记录保留）。

## 二、刷机方式

三种方式任选，推荐第 1 种：

1. **单文件全量刷机（推荐）**：`usb-full-package/Pico-full-flash-1.15.70.bin`（bootloader + 分区表 +
   otadata + 应用合成镜像），一条命令：
   `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.70.bin`
   （16MB flash 约 1–2 分钟；分区表未变，书籍/NVS 设置保留）。
2. **USB 四文件全量包**：`usb-full-package/` 的
   `bootloader.bin / partitions.bin / ota_data_initial.bin / firmware.bin`，按同目录 `flash_args`
   分地址写入：`python -m esptool --chip esp32s3 -p COMx write_flash @flash_args`。
3. **TF 卡升级（预计被拒绝，属正常）**：`firmware/Pico-update.bin` 放 TF 根目录 → 设置 → 升级和恢复 →
   本地升级。因上游应用版本仍是 0.3.3-rc99，设备「同版本检查」会提示「升级包与当前版本相同」并拒绝，
   这是固件既有逻辑，不是包损坏；请改用方式 1/2。
4. 分区表和 bootloader 未改动；升级不会清空书籍、设置与阅读记录。

## 三、本版详细说明

- **P0 蓝牙翻页器**：设置 →「蓝牙翻页器」开启并连接；阅读页测试键盘类键（PageUp/PageDown/方向键/
  空格/回车）、消费者页键（音量 +/−、上一曲/下一曲、快进/快退）、非标遥控器用「学习」绑定。
  按一次应翻一页；方向默认「下一页/音量+/右→下一页，上一页/音量−/左→上一页」。
  详细步骤与日志判读见 `docs/真机验收清单-1.15.70.md` 与 `docs/蓝牙翻页器验收卡.md`。
  已知限制：仅支持 BLE，纯 Classic 蓝牙翻页器连不上（S3 硬件限制）；冷启动后需在设置里点一下
  已配对设备或顶部快捷层蓝牙圆钮重连。
- **P1 残影**：阅读翻页模式选「水波纹·高清」后连翻 10–30 页，清理后继续翻 2–3 页观察上一页
  字影是否再出现；另验证退出阅读/书架/首页、锁屏唤醒、静置 10 分钟、图片页/章节切换。
  逐项回退宏（编译期）：`DISPLAY_HD_WATER_SETTLE_TABLE=0`、`DISPLAY_ANTI_FADE_AFTER_CLEANUP_HOLD_MS=0`、
  `DISPLAY_LIGHT_CLEANUP_ACCOUNT_INTERNAL_GC16=0`。
- **P2 横屏并排**：横屏 + 横排 + 显示插图时生效；含图页图片在一侧栏、文字另一栏窄列换行；
  竖屏/竖排/纯文字页不变；翻页/回看/旋转/改字号后位置不丢。回退宏：`BOOK_LANDSCAPE_SIDE_IMAGE=0`
  （逐字节恢复旧单列）。

## 四、文件清单

```
handover-1.15.69/
├─ firmware/Pico-update.bin              # TF 卡升级镜像（3,707,056 B；同版本检查会拒绝，备用）
├─ usb-full-package/                     # USB 完整刷机包
│  ├─ Pico-full-flash-1.15.70.bin        # 单文件合成刷机镜像（推荐，一条命令刷完）
│  ├─ firmware.bin / bootloader.bin / partitions.bin / ota_data_initial.bin
│  ├─ flash_args / manifest.json
│  ├─ 改版日志与刷机指南.md / 使用说明.txt
│  └─ SHA256SUMS.txt
├─ rollback-1.15.53/                     # 离线回退 1.15.53
│  ├─ Pico-full-flash-1.15.53.bin        # 单文件合成刷机镜像（推荐）
│  ├─ Pico-update.bin                    # 3,687,280 B / f7fc…95bd
│  ├─ 回退说明.txt / SHA256SUMS.txt
├─ docs/                                 # 同一套文档副本 + 校验和 + 真机验收清单 + 蓝牙验收卡
├─ promo-fun/                            # 宣传图（沿用）
├─ README-HANDOVER.md                    # 本文件
└─ GitHub上传指南.md                     # 网页版上传步骤
```

## 五、校验

- `Pico-update.bin` / `firmware.bin`：`5e374698a3c78618098102a0d28f7ab3a9e2293611d118b7b9b97e49cf412473`
- USB 包内 `SHA256SUMS.txt` 覆盖 `bootloader.bin`、`firmware.bin`、`ota_data_initial.bin`、`partitions.bin`；
  升级前可自行核对。

## 六、回退（重要）

- 回退到 **1.15.53 正式版**（推荐用单文件）：`rollback-1.15.53/Pico-full-flash-1.15.53.bin`
  `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.53.bin`；
  其单独 TF 镜像为 `rollback-1.15.53/Pico-update.bin`（3,687,280 字节，
  sha256 `f7fc2253cd8637c8e3ce9334a13f60c6ebfd191c49f5cb4b8dd3f8661ece95bd`，TF 内升级同样会被
  同版本检查拒绝，请走 USB）；
- 或回退到 **1.15.69 默认宏关闭构建**（如需要，可让开发重新出包）；
- 本版未改分区表/bootloader/OTA 布局，回退只需重刷应用镜像。

## 七、已知限制（如实说明）

- 本版**未真机验证**：编译 0 error、warning 与 1.15.53 同量（11 条历史遗留、无新增）；
  BLE 宿主测试真实运行 PASS，横屏并排控件级探针 PASS（含宏 0 逐字节等价证明），残影改动只做了
  目标编译语法检查（本机无原生 host gcc，未跑仓库全部宿主测试）。
- 蓝牙翻页器：仅 BLE；冷启动不自动连回；`blept:` 诊断日志默认开启（下一版可关）。
- 残影：水波纹·高清每页约 +44ms；清理后 60 秒内静置白推被抑制（若观感变差可回退）。
- 横屏并排：一页最多一张并排图；整页图/纯文字页行为不变；第 0 页有题头带时图从带下方开始。
- 横屏并排的宿主回归依赖自建桩（zig cc），仓库自带 `book_layout_host_test.c` 在本仓库快照上
  本就过期（非本版改动引入），已在开发报告注明。

## 八、建议的真机复测顺序

1. **P0**：蓝牙翻页器连接 → 阅读页按音量 +/−、上一曲/下一曲、PageUp/PageDown（各 2 次）→
   方向与次数是否正确 → 断线重连/开关 WiFi 各一次 → 回传 `blept:` 日志。
2. **P1**：水波纹·高清连翻 10–30 页 → 观察清理后上一页字影是否再冒出 → 退出阅读/锁屏/静置。
3. **P2**：横屏含插图 EPUB → 图在左/右交替、文字窄列换行、不压图不变形 → 翻页/回看/旋转/改字号。
4. **回归**：开机/锁屏/深睡/充电、书架/设置/横竖屏/字体边距重排、WiFi 传书/OTA/云同步、其他翻页档位。

## 九、源码

源码位于开发机的 `read-pico-reader-0.3.3-rc99` 目录；如需上传 GitHub，可直接把整个源码目录
打包（排除 `build/`）作为 Release 附件或仓库内容，步骤见 `GitHub上传指南.md`。
