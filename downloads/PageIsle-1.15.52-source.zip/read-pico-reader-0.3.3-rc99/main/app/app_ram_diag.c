/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：逐界面运行内存诊断的实现。采样内部 SRAM（DIRAM 窗口）与 PSRAM 的运行时占用，
 * 按 app 页面累计峰值；页面切换时结算上一页并追加一行 TF 卡日志（卡不在则静默）。
 * English: Per-screen runtime RAM diagnostics. Samples internal-SRAM (DIRAM window) and
 * PSRAM use, accumulates per-app peaks, settles the previous page on every switch and
 * appends one TF-card log line (silent when the card is absent).
 *
 * 内部 SRAM 口径：DIRAM 窗口总量固定为链接脚本 LENGTH(dram0_0_seg) = 0x53700 = 341,760 B
 * （与 esp_idf_size 的 DIRAM 行一致）；静态段在运行时由链接符号算出，heap 部分取
 * heap_caps 的 total-free。因此把静态大数组搬到 PSRAM 后百分比会自动下降，不需要改常量。
 * Internal-SRAM accounting: the DIRAM window is the fixed linker value LENGTH(dram0_0_seg)
 * = 0x53700 = 341,760 B (same as esp_idf_size's DIRAM row). Static sections are derived at
 * runtime from linker symbols and the heap share comes from heap_caps total-free, so moving
 * static arrays to PSRAM lowers the percentage automatically with no constant to edit.
 */

#include "app_ram_diag.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"

#define TAG "ram_diag"

// 内部 SRAM 的 DIRAM 窗口总量：ESP32-S3 链接脚本 0x53700 = 341,760 B。
// Internal DIRAM window total: ESP32-S3 linker script 0x53700 = 341,760 B.
#define APP_RAM_DIAG_INTERNAL_TOTAL 341760u

// PSRAM 总量兜底：heap API 尚未就绪（返回 0）时按 8 MB 板型显示，避免除零。
// PSRAM total fallback for the 8 MB board when the heap API is not ready yet (avoids /0).
#define APP_RAM_DIAG_PSRAM_FALLBACK_TOTAL (8u * 1024u * 1024u)

// 采样节流：每页至多 500 ms 读一次 heap API，主循环空转时不增加开销。
// Sample throttle: one heap probe per page per 500 ms so idle ticks stay free.
#define APP_RAM_DIAG_SAMPLE_MS 500

// 日志只在离开页面时追加；超过 128 KiB 时从新文件重写，避免长期使用无限增长。
// Log only appends on page leave; past 128 KiB the file restarts so long use cannot grow it forever.
#define APP_RAM_DIAG_LOG_PATH "/sdcard/pageisle_ram_diag.log"
#define APP_RAM_DIAG_LOG_MAX_BYTES (128u * 1024u)

typedef struct {
    const app_desc_t *app;   // 页面身份：同一实现可能服务多个页面，必须用指针区分。/ Identity: one impl may serve several pages, so keep the pointer.
    const char *name;        // app_desc_t->title，注册表里的静态字符串。/ Static title pointer from app_desc_t->title.
    uint16_t internal_peak;  // 内部 SRAM 峰值，0.1% 单位。/ Internal-SRAM peak in 0.1% units.
    uint16_t psram_peak;     // PSRAM 峰值，0.1% 单位。/ PSRAM peak in 0.1% units.
    uint32_t min_free;       // 内部 heap 最小剩余字节。/ Minimum free internal heap bytes.
    bool valid;              // 至少采样过一次。/ At least one sample taken.
} app_ram_diag_slot_t;

// 峰值表放 PSRAM：诊断设施不能占用被诊断的内部 RAM。
// The peak table lives in PSRAM: the diagnostic must not consume the RAM it measures.
static EXT_RAM_BSS_ATTR app_ram_diag_slot_t s_slots[APP_RAM_DIAG_MAX_ENTRIES];
static int s_slot_count;
static const app_desc_t *s_current;
static int s_current_slot = -1;
static int64_t s_last_sample_ms;
static uint16_t s_baseline_internal;
static bool s_started;

// 内部 SRAM 静态占用：data/bss（_data_start.._heap_start）加上 DIRAM 内代码区
// （_iram_start.._iram_end，其 DRAM 别名位于 _data_start 之前）。
// Internal static share: data/bss plus the code area (the DRAM alias of _iram_start.._iram_end
// sits right before _data_start). Both symbol pairs are defined by the IDF linker script.
static size_t internal_static_bytes(void)
{
    extern int _data_start, _heap_start, _iram_start, _iram_end;
    const size_t data = (size_t)((uintptr_t)&_heap_start - (uintptr_t)&_data_start);
    const size_t code = (size_t)((uintptr_t)&_iram_end - (uintptr_t)&_iram_start);
    const size_t total = data + code;
    if (total == 0 || total >= APP_RAM_DIAG_INTERNAL_TOTAL) return 0;  // 符号异常时交回退分支 / fall back when symbols look wrong
    return total;
}

// 内部 SRAM 占用率（0.1%）：(静态 + 内部 heap 已用) / DIRAM 窗口。
// Internal utilisation (0.1%): (static + allocated internal heap) / DIRAM window.
static uint16_t internal_pct_x10(size_t *used_out)
{
    const size_t heap_total = heap_caps_get_total_size(MALLOC_CAP_INTERNAL);
    const size_t heap_free = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    const size_t stat = internal_static_bytes();
    size_t used;
    if (stat != 0 && heap_total >= heap_free) {
        used = stat + (heap_total - heap_free);
    } else {
        // 链接符号不可用时退化：假设窗口剩余与内部 heap 空闲相同。/ Fallback: treat window remainder as free internal heap.
        used = APP_RAM_DIAG_INTERNAL_TOTAL > heap_free
            ? APP_RAM_DIAG_INTERNAL_TOTAL - heap_free : 0;
    }
    if (used > APP_RAM_DIAG_INTERNAL_TOTAL) used = APP_RAM_DIAG_INTERNAL_TOTAL;
    if (used_out != NULL) *used_out = used;
    return (uint16_t)((used * 1000u + APP_RAM_DIAG_INTERNAL_TOTAL / 2u) / APP_RAM_DIAG_INTERNAL_TOTAL);
}

// PSRAM 占用率（0.1%）：(total-free)/total；heap API 未就绪时用 8 MB 兜底总量。
// PSRAM utilisation (0.1%): (total-free)/total, with the 8 MB fallback total before the heap is ready.
static uint16_t psram_pct_x10(uint32_t *total_out, uint32_t *free_out, uint32_t *used_out)
{
    size_t total = heap_caps_get_total_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    const size_t free_bytes = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (total == 0) total = APP_RAM_DIAG_PSRAM_FALLBACK_TOTAL;
    const size_t used = total > free_bytes ? total - free_bytes : 0;
    if (total_out != NULL) *total_out = (uint32_t)total;
    if (free_out != NULL) *free_out = (uint32_t)free_bytes;
    if (used_out != NULL) *used_out = (uint32_t)used;
    // 8 MB PSRAM 时 used*1000 会超过 32 位，这里必须用 64 位中间量。
    // With 8 MB PSRAM, used*1000 overflows 32 bits, so the intermediate must be 64-bit.
    return (uint16_t)(((uint64_t)used * 1000u + (uint64_t)total / 2u) / (uint64_t)total);
}

static int slot_for(const app_desc_t *app)
{
    if (app == NULL) return -1;
    for (int i = 0; i < s_slot_count; ++i) {
        if (s_slots[i].app == app) return i;
    }
    if (s_slot_count >= APP_RAM_DIAG_MAX_ENTRIES) return -1;
    app_ram_diag_slot_t *slot = &s_slots[s_slot_count];
    memset(slot, 0, sizeof(*slot));
    slot->app = app;
    slot->name = (app->title != NULL && app->title[0] != '\0') ? app->title : "未知页面 Unknown";
    return s_slot_count++;
}

// 采样当前页并把峰值/最小剩余写进它的槽位。/ Sample the current page into its slot.
static void sample_current(int64_t now_ms)
{
    s_last_sample_ms = now_ms > 0 ? now_ms : 1;
    if (s_current_slot < 0 || s_current_slot >= s_slot_count) return;
    app_ram_diag_slot_t *slot = &s_slots[s_current_slot];
    size_t internal_used = 0;
    uint32_t psram_used = 0;
    const uint16_t internal_peak = internal_pct_x10(&internal_used);
    const uint16_t psram_peak = psram_pct_x10(NULL, NULL, &psram_used);
    const size_t internal_heap_free =
        heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!slot->valid || internal_peak > slot->internal_peak) slot->internal_peak = internal_peak;
    if (!slot->valid || psram_peak > slot->psram_peak) slot->psram_peak = psram_peak;
    if (!slot->valid || (uint32_t)internal_heap_free < slot->min_free)
        slot->min_free = (uint32_t)internal_heap_free;
    slot->valid = true;
}

// 离开页面时追加一行：t=ms app=标题 internal=xx.x% free=NNNN B psram=xx.x%
// 只在页面切换写，不每 tick 写；卡不在/只读时静默失败，不重试也不打日志。
// One line per page leave; silent when the card is absent or read-only.
static void log_slot(const app_ram_diag_slot_t *slot)
{
    if (slot == NULL || !slot->valid) return;
    struct stat info;
    const bool rotate = stat(APP_RAM_DIAG_LOG_PATH, &info) == 0 &&
        (size_t)info.st_size > APP_RAM_DIAG_LOG_MAX_BYTES;
    FILE *file = fopen(APP_RAM_DIAG_LOG_PATH, rotate ? "w" : "a");
    if (file == NULL) return;  // TF 卡未挂载：静默 / card absent: stay silent
    const long long now_ms = (long long)(esp_timer_get_time() / 1000);
    fprintf(file,
            "t=%lld app=%s internal=%u.%u%% free=%lu B psram=%u.%u%%\n",
            now_ms, slot->name != NULL ? slot->name : "?",
            (unsigned)(slot->internal_peak / 10u), (unsigned)(slot->internal_peak % 10u),
            (unsigned long)slot->min_free,
            (unsigned)(slot->psram_peak / 10u), (unsigned)(slot->psram_peak % 10u));
    fclose(file);
}

void app_ram_diag_init(void)
{
    if (s_started) return;
    s_started = true;
    s_slot_count = 0;
    s_current = NULL;
    s_current_slot = -1;
    s_last_sample_ms = 0;
    s_baseline_internal = internal_pct_x10(NULL);
    // 串口基线：实机可据此核对 DIRAM 口径（静态应接近 esp_idf_size 的 259,511 B，
    // 多出的 heap_used 就是 boot 期间系统已分配的内部堆）。
    // Serial baseline: lets a real device verify the DIRAM accounting (static should be near
    // esp_idf_size's 259,511 B; the extra heap_used is system internal-heap use at boot).
    const size_t heap_total = heap_caps_get_total_size(MALLOC_CAP_INTERNAL);
    const size_t heap_free = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    ESP_LOGI(TAG, "boot baseline internal=%u.%u%% static=%u heap_used=%u heap_total=%u heap_free=%u",
             (unsigned)(s_baseline_internal / 10u), (unsigned)(s_baseline_internal % 10u),
             (unsigned)internal_static_bytes(),
             (unsigned)(heap_total > heap_free ? heap_total - heap_free : 0),
             (unsigned)heap_total, (unsigned)heap_free);
}

void app_ram_diag_switch(const app_desc_t *app)
{
    if (!s_started) app_ram_diag_init();
    if (app == NULL || app == s_current) return;
    // 先结算上一页（写入 SD 日志），再登记新页并立即采样一次。
    // Settle the previous page (SD log) before registering the new one and sampling it.
    if (s_current_slot >= 0 && s_current_slot < s_slot_count)
        log_slot(&s_slots[s_current_slot]);
    s_current = app;
    s_current_slot = slot_for(app);
    sample_current(esp_timer_get_time() / 1000);
}

void app_ram_diag_tick(const app_desc_t *app, int64_t now_ms)
{
    if (!s_started) app_ram_diag_init();
    // 返回/定时提醒等路径直接改 current 而不走 switch_to，这里按指针变化兜底。
    // Return and reminder paths change `current` without switch_to; catch the pointer change here.
    if (app != s_current) {
        app_ram_diag_switch(app);
        return;
    }
    if (s_last_sample_ms != 0 && now_ms - s_last_sample_ms < APP_RAM_DIAG_SAMPLE_MS) return;
    sample_current(now_ms);
}

void app_ram_diag_mem(app_ram_diag_mem_t *out)
{
    if (out == NULL) return;
    memset(out, 0, sizeof(*out));
    size_t internal_used = 0;
    out->internal_total = APP_RAM_DIAG_INTERNAL_TOTAL;
    out->internal_pct = internal_pct_x10(&internal_used);
    out->internal_used = (uint32_t)internal_used;
    out->internal_free = out->internal_total - out->internal_used;
    out->internal_heap_free =
        (uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    out->internal_heap_total = (uint32_t)heap_caps_get_total_size(MALLOC_CAP_INTERNAL);
    uint32_t psram_total = 0, psram_free = 0, psram_used = 0;
    out->psram_pct = psram_pct_x10(&psram_total, &psram_free, &psram_used);
    out->psram_total = psram_total;
    out->psram_free = psram_free;
    out->psram_used = psram_used;
}

uint16_t app_ram_diag_baseline_internal_pct(void)
{
    if (!s_started) app_ram_diag_init();
    return s_baseline_internal;
}

int app_ram_diag_count(void)
{
    return s_slot_count;
}

bool app_ram_diag_entry(int index, const char **name, uint16_t *internal_peak_pct,
                        uint32_t *min_free, uint16_t *psram_peak_pct)
{
    if (index < 0 || index >= s_slot_count) return false;
    const app_ram_diag_slot_t *slot = &s_slots[index];
    if (!slot->valid) return false;
    if (name != NULL) *name = slot->name;
    if (internal_peak_pct != NULL) *internal_peak_pct = slot->internal_peak;
    if (min_free != NULL) *min_free = slot->min_free;
    if (psram_peak_pct != NULL) *psram_peak_pct = slot->psram_peak;
    return true;
}

void app_ram_diag_reset(void)
{
    if (!s_started) app_ram_diag_init();
    memset(s_slots, 0, sizeof(s_slots));
    s_slot_count = 0;
    // 当前页继续统计：清空后立刻重新登记，避免设置页自己的行消失。
    // Keep counting the current page: re-register at once so the settings row does not vanish.
    s_current_slot = slot_for(s_current);
    s_last_sample_ms = 0;
    if (s_current != NULL) sample_current(esp_timer_get_time() / 1000);
    ESP_LOGI(TAG, "statistics reset, current page retained");
}
