/* SPDX-License-Identifier: Apache-2.0
 * 中文：主页保持等灰；退出书架只向白色加强擦除。柔和水波纹端点单向驱动，中灰保留原序列，不改厂商表和扫描时序。
 * English: Main pages hold equal grays; shelf exit strengthens whitening only toward white. Soft water uses directional endpoints and original intermediate-gray sequences without editing vendor tables or scan timing.
 * 用户修订：快刷亚克力保留校准GL16，移除偏深且慢的试验灰阶；保留同向擦白用于书架分页及退出。
 * User revision: fast acrylic retains calibrated GL16; remove the dark, slow experimental gray drive and keep directional whitening for shelf paging/exit.
 */
#include "display_main_waveform.h"
#include "display_waveform_smooth.h"
#include "esp_heap_caps.h"
#include "app_config.h"
#include "e0470_epaper_waveform.h"
#include <stdbool.h>
#include <string.h>

static uint8_t s_data[E0470_GL16_FRAMES][16][4];
static const EpdWaveformPhases s_phases = {E0470_GL16_FRAMES, (const uint8_t*)s_data, NULL};
static const EpdWaveformPhases* s_ranges[] = {&s_phases};
static const EpdWaveformMode s_mode = {5, 1, s_ranges};
static const EpdWaveformMode* s_modes[] = {&s_mode};
static EpdWaveform s_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_modes};
static bool s_ready;
#define MAIN_ERASE_EXTRA_FRAMES 4
#define MAIN_EXIT_FRAMES (E0470_FULL_DU_FRAMES + MAIN_ERASE_EXTRA_FRAMES)
static uint8_t s_exit_data[MAIN_EXIT_FRAMES][16][4];
static const EpdWaveformPhases s_exit_phases = {MAIN_EXIT_FRAMES, (const uint8_t*)s_exit_data, NULL};
static const EpdWaveformPhases* s_exit_ranges[] = {&s_exit_phases};
static const EpdWaveformMode s_exit_mode = {1, 1, s_exit_ranges};
static const EpdWaveformMode* s_exit_modes[] = {&s_exit_mode};
static EpdWaveform s_exit_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_exit_modes};
static bool s_exit_ready;
static uint8_t s_water_data[E0470_GL16_FRAMES][16][4];
static const EpdWaveformPhases s_water_phases = {E0470_GL16_FRAMES, (const uint8_t*)s_water_data, NULL};
static const EpdWaveformPhases* s_water_ranges[] = {&s_water_phases};
static const EpdWaveformMode s_water_mode = {5, 1, s_water_ranges};
static const EpdWaveformMode* s_water_modes[] = {&s_water_mode};
static EpdWaveform s_water_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_water_modes};
static bool s_water_ready;
static uint8_t s_bw_data[E0470_FULL_DU_FRAMES][16][4];
static const EpdWaveformPhases s_bw_phases={E0470_FULL_DU_FRAMES,(const uint8_t*)s_bw_data,NULL};
static const EpdWaveformPhases* s_bw_ranges[]={&s_bw_phases};
static const EpdWaveformMode s_bw_mode={1,1,s_bw_ranges};
static const EpdWaveformMode* s_bw_modes[]={&s_bw_mode};
static EpdWaveform s_bw_waveform={.num_modes=1,.num_temp_ranges=1,.mode_data=s_bw_modes};
static bool s_bw_ready;
_Static_assert(MAIN_EXIT_FRAMES <= E0470_GL16_FRAMES, "soft water must fit endpoint cleanup");

static int endpoint_action(const EpdWaveformPhases* bw, int f, int to, int from) {
    if (to == from) return 0;
    if (f < bw->phases) return e0470_phase_action(bw, f, to, from);
    // 只给变白像素补四相同向推动；未变白底与最终黑字均不增加推动。
    // Add four same-direction pushes only to whitening pixels, never unchanged backgrounds or final black text.
    return to == 15 && f < bw->phases + MAIN_ERASE_EXTRA_FRAMES ? 2 : 0;
}

const EpdWaveform* display_main_gray_waveform(void) {
    if (!s_ready) {
        const EpdWaveformPhases* original = e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16);
        if (!original || original->phases != E0470_GL16_FRAMES || !original->luts || original->phase_times)
            return &E0470_WAVEFORM;
        memcpy(s_data, original->luts, sizeof(s_data));
        for (int f = 0; f < E0470_GL16_FRAMES; ++f)
            for (int v = 0; v < 16; ++v)
                s_data[f][v][v / 4] &= (uint8_t)~(3u << (6 - 2 * (v % 4)));
        s_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
        s_ready = true;
    }
    return &s_waveform;
}

const EpdWaveform* display_main_shelf_exit_waveform(void) {
    if (!s_exit_ready) {
        const EpdWaveformPhases* bw = e0470_waveform_phases(&E0470_WAVEFORM, MODE_DU);
        if (!bw || bw->phases != E0470_FULL_DU_FRAMES || !bw->luts || bw->phase_times)
            return &E0470_WAVEFORM;
        // 取消GC16中灰到白的反向压黑；一次输出内增强白推动，不另起清屏。
        // Remove GC16's reverse darkening on gray-to-white; strengthen white drive in one update without a separate clear.
        for (int to = 0; to < 16; ++to)
            for (int from = 0; from < 16; ++from) {
                for (int f = 0; f < MAIN_EXIT_FRAMES; ++f)
                    s_exit_data[f][to][from / 4] |= (uint8_t)(endpoint_action(bw, f, to, from) << (6 - 2 * (from % 4)));
            }
        s_exit_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
        s_exit_ready = true;
    }
    return &s_exit_waveform;
}

const EpdWaveform* display_main_water_waveform(void) {
    if (!s_water_ready) {
        const EpdWaveformPhases* bw = e0470_waveform_phases(&E0470_WAVEFORM, MODE_DU);
        const EpdWaveformPhases* gl = e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16);
        if (!bw || !gl || !bw->luts || !gl->luts || bw->phases != E0470_FULL_DU_FRAMES ||
            gl->phases != E0470_GL16_FRAMES || bw->phase_times || gl->phase_times)
            return &E0470_WAVEFORM;
        for (int to = 0; to < 16; ++to)
            for (int from = 0; from < 16; ++from)
                for (int f = 0; f < E0470_GL16_FRAMES; ++f) {
                    const int action = to == from ? 0 : to == 0 || to == 15
                        ? endpoint_action(bw, f, to, from) : e0470_phase_action(gl, f, to, from);
                    s_water_data[f][to][from / 4] |= (uint8_t)(action << (6 - 2 * (from % 4)));
                }
        s_water_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
        s_water_ready = true;
    }
    return &s_water_waveform;
}

const EpdWaveform* display_main_bw_waveform(void) {
    if(!s_bw_ready) {
        const EpdWaveformPhases* bw=e0470_waveform_phases(&E0470_WAVEFORM,MODE_DU);
        if(!bw || !bw->luts || bw->phases!=E0470_FULL_DU_FRAMES || bw->phase_times)return &E0470_WAVEFORM;
        memcpy(s_bw_data,bw->luts,sizeof(s_bw_data));
        for(int f=0;f<E0470_FULL_DU_FRAMES;++f)for(int v=0;v<16;++v)
            s_bw_data[f][v][v/4]&=(uint8_t)~(3u<<(6-2*(v%4)));
        s_bw_waveform.temp_intervals=E0470_WAVEFORM.temp_intervals;s_bw_ready=true;
    }
    return &s_bw_waveform;
}

// 普通切页独立派生；水波纹/快刷不改，内存紧张回退现有柔和表。
// Derive ordinary output independently; water/fast stay unchanged and low memory falls back to the existing soft table.
// 面板层切换用的 AA 修复表：只驱动「等灰对」里的中灰（1..14，即字形/抗锯齿边缘），纯黑 0→0 与
// 纯白 15→15 一律保持，避免整幅非差分 GL16 把黑字短暂擦白；非等灰对沿用原 GL16 动作。
// AA-repair table for panel-layer transitions: among equal pairs only mid-grays (1..14, the glyph
// antialiased fringes) are driven; pure black 0->0 and pure white 15->15 hold so a full-pixel
// update cannot briefly wipe the text; non-equal pairs keep the original GL16 actions.
static uint8_t s_aa_repair_data[E0470_GL16_FRAMES][16][4];
static const EpdWaveformPhases s_aa_repair_phases = {E0470_GL16_FRAMES, (const uint8_t*)s_aa_repair_data, NULL};
static const EpdWaveformPhases* s_aa_repair_ranges[] = {&s_aa_repair_phases};
static const EpdWaveformMode s_aa_repair_mode = {5, 1, s_aa_repair_ranges};
static const EpdWaveformMode* s_aa_repair_modes[] = {&s_aa_repair_mode};
static EpdWaveform s_aa_repair_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_aa_repair_modes};
static bool s_aa_repair_ready;

const EpdWaveform* display_aa_repair_waveform(void) {
    if (!s_aa_repair_ready) {
        const EpdWaveformPhases* original = e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16);
        if (!original || !original->luts || original->phases != E0470_GL16_FRAMES || original->phase_times)
            return &E0470_WAVEFORM;
        memcpy(s_aa_repair_data, original->luts, sizeof(s_aa_repair_data));
        for (int f = 0; f < E0470_GL16_FRAMES; ++f)
            for (int v = 0; v < 16; ++v) {
                if (v != 0 && v != 15) continue;
                s_aa_repair_data[f][v][v / 4] &= (uint8_t)~(3u << (6 - 2 * (v % 4)));
            }
        s_aa_repair_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
        s_aa_repair_ready = true;
    }
    return &s_aa_repair_waveform;
}

// 白底推白表（1.15.38 起只用于「静置防褪色」；翻页清残影不再调用）：只对「纯白→纯白」迁移施加
// **纯白推**帧（动作 2，往白推），不包含任何压黑帧；其余所有迁移全部保持。静置防褪色每 5 分钟
// 左右对纯白像素补几帧白推，白底本来就白、视觉上几乎不可见；黑字/抗锯齿/中灰不驱动。
// 1.15.24–1.15.37 的翻页白推/双轮复位已全部移除，翻页不再调用此表。
// 表在 RAM 里派生，不改厂商 waveform 数据。
// White-ground white-push table (since 1.15.38 only the idle anti-fade uses it; page turns no longer
// call it): only the pure white action is applied to the equal-white pair, no darken phase. The
// idle anti-fade tops pure-white pixels up with a few white frames every ~5 minutes; black glyphs,
// AA fringes and mid-grays are not driven. The 1.15.24-1.15.37 per-turn white push / two-cycle reset
// is removed. Derived in RAM; the vendor waveform data is untouched.
#define WHITE_REPAIR_FRAMES 8
static uint8_t s_white_repair_data[WHITE_REPAIR_FRAMES][16][4];
static EpdWaveformPhases s_white_repair_phases;
static const EpdWaveformPhases* s_white_repair_ranges[] = {&s_white_repair_phases};
static const EpdWaveformMode s_white_repair_mode = {5, 1, s_white_repair_ranges};
static const EpdWaveformMode* s_white_repair_modes[] = {&s_white_repair_mode};
static EpdWaveform s_white_repair_waveform = {.num_modes=1, .num_temp_ranges=1, .mode_data=s_white_repair_modes};
static bool s_white_repair_ready;

const EpdWaveform* display_reader_white_repair_waveform(void) {
    if (!s_white_repair_ready) {
        memset(s_white_repair_data, 0, sizeof(s_white_repair_data));
        // 只写 (to=15, from=15) 的槽位：data[frame][15][15/4]，shift 由 from%4 决定；
        // 动作 2 = 擦白/往白推（1 是压黑，这里一帧都不用）。
        // Only the (to=15, from=15) slot: data[frame][15][15/4], shift from from%4;
        // action 2 = erase/white push (action 1 would darken and is never used here).
        const uint8_t white = (uint8_t)(2u << (6 - 2 * (15 % 4)));
        for (int f = 0; f < WHITE_REPAIR_FRAMES; ++f) s_white_repair_data[f][15][15 / 4] = white;
        s_white_repair_phases.phases = WHITE_REPAIR_FRAMES;
        s_white_repair_phases.luts = (const uint8_t*)s_white_repair_data;
        s_white_repair_phases.phase_times = NULL;
        s_white_repair_waveform.temp_intervals = E0470_WAVEFORM.temp_intervals;
        s_white_repair_ready = true;
    }
    return &s_white_repair_waveform;
}

const EpdWaveform* display_main_normal_waveform(void) {
    static EpdWaveformPhases phases;
    static const EpdWaveformPhases *ranges[]={&phases};
    static EpdWaveformMode mode={MODE_GL16,1,ranges};
    static const EpdWaveformMode *modes[]={&mode};
    static EpdWaveform waveform={.num_modes=1,.num_temp_ranges=1,.mode_data=modes};
    if(phases.luts)return &waveform;
    const EpdWaveform *base=display_main_water_waveform();
    const EpdWaveformPhases *original=e0470_waveform_phases(base,MODE_GL16);
    if(!original||!original->luts||original->phases!=E0470_GL16_FRAMES||original->phase_times)return base;
    uint8_t *data=heap_caps_malloc(E0470_GL16_FRAMES*16*4,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!data)return base;
    memcpy(data,original->luts,E0470_GL16_FRAMES*16*4);
    for(int to=1;to<15;++to)for(int from=0;from<16;++from)
        if(to!=from)display_soften_gray_pair(data,original,to,from);
    phases=(EpdWaveformPhases){E0470_GL16_FRAMES,data,NULL};
    waveform.temp_intervals=base->temp_intervals;
    return &waveform;
}

// 仅书架普通切页：封面/材质灰阶完整保留，留白只向白推动，不再先压黑。
// Ordinary shelf transitions retain calibrated art grays; whitespace drives only white without reverse blackening.
const EpdWaveform* display_main_shelf_waveform(enum EpdDrawMode draw_mode) {
    static EpdWaveformPhases phases[2];
    static const EpdWaveformPhases *ranges[2][1]={{&phases[0]},{&phases[1]}};
    static EpdWaveformMode modes[2]={{MODE_GL16,1,ranges[0]},{MODE_GC16,1,ranges[1]}};
    static const EpdWaveformMode *mode_ptrs[2][1]={{&modes[0]},{&modes[1]}};
    static EpdWaveform waves[2]={
        {.num_modes=1,.num_temp_ranges=1,.mode_data=mode_ptrs[0]},
        {.num_modes=1,.num_temp_ranges=1,.mode_data=mode_ptrs[1]}};
    int index=draw_mode==MODE_GC16?1:0;
    if(phases[index].luts)return &waves[index];
    const EpdWaveformPhases *original=e0470_waveform_phases(&E0470_WAVEFORM,draw_mode);
    const EpdWaveformPhases *soft=e0470_waveform_phases(display_main_normal_waveform(),MODE_GL16);
    if(!original||!soft||!original->luts||!soft->luts||original->phase_times||soft->phase_times||original->phases>soft->phases)
        return &E0470_WAVEFORM;
    size_t size=(size_t)original->phases*16*4;
    uint8_t *data=heap_caps_malloc(size,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!data)return &E0470_WAVEFORM;
    memcpy(data,original->luts,size);
    for(int f=0;f<original->phases;++f)memcpy(data+f*16*4+15*4,soft->luts+f*16*4+15*4,4);
    phases[index]=(EpdWaveformPhases){original->phases,data,NULL};
    waves[index].temp_intervals=E0470_WAVEFORM.temp_intervals;
    return &waves[index];
}

// 用户2026-10-20恢复二级底色：浅灰卡片也使用原完整灰阶，白底沿用同向擦白；底栏由独立裁剪保护。
// User revision2026-10-20: restore complete original gray drive for light cards and directional white erasure; separate clipping protects navigation.
const EpdWaveform* display_main_ui_waveform(void) {
    return display_main_normal_waveform();
}

// 设置/列表滚动：与上游 rc103 一致，保留原厂完整擦白序列，在 3 相定稿保持之前插入
// 8 相“变白驱动”，得到 37+8=45 相（高清单层输出直接支持 45 相）。
// 尾部 3 相必须只有等值维持（不含任何改变像素的动作），否则不插相、直接保留柔和表。
// Settings/list scrolling follows upstream rc103: keep the vendor's complete white-erase
// sequence and insert eight changed-white drives before the three settle holds, giving
// 37+8 = 45 phases (the high-level list output supports 45 phases directly). The settling tail
// must contain only equal-pixel holds; otherwise the soft table is kept without insertion.
const EpdWaveform* display_settings_scroll_waveform(void) {
    // 用户2026-11-01（移植上游 rc103）：37 相原生 + 8 相变白 = 45 相。
    // User 2026-11-01 (ported from upstream rc103): 37 native + 8 changed-white = 45 phases.
    enum { WHITE = 8, HOLDS = 3, PHASES = E0470_GL16_FRAMES + WHITE };
    static EpdWaveformPhases phases;
    static const EpdWaveformPhases *ranges[]={&phases};
    static EpdWaveformMode mode={MODE_GL16,1,ranges};
    static const EpdWaveformMode *modes[]={&mode};
    static EpdWaveform waveform={.num_modes=1,.num_temp_ranges=1,.mode_data=modes};
    if(phases.luts)return &waveform;
    const EpdWaveform *base=display_main_normal_waveform();
    const EpdWaveformPhases *original=e0470_waveform_phases(base,MODE_GL16);
    if(!original||!original->luts||original->phases!=E0470_GL16_FRAMES||original->phase_times)return base;
    const int drive=original->phases-HOLDS;
    // 定稿尾 3 相只允许等灰保持；出现任何变色动作说明源表被改动，保留原表不插相。
    // Only equal holds are allowed in the three settling phases; any changed-pixel action means
    // the source table changed, so keep it untouched instead of inserting phases.
    for(int f=drive;f<original->phases;++f)
        for(int to=0;to<16;++to)for(int from=0;from<16;++from)
            if(to!=from&&e0470_phase_action(original,f,to,from))return base;
    uint8_t (*data)[16][4]=heap_caps_malloc((size_t)PHASES*64,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!data)return base;
    memcpy(data,original->luts,(size_t)drive*64);
    memset(data+drive,0,WHITE*64);
    memcpy(data+drive+WHITE,original->luts+(size_t)drive*64,HOLDS*64);
    // 等值对一律保持（含 15→15），只对变白目标追加 8 相擦白；不叠加第二次推屏。
    // Equal pairs stay held (including 15->15); only whitening targets get the eight erases.
    for(int f=0;f<PHASES;++f)for(int gray=0;gray<16;++gray)
        data[f][gray][gray/4]&=(uint8_t)~(3u<<(6-2*(gray%4)));
    for(int f=drive;f<drive+WHITE;++f)
        for(int from=0;from<15;++from)data[f][15][from/4]|=(uint8_t)(2u<<(6-2*(from%4)));
    phases=(EpdWaveformPhases){PHASES,(const uint8_t*)data,NULL};
    waveform.temp_intervals=base->temp_intervals;
    return &waveform;
}
