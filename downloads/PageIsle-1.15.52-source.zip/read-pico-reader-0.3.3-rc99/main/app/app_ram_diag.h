/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：逐界面运行内存诊断。按 app 页面记录「内部 SRAM（DIRAM 341,760 B 窗口）」
 * 与 PSRAM 的运行时峰值占用，供设置页「内存诊断」与 TF 卡日志查看；
 * 只读 heap API 与链接符号，不做显示调用，峰值表放 PSRAM，不占用被诊断的内部 RAM。
 * English: Per-screen runtime RAM diagnostics. Records internal-SRAM (the 341,760-byte
 * DIRAM window) and PSRAM peaks per app page for the Settings "RAM diagnostics" page
 * and an SD log; read-only heap/linker probing with no display calls, and the peak
 * table lives in PSRAM so the diagnostic does not consume the RAM it measures.
 *
 * 冻结：百分比一律以 0.1% 为单位（760 = 76.0%），整数运算，不用浮点。
 * Frozen: percentages are always in 0.1% units (760 = 76.0%) with integer math only.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "app.h"

#ifdef __cplusplus
extern "C" {
#endif

/// 峰值表容量（同时是设置页最多展示的数据源容量）。/ Peak-table capacity (also the settings-page data source cap).
#define APP_RAM_DIAG_MAX_ENTRIES 32

/// 一次内存快照：内部 SRAM 与 PSRAM 的总量/已用/剩余/占用率。
/// / One memory snapshot: totals, used, free and percentages for internal SRAM and PSRAM.
typedef struct {
    /// 内部 SRAM 的 DIRAM 窗口总量（链接脚本常量，341,760 B）。/ DIRAM window total (linker constant, 341,760 B).
    uint32_t internal_total;
    /// 内部 SRAM 已用 = 静态段 + 内部 heap 已分配。/ Internal used = static sections + allocated internal heap.
    uint32_t internal_used;
    /// 内部 SRAM 剩余 = 总量 - 已用。/ Internal free = total - used.
    uint32_t internal_free;
    /// 内部 heap 的空闲字节（排查「还剩多少可用」用）。/ Free internal heap bytes (headroom for the 80% gate).
    uint32_t internal_heap_free;
    /// 内部 heap 总容量（heap API 口径，约 82 KB；用于核对 DIRAM 剩余）。/ Total internal heap capacity (heap API view, ~82 KB).
    uint32_t internal_heap_total;
    /// 内部 SRAM 占用率，0.1% 单位。/ Internal utilisation in 0.1% units.
    uint16_t internal_pct;
    /// PSRAM 总量（heap API 不可用时用 8 MB 兜底并注释）。/ PSRAM total (8 MB fallback when the heap API is not ready).
    uint32_t psram_total;
    /// PSRAM 已用。/ PSRAM used.
    uint32_t psram_used;
    /// PSRAM 剩余。/ PSRAM free.
    uint32_t psram_free;
    /// PSRAM 占用率，0.1% 单位。/ PSRAM utilisation in 0.1% units.
    uint16_t psram_pct;
} app_ram_diag_mem_t;

/// 启动基线：在首个页面进入前调用一次，记录启动时的内部 SRAM 占用。
/// / Boot baseline: call once before the first page enters to record startup internal usage.
void app_ram_diag_init(void);

/// 页面切换：结算上一页峰值并追加一行 SD 日志，然后登记并立即采样新页。
/// / Page switch: settle/log the previous page, then register and sample the new one immediately.
void app_ram_diag_switch(const app_desc_t *app);

/// 主循环每轮调用：页面指针变化时兜底切页（返回/提醒等非 switch_to 路径），
/// 同一页最多每 500 ms 采样一次，避免每 tick 调 heap API。
/// / Called every loop tick: catches page changes that bypass switch_to (return/reminder),
/// and samples at most once per 500 ms per page so the heap API is not hit every tick.
void app_ram_diag_tick(const app_desc_t *app, int64_t now_ms);

/// 当前内存快照（设置页渲染时读；直接读 heap API，无缓存）。/ Live snapshot for the settings page.
void app_ram_diag_mem(app_ram_diag_mem_t *out);

/// 启动基线内部占用，0.1% 单位。/ Boot-baseline internal utilisation in 0.1% units.
uint16_t app_ram_diag_baseline_internal_pct(void);

/// 已记录页面的数量（按首次访问顺序）。/ Number of recorded pages (first-visit order).
int app_ram_diag_count(void);

/// 读取第 index 项：标题、内部峰值、内部 heap 最小剩余、PSRAM 峰值。
/// 百分比均为 0.1% 单位；未访问过或越界返回 false。
/// / Read entry index: title, internal peak, minimum free internal heap, PSRAM peak.
/// Percentages are in 0.1% units; false when out of range.
bool app_ram_diag_entry(int index, const char **name, uint16_t *internal_peak_pct,
                        uint32_t *min_free, uint16_t *psram_peak_pct);

/// 清空所有峰值（保留启动基线），并从当前页重新开始累计。
/// / Clear every peak (baseline survives) and restart accumulation from the current page.
void app_ram_diag_reset(void);

#ifdef __cplusplus
}
#endif
