# 1.15.23 浅色模式残影（显示层）根因分析与修复

> 任务：task-6（显示层）。代码：`main/display.c`、`main/display.h`（本文档）。
> 现场版本：1.15.22 内测（`87beed2`）。**无真机**：本文所有结论均为代码/波形数值分析 + 单文件语法检查，未经实屏验证。

## 0. 结论摘要（TL;DR）

1. **用户主诉**（Lead 转述）：浅色模式残影过多，主页+阅读都有；表现为**本应无色/白色的区域残留上一屏的黑色文字或图案**；**自 1.15.17 正式版起就存在**（不是 1.15.22 新回归）；阅读翻页效果=**水波纹·高清（effect 3）**。
2. **长期根因（显示/刷新策略层）**：浅色模式白底上的残影只有**真正的 GC16 清屏复位**（整屏全像素、每像素完整擦除→重写）才能清掉，但现有策略里真 GC16 的覆盖太稀疏：
   - 阅读：只有**每 15 次翻页**一次（`app_settings_reader_full_pages` 默认 15，`app_book.c` 的 `s_reader_cleanup`）；页间靠水波纹高清的**单次差分 GL16** 揭页，差分不驱动未变化像素、裁剪表的擦除余量也只有源表的 11/19，残留会累积到下一次全刷。
   - 主页：从阅读/其它页返回**没有真 GC16**（差分或全像素 GL16 转场），主页停留时时钟/秒针只做局部差分，`s_page_refreshes` 只统计整页切页 → 阅读留下的白底黑字残影可以在主页**长期不退**。
   - 白底像素在页间是“等灰对”，差分永远跳过它 → 一旦某次擦除不彻底，之后没有任何路径纠正，直到真 GC16。
3. **1.15.22 的活动期 GL16 重推不是修复、而且是加重项**（本轮已默认停用）：裁剪 GL16 表里等灰对并不是“保持”——黑字 0→0 是 **11 帧擦白 + 13 帧压黑（24 帧）**、抗锯齿中灰等灰对 **25–31 帧**，白底 15→15 只有 **1 帧白推**。即每 10 次页级输出就把整帧笔墨像素完整擦掉重写一遍（过驱动），却**清不掉白底残影**；每第 5 次升级的“全像素 GC16”还是**裁剪 36 相表**（擦除余量 11/19），等于每 50 次输出一次整屏灰闪，并非真正的 48 相 GC16 复位。
4. **1.15.22 的面板层 AA 修复表全像素定稿**（`app_book.c` 约 6466–6474 行，`display_aa_repair_waveform()`）是阅读区另一个纯过驱动源：它只重驱动**等灰中灰 1..14**（每档 25–31 帧、整幅读者区、每次开关工具栏/sheet），纯黑/纯白保持 → **清不了黑白残影**，只会反复擦写所有抗锯齿边。建议改回差分（精确补丁见 §7，Lead 应用）。
5. **本层修复**：① 默认停用 1.15.22 活动期 GL16 重推（宏可回滚）；② 新增低频**真 GC16 清理**：浅色模式整屏全像素 **48 相未裁剪 `E0470_FULL_WAVEFORM` GC16**（每像素完整擦除→重写，≈0.47–0.57 s/次），触发=**30 次页级输出**或**10 分钟（期间有任意浅色输出）**，并在任何页级 full-pixel GC16（阅读每 15 页清理、主页进入清理等）后自动归零，避免与页面层清理叠加双闪；③ 深→浅首帧擦白复位与共享复位函数保留不动；④ 反色/深色路径零改动。
6. **淡墨（1.15.22 修的淡墨）重新引入评估**：低风险。活动期重推对白底只有 1 帧白推，本来就不是有效的防淡墨手段；真正防淡墨的是：深→浅共享擦白复位（保留）、静置防泛白 `update_display_anti_fade`（保留）、以及现在的低频真 GC16（更强）。见 §6 的风险与回滚。

## 1. 现场与问题定义

| 项目 | 内容 |
| --- | --- |
| 版本 | 1.15.22 内测（用户反馈“1.15.17 正式版就有，一直没解决”） |
| 模式 | 浅色（非反色）；深色模式行为不在本问题范围 |
| 界面 | 主页 + 阅读，均出现 |
| 阅读翻页效果 | 水波纹·高清（`app_settings_reader_turn_effect() == 3`，`app_book.c:6430-6433`） |
| 现象 | 白底/无色区域残留上一屏的黑色文字或图案（残影） |
| 历史同类教训 | 1.13.1「白天补白」因过驱动累积残影被停用；1.15.18 取消反复压黑补扫；1.15.22 前的白天整片推白也因过驱动被停用（`app_book.c:6500-6506` 注释） |

## 2. 波形数值证据

### 2.1 方法

- 解析厂商完整表 `components/e0470_epaper_waveform/waveforms/gl16.h`、`gc16.h`（48 相，`data[frame][to][from/4]`，每 (to,from) 2bit 动作：0 保持 / 1 压黑 / 2 擦白）。
- 在 Python 中逐行复刻 `components/e0470_epaper_waveform/e0470_waveform_trim.c` 的裁剪算法（`erase_max=11`、`sat_cut=5`、`white_sat_cut=0`、`hold=3`）与 `e0470_epaper_waveform.c` 的 `e0470_gl16_white_tick()`（给 15→15 补 1 帧白推），得到固件运行时实际使用的表：
  - `E0470_WAVEFORM` GL16 = **37 相**、GC16 = **36 相**（裁剪表，活动期重推 / AA 修复表 / 常规刷新用）；
  - `E0470_FULL_WAVEFORM` GC16 = **48 相未裁剪**（深→浅首帧擦白复位、阅读周期清理用）。
- 帧时间：`read_pico_epd_timing.c` 在 18 MHz pclk、1216×684、bus 16bit（8 px/clk，152 clk/行，701 行/帧）下解出 **FULL 行 17 µs → 11 917 µs/帧**、**FAST 行 10 µs → 7 010 µs/帧**（波形标称 11 090 µs/帧）。
- 脚本：`C:\dshb\tmp\analyze_gl16_11523.py`（不入库）。

### 2.2 裁剪 GL16（37 相，`E0470_WAVEFORM`）等灰对：未变化像素实际被“擦白+压黑”

“全像素 GL16 重推”把整帧当作目标重推；因为内容没变，每个像素的 (to,from) 是 **等灰对**。裁剪表里这些等灰对的驱动量：

| 等灰对 (to→from) | 驱动帧数 | 构成 | 起始相 |
| --- | --- | --- | --- |
| 15→15（白底） | **1** | 1 帧白推（15→15 白 tick） | 33 |
| 0→0（黑字） | **24** | 11 帧擦白 + 13 帧压黑 | 10 |
| 1→1 … 14→14（AA 中灰） | **25–31** | 擦白 + 压黑 + 灰阶尾 | 3–9 |
| 16 个等灰对合计 | **419 帧** | — | — |

即一次“全像素 GL16 重推”对整帧的平均驱动是 **419/16 ≈ 26.2 帧/像素**（37 相里的 70.8%）：黑字像素被完整擦成白再压回黑 24 帧，AA 边 25–31 帧，**白底只推 1 帧**。

按 FULL 扫描、leading-skip 后实际扫 ~34–37 相，一次重推约 **0.40–0.44 s**（FULL）/ 0.24–0.26 s（FAST）。1.15.22 的触发是**每 10 次页级输出**（或 600 次局部输出、或 5 分钟），因此每个黑字像素每 10 页被额外擦写 24 帧、AA 边 25–31 帧——这就是过驱动；而白底那 1 帧白推根本压不掉上一屏残留的黑。

### 2.3 裁剪 GL16 的“平凡”迁移并不平凡：擦除余量被裁掉

| to←from（新←旧） | 裁剪 GL16 驱动 | 完整 48 相 GC16 驱动 |
| --- | --- | --- |
| 15←0（黑字变白底） | 18 帧白推 | 17 帧白推（另 0 帧压黑） |
| 15←8（中灰变白） | 24 帧 | 21 帧 |
| 0←15（白底变黑字） | 13 帧压黑 | 17 帧压黑 |
| 0←0（等灰黑） | 24 帧（11 擦 + 13 压） | **35 帧（18 擦 + 17 压）** |
| 15←15（等灰白） | 1 帧 | **35 帧（18 压 + 17 擦）** |

裁剪表的擦除上限是 **11/19 相**（`E0470_TRIM_ERASE_MAX=11`）。`e0470_waveform_trim.h` 自己写明代价：*“擦除余量变小，旧内容的残影会先出来”*。也就是说：**单次水波纹高清揭页（差分 GL16）按设计就会留下旧内容残影**，只能靠周期性的完整 GC16 清掉。

### 2.4 真 GC16 与 GL16 重推的本质差别

- 真 GC16（`E0470_FULL_WAVEFORM` 48 相未裁剪、全像素）：每个 (to,from) 都走完整“擦除到反向轨 → 饱和到目标轨 → 灰阶尾”，**等灰白 15→15 也要 35 帧**（18 压黑 + 17 擦白）——白底上的残影会被真正擦掉，残余电荷被释放。
- 裁剪 GL16 全像素重推：等灰白只有 1 帧、等灰黑 24 帧，**物理上不是一次复位**，只把笔墨像素反复擦写了 24–31 帧；它清不掉白底残影，还会累积残余电荷（与 1.13.1 白天补白、1.15.18 反复压黑同一类教训）。
- 1.15.22 的“每 5 次升级全像素 GC16”用的是**裁剪 36 相 GC16**（等灰白 28 帧、等灰黑 23 帧、擦除余量仍 11/19），不是 48 相完整复位；且白底等灰白序列是“先压黑 17 帧再擦白”，每 50 次输出会给整屏白底一次约 0.2 s 的压黑暗闪。
- 真正清残影的入口（现有）：`epd_clear()` + `E0470_FULL_WAVEFORM` GC16（深→浅首帧复位 `display_light_white_reset_unlocked`），或全像素 48 相 GC16（阅读周期清理 `update_display_area_full_with(&E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect())`）。

### 2.5 AA 修复表（`display_aa_repair_waveform()`，1.15.22 新增）

由裁剪 GL16 复制，仅把等灰对 0→0、15→15 清零，等灰中灰 1..14 保持原序列：

| 等灰对 | 驱动帧数 |
| --- | --- |
| 0→0 / 15→15 | **0（保持）** |
| 1→1 | 25 |
| 5→5 / 8→8 | 27 / 28 |
| 11→11 … 14→14 | 30 / 31 |

`app_book.c:6466-6474` 在**每次面板层切换**（正文 ↔ 工具栏/任一二三级 sheet）对 `reader_full_rect()`（整幅读者区）做一次全像素定稿。因为内容未变、全像素更新里只存在等灰对，所以它实际只重驱动所有**抗锯齿中灰**（整幅扫描约 0.43 s），纯黑/纯白完全不动 → **清不了白底黑字残影**，是纯过驱动；AA 问题的根因已在 1.15.22 字体层修复（task-2），这条显示层兜底不再需要。

## 3. 长期根因（显示/刷新策略）

| 编号 | 根因 | 证据 |
| --- | --- | --- |
| R1 | **白底等灰像素永不进差分**：只有初次进入/周期 GC16 才会驱动它们；一旦某次擦除不彻底，残留会一直留在白底上 | `epd_difference_image_cropped` + 差分刷新只驱动 front≠back；裁剪表等灰白 15→15 仅 1 帧白推 |
| R2 | **阅读真 GC16 覆盖太稀疏**：默认每 15 次翻页一次（`app_book.c:8318-8322`），页间是水波纹高清**单次差分 GL16**（`update_display_hd_water_unlocked`），裁剪表擦除余量 11/19 → 页间残留累积可见 | 2.3/2.4 数值；`s_reader_cleanup` 触发条件 |
| R3 | **主页没有真 GC16 覆盖**：从阅读返回主页是差分/全像素 GL16 转场，不是 GC16；主页停留时 `present_clock_motion/area` 只做局部差分，`s_page_refreshes` 只统计切页（`APP_UI_FAST_GC16_EVERY=12`）→ 阅读/前一屏的残影可在主页长期不退 | `app_loop.c:527/528`（阅读非主页面，返回不 arm 主页转场）；`app_dashboard.c` 刷新路径；`display.c` `main_begin` 计数逻辑 |
| R4 | **1.15.22 活动期 GL16 重推**（`display_light_activity_*`）：每 10 次页级输出全帧重推等灰对（0→0 24 帧、中灰 25–31 帧、白底仅 1 帧），第 5 次升级裁剪 36 相 GC16 → 加重过驱动、清不掉残影、偶发整屏灰闪 | §2.2/§2.4 |
| R5 | **1.15.22 AA 修复表全像素定稿**：每次面板层切换对整幅读者区重驱动所有 AA 中灰 25–31 帧，黑白保持 → 纯过驱动 | §2.5 |

R1–R3 是自 1.15.17 起就存在的显示层/页面层策略缺陷（与用户“1.15.17 就有”一致）；R4/R5 是 1.15.22 引入的加重项。**页面层的 R3 修复**（主页进入真 GC16、阅读周期清理提前/加时间触发）由 ghost-pages/Lead 负责；本任务只做显示层（R4 + 提供 R1–R3 的全局兜底 + R5 的补丁建议）。

## 4. 修复设计（`main/display.c` / `main/display.h`）

### 4.1 默认停用 1.15.22 活动期 GL16 重推

```c
#define DISPLAY_LIGHT_ACTIVITY_ENABLE 0     // 0=停用（默认）；1=恢复 1.15.22 行为（仅 A/B 回滚）
#define DISPLAY_LIGHT_ACTIVITY_PAGE_EVERY 10
#define DISPLAY_LIGHT_ACTIVITY_AREA_EVERY 600
#define DISPLAY_LIGHT_ACTIVITY_INTERVAL_MS 300000
#define DISPLAY_LIGHT_ACTIVITY_GC16_EVERY 5
```

旧代码（`display_light_activity_*`）整套保留，只在 `DISPLAY_LIGHT_ACTIVITY_ENABLE=1` 时执行；默认编译期即死代码。理由见 §2.2/§2.4：它清不掉白底残影、且每 10 页对笔墨像素过驱动一次。

### 4.2 新增低频「真 GC16 清理」

```c
#define DISPLAY_LIGHT_CLEANUP_ENABLE 1        // 90 天回滚：0=一键停用
#define DISPLAY_LIGHT_CLEANUP_PAGE_EVERY 30   // 页级输出（面积≥逻辑画布 50%）计数触发
#define DISPLAY_LIGHT_CLEANUP_INTERVAL_MS 600000  // 10 分钟计时触发
#define DISPLAY_LIGHT_CLEANUP_DEEP 0          // 1=追加 epd_clear 盲擦白（更强、多约 0.9s）
```

- **动作**：整屏（逻辑全画布）全像素 **`E0470_FULL_WAVEFORM` GC16**（48 相未裁剪），即真正的 GC16 复位：每个像素（含白底等灰对）完整擦除→重写；`DISPLAY_LIGHT_CLEANUP_DEEP=1` 时先 `epd_clear()` 再从白基准 GC16 写回（更强、约 +0.9 s）。单次常规清理约 **0.47–0.57 s**（含底栏）。
- **触发（OR）**：
  1. 自上次真清理以来累计 **30 次页级输出**（面积 ≥ 逻辑画布 50%）；或
  2. 距上次真清理 **≥10 分钟**且期间**至少有一次任意浅色输出**（局部输出也算“使用中”：主页停留只有时钟/秒针局部差分，若只认页级输出计时永远到不了点——这是主页停留缺口的兜底）。
  - 长时间完全没有输出（休眠/断电）的空档**不计入连续使用时长**，从下一次输出重新计时，避免久置后第一下就整屏闪。
- **归零规则**：任何**页级 full-pixel GC16 成功**都会把显示层计数/计时清零——阅读每 15 页清理（`update_display_area_full_with(&E0470_FULL_WAVEFORM, MODE_GC16, reader_full_rect)`）、阅读进入/目录返回清理、主页进入清理（Lead 应用的 ghost-pages 改动）、整屏全刷、图片灰阶、欠载恢复、面板修复、反色切换等都会归零。因此显示层清理**只作为兜底**，不会和页面层周期清理叠加成两次连闪。
- **失败处理**：只记诊断日志（新增 `light GC16 cleanup failed (%d)`），并置 `s_full_refresh_requested` 让下一帧整屏重画；不改变调用方主输出结果。
- **反色/深色路径零改动**：`epd_get_inverted()` 时直接返回，不进入任何浅色维护；逐页压黑、深色 GC16 复位、LUT 镜像/保持、`display_dark_*` 全部未改。

### 4.3 保留项（不回退）

- 深→浅首帧擦白复位 `s_light_white_reset_pending` / `display_light_white_reset_unlocked()`（`epd_clear` + `E0470_FULL_WAVEFORM` GC16 from white）完整保留，所有既有调用点未改。
- 静置防泛白 `update_display_anti_fade()` 保留原行为（仍是对静态画面做温和 GL16 白推，未改成整屏 GC16——用户此前不接受为此整屏闪）。
- 共享的 `display_light_page_level_area()`、`display_light_full_area()` 等工具保留。

### 4.4 为什么这样改能减少残影

1. 去掉 1.15.22 每 10 次页级输出的整帧等灰重驱动：黑字/AA 不再每 10 页被无意义地擦写 24–31 帧（过驱动累积残余电荷的来源之一），白底那 1 帧白推本来也清不掉任何东西。
2. 新增的 48 相全像素 GC16 是**真正的复位**：白底等灰对 35 帧完整擦写，能把白底残留的上一屏黑字/图案擦掉，并释放残余电荷。最高 10 分钟（或 30 次页级输出）就会出现一次，堵住 R1–R3 的“长时间无真 GC16”缺口：主页停留/阅读慢速翻页都有兜底。
3. 与页面层清理联动归零，避免“连续两次 GC16 闪屏”的新问题；页面层仍可做更及时的主页进入/阅读 10 页清理（ghost-pages/Lead 负责），显示层只做低频兜底。
4. `reader_full_rect` 级别的清理仍在页面层可配（15→10 页等，Lead 决定）；本层不再引入任何 GL16 过驱动路径。

### 4.5 是否可能重新引入「淡墨」

- 1.15.22 的淡墨修复真正生效的是**深→浅首帧擦白复位**（保留）和**静置防泛白**（保留）；活动期 GL16 重推对白底只有 1 帧白推，从来不是有效防淡墨手段，去掉它不会显著增加淡墨风险。
- 新真 GC16 清理比 GL16 重推强得多：每 ≤10 分钟（或 30 次页级输出）一次完整 48 相复位，本身就能抑制电荷泄漏型“白底发灰”。
- 残余风险场景：用户把阅读周期清理设为“关闭”（`full_pages=0`）且长时间高频操作、10 分钟内输出很多；此时显示层会在 30 次页级输出时清理，仍有兜底。若真机仍见淡墨，可把 `DISPLAY_LIGHT_CLEANUP_INTERVAL_MS` 调小（如 300000）而**不要**恢复活动期 GL16 重推。

## 5. 逐文件改动

| 文件 | 改动 |
| --- | --- |
| `main/display.h` | 重写浅色维护宏区：新增 `DISPLAY_LIGHT_ACTIVITY_ENABLE`（默认 0）；新增 `DISPLAY_LIGHT_CLEANUP_ENABLE/PAGE_EVERY/INTERVAL_MS/DEEP`（默认 1/30/600000/0）。宏注释中英双语，含数值依据、触发规则、归零规则、回滚方式。无函数原型变更。 |
| `main/display.c` | ① 新增 `s_light_cleanup_page_ops / s_light_cleanup_last_ms / s_light_cleanup_activity_seen / s_light_cleanup_last_output_ms`；② 新增 `display_light_maintenance_reset()`、`display_light_gc16_cleanup_unlocked()`、`display_light_maintenance_tick_unlocked()`；③ 所有浅色维护 tick 调用点由 `display_light_activity_tick_unlocked` 改为 `display_light_maintenance_tick_unlocked`（12 处出口：mode/mode_diff/fast_page/with/area_with/area_diff/area_full/water/water_hd/main_turn/text_turn 等）；④ 所有“真复位”出口的 `display_light_activity_reset()` 改为 `display_light_maintenance_reset()`（display_set_inverted、from_white、full、image_gray、white_reset、欠载恢复、面板修复）；⑤ 活动期旧函数保留并标注默认停用；⑥ `update_display_anti_fade()` 仍只重置活动期计数（防泛白不是真清理），行为不变。反色分支零逻辑改动。 |
| `docs/analysis/11523_issue_ghost_display.md` | 本文。 |

未改任何其它源文件；`components/e0470_epaper_waveform/waveforms/*.h`、`SY7636A`、`fallback.h`、`stb_truetype.h` 未触碰；`display_main_waveform.c` 未改（其 `display_aa_repair_waveform()` 保留给回滚，调用点补丁见 §7）。

## 6. 验证

- 单文件语法检查（项目真实编译参数 + `-fsyntax-only`）：
  ```
  cd C:\dshb\src2\read-pico-reader-0.3.3-rc99
  C:\dshb\pyenv-idf\Scripts\python.exe C:\dshb\syntax_check.py main/display.c
  → syntax check: ...\main\display.c
  → exit: 0
  ```
- 静态自检：`display.h` 宏在 `display.c` 内成对出现（`grep DISPLAY_LIGHT_CLEANUP_`）；`epd_hl_update_screen_full/from_white`、`epd_clear`、`epd_hl_waveform` 均为既有 API（`components/epdiy`），无新增依赖/内存分配。
- **未做**：`idf.py build`、validate、真机验证（按任务纪律，构建由 Lead 统一做；本文不声称任何实屏结果）。

## 7. 需 Lead 应用的 `app_book.c` 补丁（AA 修复定稿 → 差分）

原因：`display_aa_repair_waveform()` 全像素定稿只驱动等灰中灰 1..14（25–31 帧/档、整幅读者区、每次面板层切换），纯黑/纯白保持，清不了白底黑字残影，只反复过驱动抗锯齿边（§2.5）。AA 根因已在字体层修复（task-2）。改为普通差分 GL16（与默认 READING 分支一致）：

- 定位串（唯一，`main/apps/app_book.c` 约 6466–6474 行）：

```c
    else if (s_view == READING && reader_panel_layer_changed) {
        // 面板层切换用 AA 修复表做一次全像素定稿：中灰等灰对被重驱动（恢复抗锯齿边），
        // 纯黑/纯白保持（不会短暂擦白/变淡），非等灰对按原 GL16 驱动。面板内部层级切换仍走
        // 差分以控制时延；这里只覆盖「正文 ↔ 工具栏/sheet」这一层。
        // The panel-layer transition runs one full-pixel settle with the AA-repair table: equal-pair
        // mid-grays are re-driven (antialiased edges recover), pure black/white hold (no wipe/fade),
        // non-equal pairs follow the original GL16. Sheet-internal level changes stay differential.
        err = update_display_area_full_with(ctx->hl, display_aa_repair_waveform(), MODE_GL16,
                                            reader_full_rect());
    } else err = s_view == READING
```

- 替换为：

```c
    else if (s_view == READING && reader_panel_layer_changed) {
        // 1.15.23：面板层切换改回差分 GL16。1.15.22 的 AA 修复表全像素定稿会把整幅读者区的
        // 抗锯齿中灰（等灰对 1..14）各擦白再压黑 25–31 帧，纯黑/纯白保持，既清不掉白底黑字
        // 残影（残影来源），又是纯过驱动（加重残影）；AA 根因已在字体层修复。
        // 1.15.23: panel-layer transitions return to differential GL16. The 1.15.22 full-pixel
        // AA-repair settle re-drove every antialiased mid-gray (equal pairs 1..14, 25-31 frames
        // each) over the whole reader area while holding pure black/white: it cannot clear
        // white-ground residue and is pure overdrive; the AA root cause was fixed in the font layer.
        err = update_display_area_diff_with(ctx->hl, display_main_normal_waveform(), MODE_GL16,
                                            reader_full_rect());
    } else err = s_view == READING
```

- 说明：`display_aa_repair_waveform()`（`display_main_waveform.c`）保留不删，作为回滚/对照；如需彻底移除，另开任务（该文件不在本任务写权限内，且仅少 2.4 KiB 静态数据）。

**另一个建议（页面层，供 Lead/ghost-pages 决定，不在本任务实现）**：阅读周期真 GC16 默认 15 页对水波纹高清偏稀，建议 Lead 在 app_book.c 把 `app_settings_reader_full_pages` 默认/选项中下调（如 10 页），并保留显示层 10 分钟/30 页级兜底；两处都归零到同一显示层计数器，不会叠加双闪（`update_display_area_full_with` 的页级 GC16 会归零）。

## 8. 风险与回滚

| 风险 | 说明 | 缓解/回滚 |
| --- | --- | --- |
| 每 10 分钟/30 次页级输出一次整屏 GC16 闪（≈0.5 s） | 频率保守但仍是可见整屏刷新；主页停留会触发 | `DISPLAY_LIGHT_CLEANUP_ENABLE=0` 一键停用；`INTERVAL_MS=0` 只留页级计数；`PAGE_EVERY=0` 只留计时；调大阈值降低频率 |
| 清理时机落在一次操作之后 | 与 1.15.22 重推一样是在输出成功后的同一次 present 内追加；页面层清理归零可避免叠加 | 归零规则 + 阈值可调 |
| 48 相 FULL 表 GC16 比裁剪表慢 ~0.5 s | 单次清理耗时 | 这是“真正复位”的固有代价；`DEEP=0` 默认不做 epd_clear |
| 全局整屏清理包含底栏 | 底栏也被重写（内容不变） | 底栏内容就在 front 里，GC16 重写相同内容；如担心，可后续改为内容区（需页面层给 `UI_NAV_REFRESH_END` 区域，本层可扩宏） |
| 与页面层清理叠加 | 已归零规避 | 任何页级 full-pixel GC16 成功后显示层计数清零 |
| 反色/深色回归 | 本层路径在 inverted 时提前返回；无逐页压黑/GC16 改动 | 代码审查 + 真机深色回归项 |
| 清理失败 | 只影响本次清理，主输出已成功 | 记日志 + 置 `s_full_refresh_requested` 下一帧整屏重画 |

## 9. 真机待验清单（必须实测，本文未验证）

1. **阅读（水波纹高清 effect 3）**：连续翻页 10–20 页，白底是否仍有上一屏黑字残留；第 10/15 页真 GC16 后是否全清；若 10 分钟内翻页少，检查 10 分钟兜底清理是否触发（日志 `light GC16 cleanup ok`）。
2. **主页**：从阅读返回后白底黑字残影是否消失；主页静止 10–11 分钟后是否出现一次整屏 GC16 清理（日志）；与 ghost-pages 的主页进入清理是否叠加（预期不叠加）。
3. **频率主观感受**：整屏 GC16 闪是否可接受；必要时调 `DISPLAY_LIGHT_CLEANUP_INTERVAL_MS/PAGE_EVERY`。
4. **淡墨回归**：浅色模式连续使用 30 分钟以上（阅读+主页混合），检查白底是否重新发灰/发淡（对比 1.15.22）；若出现淡墨，优先调小清理间隔而不是恢复 GL16 重推。
5. **深色模式回归**：进出深色、深色阅读翻页/压黑、深→浅首帧擦白、反色全刷契约（逐页压黑/GC16）均不应变化。
6. **性能**：清理时的额外耗时（~0.5–1.5 s）是否造成明显卡顿/按键丢失；`light GC16 cleanup failed` 是否出现。
7. **A/B 回滚**：`DISPLAY_LIGHT_ACTIVITY_ENABLE=1` + `DISPLAY_LIGHT_CLEANUP_ENABLE=0` 复现 1.15.22 行为对照。
8. **AA 修复补丁回归**：开关阅读工具栏/二级 sheet 后正文 AA 边是否正常（不依赖显示层全像素定稿）；若有硬边回归，说明字体层修复不足，需回滚 §7 补丁。

## 10. 附录：关键数值复现

```text
裁剪 GL16（37 相，E0470_WAVEFORM）等灰对：
  15→15: drive=1  (1 白推)
  0→0  : drive=24 (11 擦白 + 13 压黑)
  8→8  : drive=28 (15 擦 + 13 压)
  14→14: drive=31 (18 擦 + 13 压)
  16 个等灰对合计 419 帧（平均 26.2 帧/像素，占 37 相的 70.8%）

裁剪 GC16（36 相，每 5 次升级用）等灰对：15→15=28、0→0=23、8→8=27
完整 48 相 GC16（E0470_FULL_WAVEFORM，真复位用）：15→15=35、0→0=35、8→8=35
AA 修复表等灰对：0→0 / 15→15 = 0（保持）；1..14 = 25–31 帧

扫描帧：FULL 11 917 µs/帧、FAST 7 010 µs/帧（18MHz pclk 解算）
1.15.22 活动期重推：37 相全像素 ≈ 0.40–0.44 s/次（FULL），每 10 次页级输出一次
新真 GC16 清理：48 相全像素 ≈ 0.47–0.57 s/次（leading-skip 后 ~39 相）
```
