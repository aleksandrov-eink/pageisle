# 页屿 PageIsle 定制版 · 交付汇总（小纸 Pico，系统 1.15.77）

适用设备：RDP-G01-W（ESP32-S3 电子墨水屏，逻辑分辨率 684×1216，横屏 1216×684）。
系统名：**页屿 PageIsle**（对外品牌；固件包名、版本号、分区表仍是上游 0.3.3-rc99，未改动）。
本包是 **页屿系统 1.15.77**（2026-11-14）；**所有代码只做了编译、静态分析与宿主测试，未在真机上运行过**，真机结论以用户反馈为准。

## 一、最终固件

| 项目 | 值 |
|---|---|
| 版本 | 上游应用 0.3.3-rc99（页屿系统 **1.15.77**） |
| 应用镜像大小 | **3,714,016 字节** |
| ota_0 分区余量 | **480,288 字节（约 11.45%）** |
| sha256 | `265720ec6d154f60c9b802252b7233c53c2c250b480773e717a12b3e1c4374ed` |

## 二、1.15.72 → 1.15.77 主要变化

- **蓝牙翻页器兼容（本版核心，智联纵维等 BLE HID 遥控器）**：Legacy 配对失败后自动改用 LE Secure Connections 重试一次并请求身份密钥（IRK/ID）；仍失败则按原逻辑改走明文 HID；扫描列表不再隐藏没有广播名的设备（显示「未命名设备 + 地址尾号」），并提示先让翻页器进入配对模式。
- 可用编译宏 `BLE_PT_SEC_SC_FALLBACK=0` 关闭 SC 重试；其余功能与 1.15.72 相同（分区表 / bootloader / OTA 布局未改；书、设置与阅读记录保留）。

## 三、刷机方式

三种方式任选，推荐第 1 种：

1. **单文件全量刷机（推荐）**：`usb-full-package/Pico-full-flash-1.15.77.bin`（bootloader + 分区表 +
   otadata + 应用合成镜像），一条命令：
   `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.77.bin`
   （16MB flash 约 1–2 分钟；分区表未变，书籍/NVS 设置保留）。
2. **USB 四文件全量包**：`usb-full-package/` 的
   `bootloader.bin / partitions.bin / ota_data_initial.bin / firmware.bin`，按同目录 `flash_args`
   分地址写入：`python -m esptool --chip esp32s3 -p COMx write_flash @flash_args`。
3. **TF 卡升级（预计被拒绝，属正常）**：`firmware/Pico-update.bin` 放 TF 根目录 → 设置 → 升级和恢复 →
   本地升级。因上游应用版本仍是 0.3.3-rc99，设备「同版本检查」会拒绝；请改用方式 1/2。

## 四、本版验收（蓝牙翻页器）

翻页器拨到音量控制或左右翻页模式（指示灯闪烁）→ 设置 →「蓝牙翻页器」→ 打开并扫描，确认能看到设备（有名字或「未命名设备 + 地址尾号」）→ 点连接并观察提示 → 打开书按上/下键（或音量键）翻页 → 断开重连再测一次。若仍失败，请提供复现步骤（模式/是否开 WiFi）、屏幕提示与 115200 串口日志（关键字 `blept:`）。详见 `docs/真机验收清单-1.15.77.md` 与 `docs/改版日志-1.15.77.md`。

## 五、文件清单

```
handover-1.15.77/
├─ firmware/Pico-update.bin              # TF 卡升级镜像（3,714,016 B；同版本检查会拒绝，备用）
├─ usb-full-package/                     # USB 完整刷机包
│  ├─ Pico-full-flash-1.15.77.bin        # 单文件合成刷机镜像（推荐，一条命令刷完）
│  ├─ firmware.bin / bootloader.bin / partitions.bin / ota_data_initial.bin
│  ├─ flash_args / manifest.json / SHA256SUMS.txt
├─ rollback-1.15.71/                     # 离线回退 1.15.71（上一正式版）
│  ├─ Pico-full-flash-1.15.71.bin / Pico-update.bin / 回退说明.txt / SHA256SUMS.txt
├─ rollback-1.15.53/                     # 离线回退 1.15.53（更早正式版）
├─ docs/                                 # 使用说明/变更清单/改版日志与刷机指南/0.81/验收清单/校验
├─ promo-fun/                            # 宣传图（沿用）
├─ README-HANDOVER.md                    # 本文件
└─ GitHub上传指南.md                     # 网页版上传步骤
```

## 六、校验

- `firmware/Pico-update.bin` / `usb-full-package/firmware.bin`：`265720ec6d154f60c9b802252b7233c53c2c250b480773e717a12b3e1c4374ed`
- `usb-full-package/Pico-full-flash-1.15.77.bin`：`6ca0cd0ad52c81e695812554aa5e933c6ae39f38b476fde0a7134a4167553d89`（13,705,216 字节）
- USB 包内 `SHA256SUMS.txt` 覆盖 full-flash、bootloader、firmware、ota_data、partitions。

## 七、回退（重要）

- 回退到 **1.15.71 正式版**：`rollback-1.15.71/Pico-full-flash-1.15.71.bin`
  （13,705,216 字节，sha256 `ac552e5cd8fde665807ee6577514da5b8fc515f8e634ab50924a24507414ecd7`）；
  其单独 TF 镜像为 `rollback-1.15.71/Pico-update.bin`（3,712,976 字节，sha256 `4c98b123…a774c0d`）。
- 回退到 **1.15.53 正式版**：`rollback-1.15.53/Pico-full-flash-1.15.53.bin`；其 TF 镜像为 3,687,280 字节，sha256 `f7fc2253…1ece95bd`。

## 八、已知限制（如实说明）

- 本版**未真机验证**：编译 0 error、warning 与 1.15.71 基线同量（11 条历史遗留、无新增）；竖排修复只做了严格编译检查与静态分析，真机结论以用户反馈为准。
- 网页正式站/内测站与网页刷机 bootloader 沿用线上 `e49feb21…`；本交接包 USB 全量包使用本次全量构建的 `e5be0ad2…`（同源、功能等价；分区表与 OTA 数据一致）。
- TF 本地升级同版本检查可能拒绝，请优先使用单文件全量刷机。

## 九、源码

源码位于开发机的 `read-pico-reader-0.3.3-rc99` 目录；步骤见 `GitHub上传指南.md`。
