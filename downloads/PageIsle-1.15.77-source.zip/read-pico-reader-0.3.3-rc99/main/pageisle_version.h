/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 页屿系统版本：与上游应用版本（0.3.3-rc99）分开递增，用于网页内测/正式通道和更新说明。
 * PageIsle system version: bumped independently of the upstream app version (0.3.3-rc99), used by
 * the beta/stable web channels and the release-notes page.
 *
 * 1.15.77：蓝牙翻页器兼容性 —— Legacy 配对失败后自动改用 LE Secure Connections 重试一次并请求
 * 身份密钥；扫描列表不再隐藏无广播名的设备，并提示先让翻页器进入配对模式（指示灯闪烁）。
 * 1.15.77: page-turner compatibility - after a Legacy pairing failure, retry once with LE Secure
 * Connections and identity keys; the scan list no longer hides devices without an advertised name,
 * and the scan page hints to put the remote into pairing mode (blinking LED).
 */
#pragma once

#define PAGEISLE_SYSTEM_VERSION "1.15.77"
#define PAGEISLE_SYSTEM_DATE "2026-11-14"
