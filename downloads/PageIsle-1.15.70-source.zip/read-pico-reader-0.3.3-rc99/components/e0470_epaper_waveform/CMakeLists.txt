set(kiiko_selected_sources "e0470_epaper_waveform.c" "e0470_waveform_trim.c")
idf_component_register(
    SRCS ${kiiko_selected_sources}
    INCLUDE_DIRS "include"
    PRIV_INCLUDE_DIRS "waveforms"
    REQUIRES epdiy
)

# 流畅性：热点组件同样用 -O3（绘制/抖动/揭页/检索/传输解码都在这里）。
# Smoothness: hot components also build with -O3 (drawing, dithering, page turn, search, transfer).
if(NOT CMAKE_SCRIPT_MODE_FILE)
    component_compile_options(-O3)
endif()
