/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 基于 MindReset Read Pico 官方 E0470 波形与刷新路径实现。
 * Built on the MindReset Read Pico E0470 waveform and refresh path.
 * 错相揭页引擎实现。阅读使用8带/GL16；主页可指定柔和序列和条带数。差分只算一次，每拍只换对应相位的1K LUT。
 * Staggered page-turn engine: reading uses 8 bands / GL16; main pages may supply a soft sequence and band count. Calculate differences once and select per-band 1 KiB phase LUTs on each tick.
 * 用户2026-11-01（对齐上游 rc103）：错相引擎相数上限 40→45，支持 41 相阅读水波纹；保留方向、
 * 11090us 节拍和各自灰阶序列。
 * User 2026-11-01 (aligned with upstream rc103): the staggered engine phase cap rises from 40 to 45
 * so the 41-phase reading ripple fits; direction, 11090 us pacing and independent gray sequences are
 * preserved.
 * 用户修订：普通书架分区在同一帧同步执行柔和/校准序列，不串行刷上下中三块；原阅读及主页水波纹入口保持。
 * User revision: ordinary shelf regions execute soft/calibrated sequences in each shared frame instead of three serial updates; retain reader/main ripple entry points.
 */

#include "e0470_page_turn.h"

#include <stdbool.h>
#include <string.h>

#include "e0470_epaper_waveform.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"

static const char* TAG = "e0470_turn";

#define TURN_DEFAULT_BANDS E0470_TURN_FAST_BANDS
#define TURN_BANDS_MAX 32
// 相数上限 45：阅读水波纹 41 相（37 相文字序列 + 4 相变白）走这里；45 上限与上游 rc103
// 对齐，单相位 LUT 指针数组按 45 项预留，避免后续加相再次调整内存布局。
// Phase cap 45: the 41-phase reading ripple (37 text phases + four changed-white phases) runs
// through this engine; the 45 limit matches upstream rc103 and pre-sizes the per-phase LUT
// pointer array so a future phase bump cannot change the memory layout again.
#define TURN_PHASE_CAP 45
#define TURN_LINE_MAX 2048

static uint8_t (*s_lut)[1024];
static const uint8_t* s_lut_ptr[TURN_PHASE_CAP];
static int s_band0[TURN_BANDS_MAX];
static int s_band1[TURN_BANDS_MAX];
static int8_t s_band_phase[TURN_BANDS_MAX];
static int8_t s_line_phase[TURN_LINE_MAX] DRAM_ATTR;
static const EpdWaveformPhases* s_lut_src;
static int s_lut_n;
static int s_tick_us = E0470_TURN_DEFAULT_TICK_US;

void e0470_page_turn_release(void) {
    heap_caps_free(s_lut);
    s_lut = NULL;
    s_lut_src = NULL;
    s_lut_n = 0;
}

const char* e0470_turn_dir_name(e0470_turn_dir_t dir) {
    switch (dir) {
        case E0470_TURN_LTR: return "ltr";
        case E0470_TURN_RTL: return "rtl";
        case E0470_TURN_TTB: return "ttb";
        case E0470_TURN_BTT: return "btt";
        default: return "?";
    }
}

void e0470_page_turn_set_tick_us(int us) {
    if (us < 0) us = 0;
    s_tick_us = us;
}

int e0470_page_turn_tick_us(void) {
    return s_tick_us;
}

static void clip_rect(EpdRect* r, int w, int h) {
    if (r->x < 0) {
        r->width += r->x;
        r->x = 0;
    }
    if (r->y < 0) {
        r->height += r->y;
        r->y = 0;
    }
    if (r->x + r->width > w) r->width = w - r->x;
    if (r->y + r->height > h) r->height = h - r->y;
}

static EpdRect rotate_to_fb(EpdRect rect) {
    const int pw = epd_width();
    const int ph = epd_height();
    const int lx0 = rect.x;
    const int ly0 = rect.y;
    const int lx1 = rect.x + rect.width - 1;
    const int ly1 = rect.y + rect.height - 1;
    int ax, ay, bx, by;

    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
            ax = lx0;
            ay = ly0;
            bx = lx1;
            by = ly1;
            break;
        case EPD_ROT_PORTRAIT:
            ax = pw - ly0 - 1;
            ay = lx0;
            bx = pw - ly1 - 1;
            by = lx1;
            break;
        case EPD_ROT_INVERTED_LANDSCAPE:
            ax = pw - lx0 - 1;
            ay = ph - ly0 - 1;
            bx = pw - lx1 - 1;
            by = ph - ly1 - 1;
            break;
        default:
            ax = ly0;
            ay = ph - lx0 - 1;
            bx = ly1;
            by = ph - lx1 - 1;
            break;
    }

    const int x0 = ax < bx ? ax : bx;
    const int x1 = ax < bx ? bx : ax;
    const int y0 = ay < by ? ay : by;
    const int y1 = ay < by ? by : ay;
    return (EpdRect){ .x = x0, .y = y0, .width = x1 - x0 + 1, .height = y1 - y0 + 1 };
}

static void phys_to_logical(int px, int py, int* lx, int* ly) {
    const int pw = epd_width();
    const int ph = epd_height();
    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
            *lx = px;
            *ly = py;
            break;
        case EPD_ROT_PORTRAIT:
            *lx = py;
            *ly = pw - px - 1;
            break;
        case EPD_ROT_INVERTED_LANDSCAPE:
            *lx = pw - px - 1;
            *ly = ph - py - 1;
            break;
        default:
            *lx = ph - py - 1;
            *ly = px;
            break;
    }
}

static bool dir_is_lr(e0470_turn_dir_t dir) {
    return dir == E0470_TURN_LTR || dir == E0470_TURN_RTL;
}

static bool dir_is_reverse(e0470_turn_dir_t dir) {
    return dir == E0470_TURN_RTL || dir == E0470_TURN_BTT;
}

// 错相轴若落在物理 y 上，整行共用一个相位；落在物理 x 上则一行内分段。
// If the stagger axis is physical y, a whole line shares one phase; physical x needs column bands.
static bool uses_line_phase(e0470_turn_dir_t dir) {
    const bool lr = dir_is_lr(dir);
    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
        case EPD_ROT_INVERTED_LANDSCAPE:
            return !lr;
        default:
            return lr;
    }
}

static int band_of(int coord, int origin, int span, int bands, bool reverse) {
    int band = (coord - origin) * bands / span;
    if (band < 0) band = 0;
    if (band >= bands) band = bands - 1;
    return reverse ? bands - 1 - band : band;
}

static void clear_bands(int* b0, int* b1, int n) {
    for (int i = 0; i < n; i++) {
        b0[i] = 0;
        b1[i] = 0;
    }
}

static void assign_bands(
    int* b0,
    int* b1,
    int bands,
    int from,
    int to,
    int step,
    bool along_x,
    int origin,
    int span,
    bool lr,
    bool reverse
) {
    clear_bands(b0, b1, bands);
    int cur = -1;
    int run = from;
    for (int p = from; p < to; p += step) {
        int lx, ly;
        if (along_x) phys_to_logical(p, 0, &lx, &ly);
        else phys_to_logical(0, p, &lx, &ly);
        const int coord = lr ? lx : ly;
        const int band = band_of(coord, origin, span, bands, reverse);
        if (band != cur) {
            if (cur >= 0) {
                b0[cur] = run;
                b1[cur] = p;
            }
            cur = band;
            run = p;
        }
    }
    if (cur >= 0) {
        b0[cur] = run;
        b1[cur] = to;
    }
}

static bool build_luts(const EpdWaveformPhases* gl) {
    // 最多 45 相（45 KiB）相位表按需放入 PSRAM；避免长期占用 WiFi 和 USB 需要的内部内存。
    // Allocate at most 45 phases (45 KiB) of phase LUTs in PSRAM on demand, preserving internal
    // RAM for WiFi and USB.
    if (!s_lut) {
        s_lut = heap_caps_aligned_alloc(16, sizeof(uint8_t[TURN_PHASE_CAP][1024]),
                                        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!s_lut) return false;
    }
    if (s_lut_src == gl && s_lut_n == gl->phases) return true;
    const int n = gl->phases < TURN_PHASE_CAP ? gl->phases : TURN_PHASE_CAP;
    for (int phase = 0; phase < n; phase++) {
        epd_build_1ppB_lut_1k(s_lut[phase], gl, phase);
        // 反色下的深色等灰对由 epd_build_1ppB_lut_1k 统一保持（0 动作），引擎不再二次改写。
        // 旧实现在字节下标上清零：1024 字节 = 256 个 32bit 表项，实际只清掉 0/17/34/51 四个表项
        // （逻辑 0–3 等灰对），既没挡住深色背景的白闪，又误伤了白字的等灰保持。
        // Inverted dark equal pairs are held centrally by epd_build_1ppB_lut_1k; the engine no longer
        // rewrites them. The old byte-index loop cleared only entries 0/17/34/51 (logical 0-3 equal
        // pairs): it never stopped the dark-ground flash and wrongly dropped white-glyph holds.
        s_lut_ptr[phase] = s_lut[phase];
    }
    s_lut_src = gl;
    s_lut_n = gl->phases;
    return true;
}

static void copy_front_to_back(EpdiyHighlevelState* hl, EpdRect phys) {
    const int w = epd_width();
    const int h = epd_height();
    clip_rect(&phys, w, h);
    if (phys.width <= 0 || phys.height <= 0) return;

    for (int y = phys.y; y < phys.y + phys.height; y++) {
        uint8_t* src = hl->front_fb + y * w / 2;
        uint8_t* dst = hl->back_fb + y * w / 2;
        int x = phys.x;
        int x_last = phys.x + phys.width - 1;
        if (x & 1) {
            dst[x / 2] = (uint8_t)((src[x / 2] & 0xF0) | (dst[x / 2] & 0x0F));
            x++;
        }
        if ((x_last & 1) == 0) {
            dst[x_last / 2] = (uint8_t)((src[x_last / 2] & 0x0F) | (dst[x_last / 2] & 0xF0));
            x_last--;
        }
        if (x_last >= x) memcpy(dst + x / 2, src + x / 2, (size_t)((x_last - x + 1) / 2));
    }
}

static enum EpdDrawError page_turn_run(EpdiyHighlevelState* hl, EpdRect area,
    e0470_turn_dir_t dir, const EpdWaveform* waveform, unsigned band_count, bool compact,
    bool commit_baseline) {
    if (hl == NULL) return EPD_DRAW_NO_PHASES_AVAILABLE;
    if (band_count < (compact ? 1u : 2u) || band_count > TURN_BANDS_MAX) return EPD_DRAW_INVALID_CROP;
    if (dir > E0470_TURN_BTT) dir = E0470_TURN_RTL;

    const EpdWaveformPhases* gl = e0470_waveform_phases(waveform, MODE_GL16);
    if (gl == NULL || gl->luts == NULL || gl->phases <= 0 || gl->phases > TURN_PHASE_CAP || gl->phase_times) {
        return EPD_DRAW_NO_PHASES_AVAILABLE;
    }

    const int bands = (int)band_count;
    const int nphase = gl->phases;
    // 紧凑模式供阅读和快速主页共用；仅提前后续条带的启动，不跳过每个像素的任何相位。
    // Reading and fast main pages share compact launches; start later bands sooner without skipping any pixel phase.
    const int launch_step = compact ? 1 : (nphase + bands - 2) / (bands - 1);
    const int ticks = (bands - 1) * launch_step + nphase;
    const int fb_w = epd_width();
    const int fb_h = epd_height();
    if (fb_h > TURN_LINE_MAX) return EPD_DRAW_INVALID_CROP;

    EpdRect phys = rotate_to_fb(area);
    clip_rect(&phys, fb_w, fb_h);
    if (phys.width <= 0 || phys.height <= 0) return EPD_DRAW_SUCCESS;

    const int y0 = phys.y;
    const int y1 = phys.y + phys.height;
    const bool lr = dir_is_lr(dir);
    const bool reverse = dir_is_reverse(dir);
    const bool line_ph = uses_line_phase(dir);
    const int origin = lr ? area.x : area.y;
    const int span = lr ? (area.width > 0 ? area.width : 1) : (area.height > 0 ? area.height : 1);

    if (line_ph) {
        assign_bands(
            s_band0, s_band1, bands, y0, y1, 1, false, origin, span, lr, reverse
        );
    } else {
        const int x_lo = (phys.x + 15) & ~15;
        const int x_hi = (phys.x + phys.width) & ~15;
        assign_bands(
            s_band0, s_band1, bands, x_lo, x_hi, 16, true, origin, span, lr, reverse
        );
    }
    int assigned = 0;
    for (int band = 0; band < bands; ++band) assigned += s_band0[band] < s_band1[band];
    if (assigned != bands) return EPD_DRAW_INVALID_CROP;

    if (!build_luts(gl)) return EPD_DRAW_NO_PHASES_AVAILABLE;
    epd_poweron();

    const int64_t t_all = esp_timer_get_time();
    const int64_t t_gen = esp_timer_get_time();
    epd_difference_image_cropped(
        hl->front_fb, hl->back_fb, phys, hl->difference_fb, hl->dirty_lines, hl->dirty_columns
    );
    const int64_t gen_us = esp_timer_get_time() - t_gen;

    int64_t draw_us = 0;
    enum EpdDrawError err = EPD_DRAW_SUCCESS;
    for (int tick = 0; tick < ticks; tick++) {
        const int64_t t_tick = esp_timer_get_time();
        memset(hl->dirty_lines, 0, sizeof(bool) * (size_t)fb_h);
        memset(hl->dirty_columns, 0, (size_t)fb_w / 2);
        memset(s_band_phase, -1, (size_t)bands);
        if (line_ph) memset(s_line_phase, -1, (size_t)fb_h);

        bool any = false;
        for (int band = 0; band < bands; band++) {
            const int phase = tick - band * launch_step;
            if (phase < 0 || phase >= nphase) continue;
            const int a = s_band0[band];
            const int b = s_band1[band];
            if (a >= b) continue;
            s_band_phase[band] = (int8_t)phase;
            if (line_ph) {
                memset(hl->dirty_lines + a, 1, (size_t)(b - a));
                memset(s_line_phase + a, (int)(int8_t)phase, (size_t)(b - a));
            } else {
                memset(hl->dirty_columns + a / 2, 0xFF, (size_t)((b - a) / 2));
            }
            any = true;
        }
        if (!any) continue;

        if (line_ph) {
            int xs = phys.x & ~1;
            int xe = (phys.x + phys.width + 1) & ~1;
            if (xe > xs) {
                memset(hl->dirty_columns + xs / 2, 0xFF, (size_t)((xe - xs) / 2));
            }
            epd_set_line_phase_luts(s_lut_ptr, s_line_phase);
        } else {
            memset(hl->dirty_lines + y0, 1, (size_t)(y1 - y0));
            epd_set_col_phase_luts(s_lut_ptr, s_band0, s_band1, s_band_phase, bands);
        }

        const int64_t t_draw = esp_timer_get_time();
        err = epd_draw_base(
            epd_full_screen(),
            hl->difference_fb,
            epd_full_screen(),
            MODE_PACKING_1PPB_DIFFERENCE | MODE_DU,
            25,
            hl->dirty_lines,
            hl->dirty_columns,
            &E0470_APPLY_WAVEFORM
        );
        epd_clear_phase_luts();
        draw_us += esp_timer_get_time() - t_draw;
        if (err != EPD_DRAW_SUCCESS) break;
        const int64_t used = esp_timer_get_time() - t_tick;
        if (s_tick_us > 0 && used < s_tick_us) {
            esp_rom_delay_us((uint32_t)(s_tick_us - used));
        }
    }

    // 扫描失败时屏幕可能停在中间相位，保留旧帧基准给调用方恢复。
    // A failed scan may leave intermediate pixels; keep the old baseline for caller recovery.
    // 高清水波纹不提交基准：随后用校准灰阶表再驱动一遍，才能恢复抗锯齿中间灰。
    // HD ripple skips the baseline commit: the calibrated gray pass that follows needs the old
    // front frame to compute the real difference.
    if (err == EPD_DRAW_SUCCESS && commit_baseline) copy_front_to_back(hl, phys);
    ESP_LOGI(
        TAG,
        "dir=%s ticks=%d gen=%d ms draw=%d ms scan_avg=%d us wall=%d ms err=%d",
        e0470_turn_dir_name(dir),
        ticks,
        (int)(gen_us / 1000),
        (int)(draw_us / 1000),
        ticks ? (int)(draw_us / ticks) : 0,
        (int)((esp_timer_get_time() - t_all) / 1000),
        (int)err
    );
    return err;
}

enum EpdDrawError e0470_page_turn(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir) {
    return page_turn_run(hl, area, dir, &E0470_WAVEFORM, TURN_DEFAULT_BANDS, true, true);
}

enum EpdDrawError e0470_page_turn_with_waveform(EpdiyHighlevelState* hl, EpdRect area,
    e0470_turn_dir_t dir, const EpdWaveform* waveform, unsigned band_count) {
    return page_turn_run(hl, area, dir, waveform, band_count, false, true);
}

enum EpdDrawError e0470_page_turn_with_waveform_compact(EpdiyHighlevelState* hl, EpdRect area,
    e0470_turn_dir_t dir, const EpdWaveform* waveform, unsigned band_count) {
    return page_turn_run(hl, area, dir, waveform, band_count, true, true);
}

enum EpdDrawError e0470_page_turn_with_waveform_compact_commit(
    EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir,
    const EpdWaveform* waveform, unsigned band_count, bool commit_baseline) {
    return page_turn_run(hl, area, dir, waveform, band_count, true, commit_baseline);
}

enum EpdDrawError e0470_update_regions(EpdiyHighlevelState* hl, EpdRect area,
    EpdRect strong_area, const EpdWaveform* soft_waveform,
    const EpdWaveform* strong_waveform, enum EpdDrawMode strong_mode) {
    const int w = epd_width(), h = epd_height();
    if (!hl || !hl->front_fb || !hl->back_fb || !hl->difference_fb ||
        !hl->dirty_lines || !hl->dirty_columns) return EPD_DRAW_NO_PHASES_AVAILABLE;
    if (epd_get_rotation() != EPD_ROT_INVERTED_PORTRAIT || area.x || area.width != h ||
        area.y < 0 || area.height <= 0 || area.y > w || area.height > w - area.y ||
        (area.y & 31) || (area.height & 31) || strong_area.x || strong_area.width != h ||
        strong_area.y < area.y || strong_area.height <= 0 || strong_area.y > area.y + area.height ||
        strong_area.height > area.y + area.height - strong_area.y ||
        (strong_area.y & 31) || (strong_area.height & 31)) return EPD_DRAW_INVALID_CROP;
    if (strong_mode != MODE_GL16 && strong_mode != MODE_GC16) return EPD_DRAW_NO_PHASES_AVAILABLE;
    const EpdWaveformPhases* soft = e0470_waveform_phases(soft_waveform, MODE_GL16);
    const EpdWaveformPhases* strong = e0470_waveform_phases(strong_waveform, strong_mode);
    if (!soft || !strong || !soft->luts || !strong->luts ||
        soft->phases <= 0 || strong->phases <= 0 || soft->phases > TURN_PHASE_CAP ||
        strong->phases > TURN_PHASE_CAP || soft->phase_times || strong->phase_times)
        return EPD_DRAW_NO_PHASES_AVAILABLE;
    // 只保留当前相位的两张1K表，下一相开始前上一帧的生产者/扫描均已结束。
    // Keep only two current 1 KiB LUTs; producers/scanning finish before the next phase overwrites them.
    uint8_t (*luts)[1024] = heap_caps_aligned_alloc(16, 2048, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!luts) return EPD_DRAW_NO_PHASES_AVAILABLE;
    const uint8_t* lut_ptrs[] = {luts[0], luts[1]};
    const int starts[] = {area.y, strong_area.y, strong_area.y + strong_area.height};
    const int ends[] = {strong_area.y, strong_area.y + strong_area.height, area.y + area.height};
    const EpdRect phys = rotate_to_fb(area);
    epd_difference_image_cropped(hl->front_fb, hl->back_fb, phys, hl->difference_fb,
                                  hl->dirty_lines, hl->dirty_columns);
    // 校准区包含等灰像素；外侧等灰是否保持由原柔和表决定，不伪造前一帧。
    // Include equal grays for art calibration; the original soft table holds equal chrome without falsifying the prior frame.
    memset(hl->dirty_lines, 1, (size_t)h * sizeof(bool));
    memset(hl->dirty_columns, 0, (size_t)w / 2);
    memset(hl->dirty_columns + area.y / 2, 0xff, (size_t)area.height / 2);
    const int phases = soft->phases > strong->phases ? soft->phases : strong->phases;
    epd_poweron();
    enum EpdDrawError error = EPD_DRAW_SUCCESS;
    for (int phase = 0; phase < phases; ++phase) {
        if (phase < soft->phases) epd_build_1ppB_lut_1k(luts[0], soft, phase);
        else memset(luts[0], 0, 1024);
        if (phase < strong->phases) epd_build_1ppB_lut_1k(luts[1], strong, phase);
        else memset(luts[1], 0, 1024);
        const int8_t selected[] = {0, 1, 0};
        epd_set_col_phase_luts(lut_ptrs, starts, ends, selected, 3);
        error = epd_draw_base(epd_full_screen(), hl->difference_fb, epd_full_screen(),
            MODE_PACKING_1PPB_DIFFERENCE | MODE_DU, 25,
            hl->dirty_lines, hl->dirty_columns, &E0470_APPLY_WAVEFORM);
        epd_clear_phase_luts();
        if (error != EPD_DRAW_SUCCESS) break;
    }
    heap_caps_free(luts);
    if (error == EPD_DRAW_SUCCESS) copy_front_to_back(hl, phys);
    return error;
}
