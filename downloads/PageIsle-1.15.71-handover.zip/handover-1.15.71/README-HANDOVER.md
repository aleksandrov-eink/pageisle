# 页屿 PageIsle 定制版 · 交付汇总（小纸 Pico，系统 1.15.71）

适用设备：RDP-G01-W（ESP32-S3 电子墨水屏，逻辑分辨率 684×1216，横屏 1216×684）。
系统名：**页屿 PageIsle**（对外品牌；固件包名、版本号、分区表仍是上游 0.3.3-rc99，未改动）。
本包是 **页屿系统 1.15.71**（2026-11-13）；**所有代码只做了编译、静态分析与宿主测试，未在真机上运行过**，真机结论以用户反馈为准。

## 一、最终固件

| 项目 | 值 |
|---|---|
| 版本 | 上游应用 0.3.3-rc99（页屿系统 **1.15.71**） |
| 应用镜像大小 | **3,712,976 字节** |
| ota_0 分区余量 | **481,328 字节（约 11.48%）** |
| sha256 | `4c98b123ee22bd362248337bf7726a73006fc6afa5259e0842e14c480a774c0d` |

## 二、1.15.70 → 1.15.71 主要变化

- **蓝牙翻页器连接修复（本版核心）**：修复标准 BLE HID 翻页器“能配对但连不上/连上无按键”的问题：
  自动清理过期配对缓存后重试；连接参数协商失败时回退明文 HID；设置页区分“已配对/已连接/失败”状态；
  增加 `blept:` 诊断日志（`sec initiate`、`sec fallback plaintext`、`link encrypted`、`notify len`、`step fail`）。
- **1.15.70 文字残影低闪微调保留**（每页纯白像素补推 + 翻页表黑→白补白相；未新增整屏闪烁）。
- 其余与 1.15.70 相同（分区表 / bootloader / OTA 布局未改；书、设置与阅读记录保留）。

## 三、刷机方式

三种方式任选，推荐第 1 种：

1. **单文件全量刷机（推荐）**：`usb-full-package/Pico-full-flash-1.15.71.bin`（bootloader + 分区表 +
   otadata + 应用合成镜像），一条命令：
   `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.71.bin`
   （16MB flash 约 1–2 分钟；分区表未变，书籍/NVS 设置保留）。
2. **USB 四文件全量包**：`usb-full-package/` 的
   `bootloader.bin / partitions.bin / ota_data_initial.bin / firmware.bin`，按同目录 `flash_args`
   分地址写入：`python -m esptool --chip esp32s3 -p COMx write_flash @flash_args`。
3. **TF 卡升级（预计被拒绝，属正常）**：`firmware/Pico-update.bin` 放 TF 根目录 → 设置 → 升级和恢复 →
   本地升级。因上游应用版本仍是 0.3.3-rc99，设备「同版本检查」会提示「升级包与当前版本相同」并拒绝，
   这是固件既有逻辑，不是包损坏；请改用方式 1/2。
4. 分区表和 bootloader 未改动；升级不会清空书籍、设置与阅读记录。

## 四、本版详细说明（蓝牙翻页器验收）

设置 →「蓝牙翻页器」开启；建议先删除设备里旧的翻页器记录，再重新扫描/连接；阅读页按 PageUp/PageDown、
方向键、空格/回车、音量 +/−、上一曲/下一曲等测试，按一次应翻一页。
失败时设置页会显示「蓝牙：<原因>」，并可在 115200 串口抓 `blept:` 日志；重点看：
`sec initiate ... rc=`、`sec fallback plaintext attempt=1`、`link encrypted ... bonded=`、
`notify len=...`、`step fail`。

详细步骤与日志判读见 `docs/真机验收清单-1.15.71.md`、`docs/改版日志-1.15.71.md`
与 `docs/蓝牙翻页器验收卡.md`。

已知限制：仅支持 BLE，纯 Classic 蓝牙翻页器连不上（S3 硬件限制）；冷启动后需在设置里点一下
已配对设备或顶部快捷层蓝牙圆钮重连。

## 五、文件清单

```
handover-1.15.71/
├─ firmware/Pico-update.bin              # TF 卡升级镜像（3,712,976 B；同版本检查会拒绝，备用）
├─ usb-full-package/                     # USB 完整刷机包
│  ├─ Pico-full-flash-1.15.71.bin        # 单文件合成刷机镜像（推荐，一条命令刷完）
│  ├─ firmware.bin / bootloader.bin / partitions.bin / ota_data_initial.bin
│  ├─ flash_args / manifest.json
│  ├─ 改版日志与刷机指南.md / 使用说明.txt
│  └─ SHA256SUMS.txt
├─ rollback-1.15.70/                     # 离线回退 1.15.70（上一正式版）
│  ├─ Pico-full-flash-1.15.70.bin        # 单文件合成刷机镜像（推荐）
│  ├─ Pico-update.bin                    # 3,707,056 B / 5e374698a3c78618098102a0d28f7ab3a9e2293611d118b7b9b97e49cf412473
│  ├─ 回退说明.txt / SHA256SUMS.txt
├─ rollback-1.15.53/                     # 离线回退 1.15.53（更早正式版）
│  ├─ Pico-full-flash-1.15.53.bin
│  ├─ Pico-update.bin                    # 3,687,280 B / f7fc…95bd
│  ├─ 回退说明.txt / SHA256SUMS.txt
├─ docs/                                 # 同一套文档副本 + 校验和 + 真机验收清单 + 蓝牙验收卡 + 证据
├─ promo-fun/                            # 宣传图（沿用）
├─ README-HANDOVER.md                    # 本文件
└─ GitHub上传指南.md                     # 网页版上传步骤
```

## 六、校验

- `firmware/Pico-update.bin` / `usb-full-package/firmware.bin`：`4c98b123ee22bd362248337bf7726a73006fc6afa5259e0842e14c480a774c0d`
- `usb-full-package/Pico-full-flash-1.15.71.bin`：`ac552e5cd8fde665807ee6577514da5b8fc515f8e634ab50924a24507414ecd7`（13,705,216 字节）
- USB 包内 `SHA256SUMS.txt` 覆盖 full-flash、`bootloader.bin`、`firmware.bin`、`ota_data_initial.bin`、`partitions.bin`；
  升级前可自行核对。

## 七、回退（重要）

- 回退到 **1.15.70 正式版**（上一版，推荐用单文件）：`rollback-1.15.70/Pico-full-flash-1.15.70.bin`
  `python -m esptool --chip esp32s3 -p COMx write_flash 0x0 Pico-full-flash-1.15.70.bin`；
  其单独 TF 镜像为 `rollback-1.15.70/Pico-update.bin`（3,707,056 字节，
  sha256 `5e374698a3c78618098102a0d28f7ab3a9e2293611d118b7b9b97e49cf412473`；TF 内升级同样可能被同版本检查拒绝，请走 USB）。
- 回退到 **1.15.53 正式版**（更早稳定版）：`rollback-1.15.53/Pico-full-flash-1.15.53.bin`；
  其单独 TF 镜像为 `rollback-1.15.53/Pico-update.bin`（3,687,280 字节，
  sha256 `f7fc2253cd8637c8e3ce9334a13f60c6ebfd191c49f5cb4b8dd3f8661ece95bd`）。
- 本版未改分区表/bootloader/OTA 布局，回退只需重刷应用镜像。

## 八、已知限制（如实说明）

- 本版**未真机验证**：编译 0 error、warning 与历史构建同量（11 条历史遗留、无新增）；蓝牙修复只做了
  严格编译检查与静态分析，尚未在真机运行；真机结论以用户反馈为准。
- 蓝牙翻页器：仅 BLE；冷启动不自动连回；`blept:` 诊断日志默认开启。
- 网页正式站与内测站当前均为 1.15.71；网页刷机 bootloader 沿用线上 `e49feb21…`，本交接包 USB
  全量包使用本次全量构建的 `d9cc36…`（同源、功能等价；分区表与 OTA 数据一致）。

## 九、建议的真机复测顺序

1. **P0 蓝牙翻页器**：设置 → 蓝牙翻页器开关 → 删除旧记录 → 重新扫描/连接 → 阅读页按键翻页 →
   断开重连/开关 WiFi 各一次 → 失败回传设备型号、其他系统表现与 115200 `blept:` 日志。
2. **回归**：开机/锁屏/深睡/充电、书架/设置/横竖屏/字体边距重排、WiFi 传书/OTA/云同步、其他翻页档位。

## 十、源码

源码位于开发机的 `read-pico-reader-0.3.3-rc99` 目录；如需上传 GitHub，可直接把整个源码目录
打包（排除 `build/`）作为 Release 附件或仓库内容，步骤见 `GitHub上传指南.md`。
