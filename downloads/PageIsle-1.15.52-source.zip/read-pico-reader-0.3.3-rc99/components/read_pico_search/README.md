# 离线书名匹配 / Offline filename matching

`read_pico_search_match(filename, query)` 无文件访问、无堆分配，可重入。输入是 UTF-8 书名（最多255字节）与查询（最多64字节），不是路径。NULL、超长或非法UTF-8返回false。忽略最后的`.txt`/`.epub`扩展名；空查询及纯ASCII空白查询匹配全部。

The matcher is reentrant, allocation-free and performs no file access. Inputs are UTF-8 filenames (not paths, at most 255 bytes) and queries (at most 64 bytes). NULL, oversized or invalid UTF-8 inputs return false. Final `.txt`/`.epub` extensions are ignored. Empty or ASCII-whitespace-only queries match all.

三个独立匹配通道：原文子串（ASCII忽略大小写）、无声调拼音子串、中英首字母子串。拼音查询可用空格分隔，`v`或`ü`表示ü；英文首字母按ASCII单词边界，数字逐位保留。ASCII分隔符在拼音通道中忽略；未知非ASCII字符中断拼音匹配，但仍能按原文搜索。全拼支持从音节内部开始的子串，首字母和全拼不在同一通道混用。

Three independent channels match literal substrings (ASCII case-insensitive), toneless pinyin substrings and Chinese/English initials. Pinyin queries may have separating whitespace; `v` or `ü` means ü. English initials follow ASCII word boundaries; digits are retained individually. ASCII separators are skipped in pinyin channels. Unknown non-ASCII characters break those channels but remain searchable literally. Full pinyin substrings may begin inside syllables; full pinyin and initials are not mixed in one channel.

逐字尝试全部字典读音，不做分词或上下文消歧。因此重庆可匹配`chongqing`和`zhongqing`。64位状态集合合并多音分支，不生成读音笛卡尔积。字表覆盖41,923字符、4,479读音组合及425音节；`search_table.h` 的表 283,381 字节，IME 反向索引 56,338 字节，合计 339,719 字节——固件里不再整份驻留 Flash，而是压缩成 149,241 字节的 `search_blob.bin`，首次使用时解压到 PSRAM（见下）。

All dictionary readings are considered per character, without segmentation or contextual disambiguation: 重庆 matches both `chongqing` and `zhongqing`. A 64-bit state set merges branches without generating a Cartesian product. The dictionary covers 41,923 characters, 4,479 reading groups and 425 syllables; the `search_table.h` tables take 283,381 bytes and the IME reverse index 56,338 bytes (339,719 bytes total). The firmware no longer keeps that whole block in flash: it stores a 149,241-byte `search_blob.bin` and inflates it into PSRAM on first use (see below).

## 固件体积压缩 / Firmware-size compression

1.15.45 起，设备端不再把 339,719 字节表格编进 `.rodata`，而是嵌入 `search_blob.bin`（149,241 B，zlib-9），首次使用才解压：

Since 1.15.45 the device no longer compiles the 339,719-byte tables into `.rodata`; it embeds `search_blob.bin` (149,241 B, zlib-9) and inflates it on first use:

- 格式 / Format: 80 字节头（magic `PISB`、版本、长度、8 段字节数、整块 CRC32、压缩长度）+ `zlib(payload)`；`payload = delta-varint(codepoints) | raw_tail`，`raw_tail` 是 groups / group_offsets / readings / syllable_offsets / syllables / ime_character_offsets / ime_characters 七段按自然对齐原样排列。解压后重建布局 = `codepoints(u32) | raw_tail`，共 339,722 B。
  Header (80 B: magic `PISB`, version, sizes, 8 section sizes, block CRC32, compressed size) followed by `zlib(payload)`, where `payload = delta-varint(codepoints) | raw_tail` and `raw_tail` holds the seven remaining sections raw with natural alignment. The rebuilt layout is `codepoints(u32) | raw_tail`, 339,722 B total.
- 生成 / Generation: 先按下面的步骤重新生成两个头文件，再执行 `python C:\dshb\work\impl_phase1\gen_search_blob.py`（瘦身阶段工具，默认指向本项目组件目录），脚本会重写 `search_blob.bin` 并自检解压、差分解码、CRC 与逐段比对。After regenerating the two headers below, run `python C:\dshb\work\impl_phase1\gen_search_blob.py` (the slimming-phase helper, defaulting to this component directory). It rewrites `search_blob.bin` and verifies inflate, delta decode, CRC and every section against the headers.
- 主机端 / Host builds: 未定义 `ESP_PLATFORM` 时直接使用 `search_table.h`/`search_candidates.h` 的静态表，`tools/test_search.py` 与 `tools/simulator` 行为不变；这两个头文件仅为宿主测试保留，设备构建不再包含它们。Without `ESP_PLATFORM` the static tables from `search_table.h`/`search_candidates.h` are used directly, so `tools/test_search.py` and `tools/simulator` behave exactly as before. The headers are kept for host tests only; the device build does not include them.
- 懒加载 / Lazy load: 第一次遇到非 ASCII 书名的拼音匹配或第一次调用 IME 接口时才解压（纯 ASCII 查询不触发）。临时 payload 214,011 B + 常驻表 339,722 B 都在 PSRAM，临时块随即释放；PSRAM 空闲低于 1 MiB 或分不到块时直接降级。Inflate happens on the first pinyin match that actually sees a non-ASCII filename, or the first IME call (ASCII-only queries never trigger it). The 214,011-byte payload and the 339,722-byte table block both live in PSRAM; the temporary block is freed immediately. The loader degrades when PSRAM free space is below 1 MiB or a block cannot be allocated.
- 失败回退 / Failure fallback: 分配、解压、头部校验或 CRC 失败时打 `ESP_LOGE("pico_search", "search tables unavailable (...)")`，拼音搜索返回 false、IME 候选返回空、音节枚举返回 NULL，本次运行不再重试——不崩溃、不反复卡在失败路径。只有原文子串匹配仍可用。On allocation/inflate/header/CRC failure it logs `ESP_LOGE("pico_search", "search tables unavailable (...)")`, pinyin matching returns false, IME candidates are empty and syllable enumeration returns NULL; the loader stays disabled for the rest of the session (no crash, no repeated stalls). Literal substring matching keeps working.



## 数据来源与再生成 / Provenance and regeneration

- 官方项目 / Official project: https://github.com/mozillazg/python-pinyin
- 固定版本 / Pinned release: `pypinyin==0.55.0`, official PyPI `pypinyin-0.55.0-py2.py3-none-any.whl`.
- 原始文件 / Source data: `pypinyin/pinyin_dict.json`.
- Wheel SHA-256: `d53b1e8ad2cdb815fb2cb604ed3123372f5a28c6f447571244aca36fc62a286f`.
- 字典采用原项目MIT许可，原文保存在[LICENSE.pypinyin](LICENSE.pypinyin)。匹配器与生成脚本为Apache-2.0。
- Dictionary data retains upstream MIT licensing in [LICENSE.pypinyin](LICENSE.pypinyin). Matcher and generator use Apache-2.0.

```sh
python -m pip download --no-deps pypinyin==0.55.0 -d build/search-deps
python tools/generate_search_table.py build/search-deps/pypinyin-0.55.0-py2.py3-none-any.whl
python tools/test_search.py build/search-deps/pypinyin-0.55.0-py2.py3-none-any.whl
```

生成只使用Python标准库并校验wheel摘要。无需安装或执行第三方包。固件编译直接使用已生成字表，不联网、不依赖Python。

Generation uses only the Python standard library and verifies the wheel digest; it neither installs nor executes third-party packages. Firmware builds use the checked-in table without Python or network access.

## 输入法反向索引 / IME reverse index

`search_candidates.h` 从同一官方字表生成，只为精确拼音候选提供直接查找，支持 `skip` 继续取同音字；保留全部 20,924 个基本汉字、27,317 个读音映射。常用字优先，随后为 GB2312 一级/二级字和其余汉字。书名匹配的多音字规则不变。词组由 `main/ui/ui_ime_phrases.h` 单独维护。

The reverse index provides exact-syllable candidate lookup with `skip` pagination, retaining 20,924 basic Han characters and 27,317 reading mappings. It prefers common glyphs, GB2312 level one/two and then other Han glyphs. Filename matching and its polyphonic rules are unchanged; the separately maintained IME lexicon owns phrases.

```sh
python3 tools/generate_ime_dictionary.py
```

内建字形补充从同一 OFL 黑体生成，字形分块存储；不是外置字体包。需要 FontTools 和 C 编译器才能重新生成，设备运行无需这些工具。
The glyph supplement is generated from the same OFL black face in small blocks, rather than distributing a separate font package. Regeneration needs FontTools and a C compiler; the device does not.

```sh
python3 tools/gen_builtin_font.py
python3 tools/gen_ui_hanzi.py
python3 tools/ui_hanzi_host_test.py
```
