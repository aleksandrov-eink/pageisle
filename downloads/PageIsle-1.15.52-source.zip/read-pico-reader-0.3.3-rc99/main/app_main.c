/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 用户修订：硬件前建立持久化启动保护；深睡恢复入口先消费再开书，中断图书进入可操作恢复页。
 * User revision: persist startup protection before hardware; consume deep-sleep checkpoints before opening books, and show an operable recovery page after interrupted opening.
 * 只做开机装配：拉起板级硬件、读设置、定 VCOM、放开机图、开字体；
 * 未标定则先拦住进设定页。然后把控制权交给 app_loop。
 *
 * Boot wiring only: board init, settings, PMU RTC restore, VCOM, splash, fonts. If VCOM
 * is unset, the factory page blocks first. Then control goes to app_loop.
 */

#include <stdint.h>
#include <string.h>
#include <sys/time.h>

#include "app_loop.h"
#include "app_content_open.h"
#include "boot_state.h"
#include "lock_screen.h"
#include "ui_lock_feedback.h"
#include "lock_pin.h"
#include "ttf_font.h"
#include "book_store.h"
#include "esp_system.h"
#include "read_pico_sd.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <sys/stat.h>
#include "app_registry.h"
#include "display.h"
#include "epd_highlevel.h"
#include "epdiy.h"
#include "esp_log.h"
#include "ota_online.h"
#include "ota_update.h"
#include "pmu_selftest.h"
#include "soc/rtc_cntl_reg.h"
#include "read_pico_board.h"
#include "read_pico_crashlog.h"
#include "read_pico_init.h"
#include "read_pico_pmu.h"
#include "read_pico_pmu_protocol.h"
#include "settings.h"
#include "sleep.h"
#include "ttf_font.h"
#include "usb_storage.h"
#include "app_font_context.h"
#include "ui_kit.h"
#include "vcom_setup.h"
#include "zh_convert.h"

static const char* TAG = "read_pico";
extern const app_desc_t app_boot_recovery;

// 软复位保留有效的 S3 RTC；断电才用 PMU 的实时秒和毫秒恢复。
// Retain a valid S3 RTC across soft reset; restore fresh PMU seconds and milliseconds after power loss.
static void restore_time_from_pmu(void) {
    struct timeval current;
    if (gettimeofday(&current, NULL) == 0 && current.tv_sec >= 1704067200 &&
        current.tv_sec <= 4102444799U) return;
    if (read_pico_pmu_cmd(PMU_CMD_TIME_GET, NULL, 0) != ESP_OK) return;
    const pmu_snapshot_t *pmu = read_pico_pmu_get();
    if (!pmu || !pmu->time_ok || !pmu->time_synced || pmu->unix_millis >= 1000 ||
        pmu->unix_sec < 1704067200 || pmu->unix_sec > 4102444799U) return;
    struct timeval tv = {.tv_sec = (time_t)pmu->unix_sec, .tv_usec = pmu->unix_millis * 1000};
    if (settimeofday(&tv, NULL) == 0) ESP_LOGI(TAG, "system clock restored from PMU");
}

// 已标定则开机读一次喂给 epdiy。未标定先用板级默认出开机图，随后拦住进标定页。
// Load VCOM once when set. Otherwise keep the board default for the splash,
// then gate into the setup page.
static bool resolve_vcom_at_boot(void) {
    int mv = 0;
    for (int i = 0; i < 3; i++) {
        if (read_pico_pmu_vcom_get(&mv) == ESP_OK) {
            epd_set_vcom((uint16_t)mv);
            ESP_LOGI(TAG, "panel VCOM loaded from PMU");
            return true;
        }
    }
    ESP_LOGW(TAG, "panel VCOM unset, keeping board default until setup");
    return false;
}

// 缓存验证失败时继续原开机路径，不假设未知屏幕已经全白。
// A rejected cache keeps the original startup path; never assume an unknown panel is white.
static bool restore_retained_lock(EpdiyHighlevelState *hl,uint8_t *framebuffer) {
    (void)framebuffer;
    // 深睡唤醒不再阻塞等 TF 挂载（原来最多 3 秒）：先立即尝试一次缓存恢复，成功时只恢复前后帧、
    // 面板保留原画；卡还没就绪时给 500ms 有界窗口，仍失败就取消挂起并交给下面的清白+兜底路径，
    // 保证 back 基准一定有定义。
    // Deep wake no longer blocks on the TF mount (previously up to 3 s): try the cache once at once;
    // on success only the frames are restored and the panel keeps its image. A bounded 500 ms window
    // follows; after that the pending resume is cancelled and the clear+fallback path below runs, so
    // the back baseline is always defined.
    if(app_lock_resume_frame(hl))return true;
    for(unsigned wait=0;wait<25;++wait){
        vTaskDelay(pdMS_TO_TICKS(20));
        const int state=app_lock_resume_poll();
        if(state>0)return true;
        if(state<0)break;
    }
    (void)app_lock_resume_frame(NULL);
    return false;
}

// 深睡恢复会继续等双击解锁；缓存失效时也必须显示锁屏。
// 用户修订：不再有「准备资源」开机图，冷启动和所有深睡唤醒一律只显示小锁界面，
// 省下 415,872 字节的内嵌 4bpp 开机图（整块释放给 ota_0 槽）。
// Deep resumes still await double-press unlock; invalid art must show a lock face.
// User revision: the preparing-resources splash is gone. Cold boot and every deep-sleep wake
// show only the small lock face, freeing the 415,872-byte baked 4bpp splash from flash.
static bool prepare_startup_frame(EpdiyHighlevelState *hl,uint8_t *framebuffer,bool resuming,bool vcom_ok) {
    (void)vcom_ok;
    // 用户要求：深睡唤醒也统一显示「小锁界面」，不再恢复上一次锁屏缓存。缓存里可能是一张壁纸，
    // 醒来先看到壁纸而不是小锁；这里与冷启动共用同一张小锁面，保证唤醒第一眼就是小锁。
    // User request: deep-sleep wake also shows the small lock face; do not restore the retained lock
    // art (it may be a wallpaper). Wake and cold boot share the same small-lock face.
    epd_poweron();
    if(!resuming)read_pico_i2c_census_take();
    epd_clear();
    epd_hl_set_all_white(hl);
    // 冷启动与唤醒共用同一个锁屏面：只有小锁，没有「准备资源」文字画面。
    // Cold boot and wake share one face: only the small lock, no preparing-resources splash.
    ui_lock_fallback_draw(framebuffer);
    update_display_from_white(hl);
    return false;
}

void app_main(void) {
    // 共享 TF 卡期间复位后，先把内部 PHY 交回串口，再清理已用完的 BOOT 请求。
    // Reclaim Serial/JTAG after a reset during card sharing, then clear the served BOOT request.
    usb_storage_phy_init();
    REG_CLR_BIT(RTC_CNTL_OPTION1_REG, RTC_CNTL_FORCE_DOWNLOAD_BOOT);

    const esp_reset_reason_t reset = esp_reset_reason();
    ESP_LOGI(TAG, "startup reset=%d stack=%u", (int)reset, (unsigned)uxTaskGetStackHighWaterMark(NULL));
    app_settings_init();
    // 繁简是全局显示模式，第一帧文字之前就生效；只改绘制，不改任何文件内容。
    // Script mode is global and applies before the first drawn glyph; it only affects drawing, never file contents.
    zh_convert_set_mode(app_settings_zh_mode());
    // 在大缓冲和字体之前读取小型锁屏设置；读取失败不阻塞，之后的检查仍可重试。
    // Read the tiny lock setting before large buffers/fonts; keep failures nonblocking and let subsequent checks retry.
    (void)lock_pin_enabled();
    pico_boot_init(reset == ESP_RST_PANIC || reset == ESP_RST_INT_WDT ||
                   reset == ESP_RST_TASK_WDT || reset == ESP_RST_WDT);

    read_pico_handle_t hw;
    if (read_pico_init(&hw) != ESP_OK) return;
    // 显示/OTA 递归锁开机即建：推屏与低优先级断电任务都靠它互斥，不能等进升级页才创建。
    // Create the display/OTA recursive lock at boot: output and the low-priority power-off task rely
    // on it, and it must not wait for the first upgrade-page visit.
    pico_online_display_lock_init();
    // 反色是显示解释方式，必须在第一帧之前设好；首帧的 from-white 基准会按反色方向建立。
    // Inversion is a display interpretation; set it before the first frame so the from-white baseline is built inverted.
    epd_set_inverted(app_settings_invert_effective());
    rp_boot_mark("hw");
    if (hw.pmu_ready) restore_time_from_pmu();
    // 深睡唤醒/冷启动时系统时钟在“首帧反色判断”之后才从 PMU 恢复：恢复后再核一次夜间窗口，
    // 否则 21:00–07:00 启动的第一帧会按白天解释，直到主循环第一次核对才翻过来。
    // A deep-sleep boot restores the clock after the first inversion decision; re-check the night
    // window so the first frame in 21:00-07:00 is interpreted correctly.
    if (app_settings_invert_night()) epd_set_inverted(app_settings_invert_effective());
    const bool vcom_ok = resolve_vcom_at_boot();
    rp_boot_mark("vcom");
    pmu_selftest_bind(hw.sensor);
    app_sleep_bind(hw.touch, hw.sensor);

    EpdiyHighlevelState hl = hw.hl;
    uint8_t* framebuffer = hw.framebuffer;

    // 深睡保留屏幕已有画面：验证缓存后同时恢复前后帧，省去清白和开机图两次推屏。
    // Deep sleep retains the panel image: validate its cache and restore both references, skipping white erase and splash output.
    const bool resuming = pico_boot_has_resume();
    bool restored_lock=prepare_startup_frame(&hl,framebuffer,resuming,vcom_ok);
    rp_boot_mark("splash");
    // 直接续读不先加载整份系统字体；密码验证仍先使用所选系统字体。
    // Direct reader resume skips loading the whole system face first; PIN authentication still uses the selected UI face.
    if(!resuming || lock_pin_enabled())app_font_activate_system();
    else (void)ttf_font_open_builtin();
    rp_boot_mark("font");

    if (!hw.touch_ready) {
        ESP_LOGE(TAG, "No touch controller, UI cannot run");
        return;
    }

    if (hw.pmu_ready && !vcom_ok) {
        vcom_setup_run(&hl, framebuffer, hw.touch);
    }

    // 硬件、显示、触摸与必要的出厂设置均成功后确认新槽。
    // Confirm a new slot only after hardware, display, touch, and required setup succeed.
    pico_ota_confirm_running();

    // 单击开机：开机那一次短按就算开机，直接续读；双击开机仍停在锁屏等第二次。
    // One-press boot treats the powering short press as the boot; double-click boot still waits on the lock face.
    const bool one_press_boot = resuming && !lock_pin_enabled() && hw.pmu_ready &&
        app_settings_wake_presses() == 1;
    bool boot_press = read_pico_pmu_take_boot_short_press();
    // 按住稍久会被 PMU 记成长按，释放也可能晚于握手；有界补等一次按键事件，避免已经按过还要再按。
    // A slightly long hold is logged as a long press and its release can land after the handshake,
    // so wait a bounded window for that event instead of asking for a second press.
    for (unsigned wait = 0; one_press_boot && !boot_press && wait < 50; ++wait) {
        boot_press = read_pico_pmu_take_key_wakeup_single();
        if (!boot_press) vTaskDelay(pdMS_TO_TICKS(20));
    }
    const bool boot_with_one_press = one_press_boot && boot_press;
    if (boot_with_one_press) {
        ESP_LOGI(TAG, "resume lock cache=%d; one-press boot", restored_lock);
        pico_boot_ready();
        pico_boot_hold_resume();
    } else {
        if(resuming && !lock_pin_enabled())
            ESP_LOGI(TAG,"resume lock cache=%d; power presses=%u",restored_lock,
                (unsigned)app_settings_wake_presses());
        app_lock_boot_gate(&hl, hw.touch, hw.sensor);
    }
    rp_boot_mark("lock");
    const app_desc_t *first = app_home_page();
    pico_resume_t resume = {0};
    if (pico_boot_take_resume(&resume)) {
        if (!resume.reader) first = app_at(resume.tab);
        else {
            // 挂载等待有界；恢复入口已消费，无卡或资源失败不会反复自动开书。
            // Bound mount waiting after consuming the checkpoint; absent media or failed resources cannot auto-open in a loop.
            if (!strncmp(resume.path, "/sdcard/", 8)) {
                read_pico_sd_info_t info;
                for (unsigned wait = 0; wait < 150 && read_pico_sd_get_info(&info) == ESP_ERR_NOT_FINISHED; ++wait)
                    vTaskDelay(pdMS_TO_TICKS(20));
            }
            if (!strncmp(resume.path, "/flash/books/", 13) && !book_store_flash_ready()) {
                book_store_root_t roots[BOOK_STORE_ROOT_MAX]; int count;
                (void)book_store_roots(roots, &count);
            }
            struct stat st;
            if (!stat(resume.path, &st) && S_ISREG(st.st_mode) &&
                app_book_request_resume(resume.path, resume.fullscreen)) first = app_at(1);
        }
    }
    char interrupted[PICO_BOOT_PATH_MAX];
    if (pico_boot_interrupted_book(interrupted, sizeof(interrupted))) first = &app_boot_recovery;
    if(resuming && !lock_pin_enabled()) {
        if(first==app_at(1) && resume.reader)app_font_activate_reading();
        else app_font_activate_system();
    }
    rp_boot_mark("resume");
    app_loop_run(&(app_loop_config_t){
        .hl = &hl,
        .fb = framebuffer,
        .acc = hw.sensor,
        .tp = hw.touch,
        .sensor_ready = hw.sensor_ready,
        // 用户修订：深睡一次性恢复上次阅读或主页面；异常启动安全回首页。
        // User revision: resume the last reader/main tab once after deep sleep; abnormal starts safely enter Home.
        .first_app = first,
    });
}
