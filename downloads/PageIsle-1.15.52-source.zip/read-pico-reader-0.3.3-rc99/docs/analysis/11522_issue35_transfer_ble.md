# 1.15.22 / issue #35 · WiFi 传书不可用 + 蓝牙搜索失败（内存不足）根因与修复

- 源码基线：`0.3.3-rc99` / 页屿系统 1.15.21（2026-10-26）
- 范围：`main/apps/app_transfer.c`、`main/apps/app_device_settings.c`（蓝牙/传书入口小改）、
  `components/read_pico_transfer/**`、`components/ble_page_turner/**`
- 验证等级：**仅编译期验证（syntax_check 全通过）+ 静态代码审查；无真机、无设备日志**。
  本文所有结论来自代码路径与既有注释/设计契约，真机待验项见文末。

## 一、用户现象

1. **P0-3 WiFi 传书不可用**：进入传书页选「WiFi 传书 / 热点传书」后无法使用（热点起不来、
   网页打不开、连接不上或启动失败后无法恢复，具体未明）。
2. **P0-5 蓝牙搜索失败并提示内存不足**：打开蓝牙翻页器后点「添加翻页器 / 扫描设备」，
   搜索失败且界面提示「内存不足」。

## 二、P0-3 WiFi 传书不可用：根因

### RC-1（主因）AP 模式"假就绪"：不等 `WIFI_EVENT_AP_START`，且 AP 永不做启动超时

旧代码 `read_pico_transfer_start()` 在 `esp_wifi_start()` 返回 `ESP_OK` 后立即把
`s_status.network_ready = true`、`url = http://192.168.4.1`。`esp_wifi_start()` 只是"命令被
接收"，AP 真正可用（含 DHCP 服务器启动）是 `WIFI_EVENT_AP_START` 到达之后；而
`read_pico_transfer_service_poll()` 对非 STA 模式直接 `return`，AP 没有超时判定。
后果链：

- 若 AP 实际未起来（射频/托管控制面异常），页面仍显示「服务已开启」与访问地址，
  `prepare_qr()` 也照旧生成二维码 → 手机连不上或连上拿不到 IP，网页打不开；
- 页面永远停在"就绪"假象，**没有任何错误提示、没有重试入口**（`draw_status()` 的
  `READ_PICO_TRANSFER_ERROR` 分支永远走不到）。
- 另外 `WIFI_EVENT_AP_STOP` 完全未处理：AP 中途自己掉了，状态仍停在就绪。

证据：`read_pico_transfer.c` 旧实现中 AP 分支直接 `s_status.network_ready = true`；
`service_poll()` 开头 `if (!s_started || s_cfg.mode != READ_PICO_TRANSFER_MODE_STA) return;`；
`wifi_event()` 只处理 `AP_STACONNECTED/AP_STADISCONNECTED`，无 `AP_START/AP_STOP`。

### RC-2 启动失败的处理链断裂：无有效提示、WiFi 模式无法重试

- `on_enter()` 的热点分支失败时把提示写进 `s_method_message`，但画面是 `TRANSFER_HOME`，
  该视图根本不画 `s_method_message`（只有 `draw_methods()` 画）；且没有写
  `s_status.last_error`，状态卡第二行显示「原因：ESP_OK」。
- `draw_status()` 第二行只打印 `esp_err_to_name()`（「原因：ESP_ERR_NO_MEM」），用户看不懂
  也不知道该做什么。
- HOME 底部按钮只有 AP 模式失败才变成「重试热点传书」；**STA（WiFi 传书）失败后按钮仍是
  「停止传输服务」**，点它就停服/退出页面，用户没有重试路径，只能退出重进。
- `network_ui_tick()` 里「连接启动失败，请重试」只写提示，没有把失败状态接到可点的重试入口
  （连接按钮在未保存/失败时可能不可见）。
- `on_enter()` 的 `s_wifi_setup_requested` 分支忽略 `enter_networks()` 的失败返回值。

### RC-3 状态机：`read_pico_transfer_stop()` 可半途返回，之后 `start()` 永远 `ESP_ERR_INVALID_STATE`

`read_pico_transfer_stop()` 是 `void`；开头 `if (!cancel_time_sync(false)) return;`——对时任务
2 秒内没退出时直接返回，无线电/HTTP/netif 资源全留着，调用方（传书页）却认为已停止。
下一次 `read_pico_transfer_start()` 检查 `if (s_wifi || s_netif || s_http) return ESP_ERR_INVALID_STATE;`
→ 每次重试都失败，形成"服务起不来"的死状态（直到下一次 stop 成功）。且早退路径没有日志，
现场无从定位。

### RC-4 起无线电前内存回收不完整

`app_transfer.c` 起服务/扫描前只调 `ttf_font_cache_clear()`（当前槽位字形），未归还
`ttf_font_cache_clear_all()`（所有槽位，最多约 1.5 MB）、`ui_font_cache_clear()`（内建界面
字形位图，最多 512 KB）、`app_home_release_clock_cache()`（首页表盘池，最多 763 KB）。
`read_pico_transfer_start()` 在 `esp_wifi_init()` 之后要再申请 HTTP 任务 12 KB **内部**
RAM（`http.task_caps = MALLOC_CAP_INTERNAL`）与 16 KB PSRAM 缓冲；余量不足时启动失败
`ESP_ERR_NO_MEM`，而旧代码只显示 errno（见 RC-2）。OTA/坚果云早已使用上述"同级回收"，
传书页漏了。

## 三、P0-5 蓝牙搜索失败/内存不足：根因

### RC-5（主因）内存门槛失败被当成"坏启动"：30 秒退避 + NVS 失败计数 + 跨重启自锁

`ble_pt_sync()` 对**所有** `ble_pt_start()` 失败统一处理：先 `boot_tries_store(tries+1)`，
再 30 秒退避、把原因写 NVS，连续 3 次后自锁（要求用户"关掉再开启"）。但
`start_locked()` 的前置内存门槛（内部 RAM ≥56 KB、最大块 ≥20 KB、PSRAM ≥256 KB）失败只是
**"此刻内存不够"的临时状态**，不是坏启动。后果：

- 页面/书籍使用后常驻的可重建缓存（字形、表盘池）把 PSRAM/内部余量压到门槛线下 →
  门槛失败一次，用户看到「内存不足」；
- 30 秒退避让用户点扫描时栈仍未启动（`ble_pt_scanning() == false`、`ble_pt_running() == false`）；
- 连续 3 次后写入 NVS 自锁，重启后仍显示「启动失败 3 次：内存不足（内部 xxK，最大块 xxK）
  （关掉再开启可重试）」——这就是用户报的"搜索失败并提示内存不足"。

证据：`ble_page_turner.c` 旧 `ble_pt_sync()` 失败分支；`start_locked()` 门槛；
`app_loop.c` 只通过 `ble_pt_sync()` 启停栈（该文件由 Lead 维护，本次未改）。

### RC-6 提示只报内部 RAM，看不出真正卡的是 PSRAM

门槛同时检查内部 RAM 与 PSRAM，但失败文案只有「内存不足（内部 %uK，最大块 %uK）」。
本案常驻缓存主要占 PSRAM，用户看到内部数字"还很宽裕"却被判内存不足，无法解释。

### RC-7 扫描入口与扫描重试的状态机缺陷

- 开关拨开后蓝牙栈是**异步**启动的（`ble_pt_sync` 有 2 秒防抖 + NimBLE 初始化）。旧
  `app_device_settings.c` 扫描入口要求 `!app_settings_ble_turner() || !ble_pt_running()`
  才允许进入；刚开启就点「添加翻页器」会被拒绝并提示「请先开启蓝牙翻页器」——用户明明
  开了蓝牙，看起来就是"搜索失败"。
- `ble_pt_scan_start()` 的 `ble_gap_disc()` 失败被空 `else {}` 静默吞掉；扫描页只在进页时
  调用一次，失败/被拒（栈未就绪、正在连接、控制器忙）后再无重试，页面永远显示
  「扫描已停止」，且不显示失败原因。
- 扫描页不消费 `ble_pt_take_start_failure()`（只有蓝牙二级页消费），启动失败原因在扫描页
  永远看不到。
- 已连接翻页器时进入扫描页：`ble_pt_scan_start()` 因 `s_connected` 直接返回，扫描页同样
  永远"扫描已停止"（要添加新翻页器必须先断开，但页面没提供这个动作）。

## 四、修复实现

### 4.1 `components/read_pico_transfer/read_pico_transfer.c`

1. **AP 就绪事件化**（RC-1）
   - 新增 `s_ap_started_ms` 与 `AP_START_TIMEOUT_MS`（10 s）。
   - `read_pico_transfer_start()` AP 分支不再立即置 `network_ready`，只记等待起点、置
     `STARTING`，等 `WIFI_EVENT_AP_START`。
   - `wifi_event()` 新增 `WIFI_EVENT_AP_START`（置 `network_ready=true`、`url=READ_PICO_TRANSFER_URL`、
     `READY`、清等待点）与 `WIFI_EVENT_AP_STOP`（非停服期间掉线 → `ERROR` + `ESP_FAIL`，
     页面可重试）。
   - `read_pico_transfer_service_poll()` 对 AP 模式也做启动超时：超过 10 s 未就绪 →
     `ERROR` + `ESP_ERR_TIMEOUT`（只报一次），页面给出可重试提示；迟到的事件仍能恢复就绪。
2. **起停自愈**（RC-3）
   - `read_pico_transfer_start()`：发现残留资源时先就地 `read_pico_transfer_stop()` 再判定，
     避免"永远 INVALID_STATE"。
   - `read_pico_transfer_stop()`：对时任务未退出导致早退时打日志
     `stop deferred: time sync still active`（新增日志，便于现场定位）。
3. 新增 AP 就绪/超时日志（`ap starting, waiting for AP_START`、`ap ready url=…`、
   `ap start timeout after … ms`、`stop deferred: …`）。原有日志文案未改。

### 4.2 `main/apps/app_transfer.c`

1. **完整回收可重建缓存**（RC-4）：新增 `transfer_release_caches()` =
   `ttf_font_cache_clear_all() + ui_font_cache_clear() + app_home_release_clock_cache()`，
   在「起上传服务」与「扫描附近 WiFi」两处起无线电前调用（替换原来的单槽
   `ttf_font_cache_clear()`）。新增 `#include "app_content_open.h"`、`"ui_font.h"`。
2. **失败提示可读**（RC-2）：新增 `transfer_error_hint()`，状态卡第二行由
   `原因：ESP_ERR_*` 改为可操作中文（内存不足 / 服务尚未结束请重试 / 超时 / 未找到配置 /
   无线服务已停止）。无 errno 时回退「启动失败，请点下方按钮重试」。
3. **两种模式都能重试**（RC-2）：
   - HOME 底部按钮：`ERROR && !network_ready` 时 AP 显示「重试热点传书」、STA 显示
     「重试 WiFi 传书」（原来 STA 失败只能退出）。
   - `on_gesture` idle 按钮：按模式分别重启热点 / `queue_network_start(STA)`。
4. **入口失败可见、模式正确**（RC-2）：
   - 热点入口失败 → 回到 `TRANSFER_METHODS` 并设 `last_error=ESP_ERR_INVALID_STATE`，
     提示在方法页可见，用户可再点一次。
   - WiFi 上传入口失败 → 写 `last_error`，HOME 可重试；并先把 `s_mode` 定为 STA，避免沿用
     上次 AP 模式显示「热点传书未启动」并走错重试分支。
   - `s_wifi_setup_requested` 分支处理 `enter_networks()` 失败并提示。
5. 新增 UI 文案（任务必需，风格与既有页面一致）：
   `重试 WiFi 传书`、`传书服务正在结束，请稍后再点一次`、`传书服务正在结束，请点下方按钮重试`、
   `网络服务正在结束，请稍后重试`、失败原因五种中文提示。

### 4.3 `components/ble_page_turner/src/ble_page_turner.c` + 头文件

1. **内存门槛失败可恢复化**（RC-5，`ble_pt_sync()`）：
   - 新增 `start_memory_ok()` 预检（与 `start_locked()` 同一组门槛宏）：在累加崩溃计数、
     写 NVS **之前**先探内存；不足则只设 2 秒短退避并刷新界面提示（含内部/PSRAM 数字），
     **不增加失败计数、不写 NVS**（避免每 2 秒一次 NVS 写入）。
   - `ESP_ERR_NO_MEM` 分支兜底（预检通过但 `start_locked()` 门槛仍失败 / NimBLE 任务创建
     失败）：`boot_tries_store(tries)` 退回计数（**不再计入跨重启自锁**）、退避
     `BLE_PT_MEM_RETRY_MS = 2000 ms`、不写 NVS 持久原因（`why_store(NULL)`，避免下次开机
     显示旧数字）、把原因交给界面提示；日志 `start refused for memory, retrying in 2000 ms`。
   - 真实的初始化失败/崩溃路径仍保留 30 s 退避 + 计数 + 自锁（原设计不变）。
2. **门槛失败文案补 PSRAM**（RC-6）：`s_failure` 改为
   「内存不足（内部 %uK/%uK，PSRAM %uK）」；`ESP_LOGW` 仍保留三项原始字节数。
3. **扫描失败不再静默**（RC-7）：`ble_pt_scan_start()` 被拒时 `ESP_LOGD` 说明原因
   （running/scanning/connected/connecting），`ble_gap_disc()` 失败时 `ESP_LOGW("scan start failed rc=%d")`；
   供页面重试节拍与现场日志对齐。头文件补充扫描契约注释（调用方负责节拍重试）。
4. 未改扫描参数、结果上限（`BLE_PT_MAX_DEVICES=24`，静态约 1.5 KB，不构成内存瓶颈）、
   NimBLE 配置与任何 sdkconfig。

### 4.4 `main/apps/app_device_settings.c`（蓝牙/传书入口小改）

1. **开启蓝牙前回收缓存**（RC-5/RC-6）：新增 `ble_release_rebuildable_caches()`（与 OTA/
   坚果云同级的三连回收），在拨开「启用蓝牙」与进入扫描页前调用；开启时同时
   `ble_pt_reset_failure()` 清掉上次失败/退避（用户明确的新尝试）。提示改为
   「已开启，正在启动…」。
2. **扫描页自动重试**（RC-7）：新增 `s_ble_scan_retry_ms` 与 `ble_scan_retry_tick()`
   （每 1 s 一次，`on_tick` 仅在扫描页调用），栈就绪/旧链路拆完后自动开始扫描。
3. **允许栈启动中进入扫描页**（RC-7）：只要「启用蓝牙」为开就允许进入，不再用
   `!ble_pt_running()` 误报「请先开启蓝牙翻页器」；已连接/连接中时先断开旧链路
   （本模块同一时刻只服务一个外设），提示「已断开当前翻页器，开始扫描」。
4. **扫描页显示原因**（RC-7）：`on_tick` 对扫描页也消费 `ble_pt_take_start_failure()`；
   扫描页头显示「蓝牙正在启动…」而非「扫描已停止」，并在状态行下新增提示行
   （启动失败原因 / 断开说明），用 `fit_value()` 截断防溢出。
5. 新增 UI 文案：`已开启，正在启动…`、`蓝牙正在启动…`、`已断开当前翻页器，开始扫描`
   （替换原「已开启，正在等待设备」）。

## 五、验证

### 改动文件与关键行号（当前源码 1.15.21 修改后）

- `components/read_pico_transfer/read_pico_transfer.c`：480–481 `s_ap_started_ms`/`AP_START_TIMEOUT_MS`；
  940–956 AP_START/AP_STOP 事件；969–970 AP 就绪日志；1018–1041 service_poll AP 超时；
  1928–1955 stop 早退日志与状态清理；1957–1971 start 残留资源自愈；2098–2106 AP 启动等待。
- `main/apps/app_transfer.c`：144–148 `transfer_release_caches()`；153–163 `transfer_error_hint()`；
  516–519 扫描前回收；728–732 状态卡原因行；853–862 失败重试按钮；940–947 热点入口失败回方法页；
  959–967 STA 模式先定；968–997 入口失败提示；1103–1106 起服务前回收；1262–1285 两种模式重试。
- `components/ble_page_turner/src/ble_page_turner.c`：98 `BLE_PT_MEM_RETRY_MS`；670–701 扫描拒绝/失败日志；
  1545–1556 门槛失败文案（含 PSRAM）；1704–1713 `start_memory_ok()` 预检；1785–1834 `ble_pt_sync()`
  预检 + NO_MEM 可恢复分支。
- `components/ble_page_turner/include/ble_page_turner.h`：156–166 扫描契约注释（调用方负责节拍重试）。
- `main/apps/app_device_settings.c`：304 `s_ble_scan_retry_ms`；1546–1551 扫描页状态/提示行；
  1813–1831 缓存回收与扫描重试助手；1953–1965 `on_tick` 扫描重试 + 失败原因；
  2612–2630 开关开启回收/复位；2631–2657 扫描入口放宽 + 断开旧链路。

| 项目 | 结果 |
| --- | --- |
| `python syntax_check.py main/apps/app_transfer.c` | exit 0（-Wall -Werror -Wextra，无新告警） |
| `python syntax_check.py main/apps/app_device_settings.c` | exit 0 |
| `python syntax_check.py components/ble_page_turner/src/ble_page_turner.c`（绝对路径） | exit 0 |
| `python syntax_check.py components/read_pico_transfer/read_pico_transfer.c`（绝对路径） | exit 0 |
| `tools/ble_turner_host_test.py` 的函数抽取阶段（正则/花括号平衡） | 通过（脚本走到 host 编译前） |
| `tools/ble_turner_host_test.py` 运行 | **无法运行**：环境无 host `cc`（Windows 无 gcc/clang），非代码问题 |
| 真机 | **未验证**（无设备；不得声称通过） |

## 六、风险与真机待验

### 风险/取舍

1. **AP 就绪改为事件驱动**：依赖 `WIFI_EVENT_AP_START`（ESP-IDF 标准事件；本固件链接本机
   ESP32-S3 WiFi 库，见 build map 中 `libnet80211.a/libpp.a`）。若某后端不发该事件，第一次
   AP 会先报 10 s 超时，用户点重试；**需要真机确认页面在 1–3 s 内显示二维码与地址**。
2. **开启蓝牙前清空所有字形/表盘缓存**：首屏重绘会短暂变慢（按需重建），OTA/坚果云已有同样
   做法；不影响设置与配对数据。
3. **已连接时点「添加翻页器」会主动断开当前翻页器**：为扫描新设备所必需（模块单外设设计），
   断开即清自动重连目标；用户需重新连接旧设备。若产品不接受，可改为提示用户手动断开。
4. 内存门槛数值（56 KB 内部 / 20 KB 块 / 256 KB PSRAM）**未调低**：调低可能半途初始化失败，
   风险高于收益；本次只把"临时不足"改为短退避重试 + 提示补全。
5. 新增中文 UI 文案 8 条、新增英文注释若干；未改既有 UI 字面量与既有日志字符串，仅新增
   诊断日志。

### 真机待验清单（Lead 统一验收）

**WiFi 传书**
1. 热点传书：选「热点传书」后 ≤3 s 内页面显示访问地址与二维码；手机能连 `kiikoread-XXXX`、
   能打开 `http://192.168.4.1` 并上传 EPUB/TXT；上传进度与完成提示正常。
2. 热点异常路径：若 AP 未起来，页面应在约 10 s 内显示失败原因与「重试热点传书」，点击可恢复
   （可用开飞行模式/占用射频等办法，或观察串口 `ap start timeout`）。
3. WiFi 传书：已保存网络时启动后能连上并显示地址；断网/密码错误时显示可读原因与
   「重试 WiFi 传书」，点击重新连接。
4. 从「文件管理」直接进入 WiFi 传书/热点传书失败后，按钮为重试而非"停止"。
5. 传书期间/结束后内存日志：`transfer` 的 `http start/ready internal free=…`、`leave keep_sta=… heap before/after`；
   确认启动失败不再出现 `ESP_ERR_INVALID_STATE` 死循环。

**蓝牙翻页器**
6. 开启蓝牙后立即点「添加翻页器」：应进入扫描页显示「蓝牙正在启动…」→「正在搜索…」，
   不再提示「请先开启蓝牙翻页器」。
7. 连续开启/关闭蓝牙 3 次以上并每次进入扫描：不应出现跨重启的「启动失败 3 次」自锁；
   串口 `ble_pt` 日志出现 `start refused for memory, retrying in 2000 ms` 后能自行恢复。
8. 已连接翻页器时点「添加翻页器」：应断开旧链路并开始扫描（提示已断开），能扫到并连接新设备。
9. 曾出现过「内存不足」的机器：更新后开启蓝牙/扫描应显示新文案（带 PSRAM 数字，若仍失败），
   并每 2 s 自动重试，恢复后自动开始扫描；关掉再开启可清失败状态。
10. 内存回收副作用：开启蓝牙后翻到其他页面/进设置，文字与图标不应缺字（缓存按需重建）。

## 七、需要 Lead 统一处理的项

- **sdkconfig**：本次无需改动（NimBLE 缓冲/栈、WiFi 缓冲均保持现状；门槛未调低）。
- **跨文件建议（app_loop.c / app_main.c 由 Lead 维护）**：
  1. 快捷手势栏开启蓝牙（`app_loop.c` 的 `ble_pt_sync()` 调用点）没有机会回收可重建缓存；
     设置页的开关/扫描入口已回收。若希望快捷栏开启也一次成功，可在 `app_main.c` 启动时给
     `ble_page_turner` 注册一个"回收回调"（需在其公开头新增
     `typedef void (*ble_pt_reclaim_fn)(void); void ble_pt_set_reclaim_fn(ble_pt_reclaim_fn);`，
     在门槛失败前调用），或由 Lead 在 `app_loop.c` 开启蓝牙的分支里直接调用
     `ttf_font_cache_clear_all()/ui_font_cache_clear()/app_home_release_clock_cache()`。
     本次未做，因为这两个文件不在本任务写权限内；组件侧已用"2 s 短退避 + 不自锁"兜底，
     用户进设置页/扫描页时也会回收，功能可用性不依赖该改动。
  2. `tools/ble_turner_host_test.py`：本环境缺少 host `cc`，无法运行；其函数抽取阶段已通过，
     建议 Lead 在有 gcc 的机器上跑一次确认 BLE 生命周期断言无回归。
- **CHANGELOG/版本**：建议 1.15.22 条目（用户可见）：
  「修复 WiFi/热点传书启动失败无提示、无法重试与热点假就绪；修复蓝牙翻页器搜索时因可重建
  缓存占用而误报内存不足、且失败后长期无法重试的问题」。
