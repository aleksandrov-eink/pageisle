set(main_requires
    read_pico
    read_pico_transfer
    read_pico_search
    espressif__qrcode
    espressif__esp_jpeg
    # 渐进式 JPEG；基线仍走 esp_jpeg。/ Progressive JPEG; baseline stays on esp_jpeg.
    jpegdec
    # 渐进式 JPEG 解码核心（vendor lowzag 2.2.1，MIT）；lowzag 失败才回落 jpegdec。
    # Progressive JPEG core (vendored lowzag 2.2.1, MIT); jpegdec is the fallback.
    lowzag
    # WebP 解码子集（libwebp 1.5.0 的 dec/dsp/utils；只依赖 heap）。
    # WebP decoder subset (libwebp 1.5.0 dec/dsp/utils; heap only).
    read_pico_webp
    espressif__libpng
    espressif__zlib
    espressif__esp_tinyusb
    # BLE HID 主机（蓝牙翻页器）。本仓库开了 MINIMAL_BUILD，组件不进依赖图的话连它的
    # Kconfig 都不会加载，sdkconfig.defaults 里的 CONFIG_BT_* 会被判为未知符号而丢弃。
    # BLE HID host (Bluetooth page-turner). This tree sets MINIMAL_BUILD, so a component
    # outside the dependency graph does not even load its Kconfig and the CONFIG_BT_*
    # entries in sdkconfig.defaults are dropped as unknown symbols.
    bt
    # 蓝牙翻页器本体。/ The page-turner itself.
    ble_page_turner
    continuous_du
    e0470_epaper_waveform
    e0470_page_turn
    read_pico_pmu
    fatfs
    wear_levelling
    bootloader_support
    spi_flash
    heap
    nvs_flash
    esp_hw_support
    esp_rom
    esp_driver_gpio
    esp_driver_usb_serial_jtag
    esp_app_format
    app_update
    esp_http_client
    mbedtls
    espressif__cjson
)
set(kiiko_selected_sources "app_main.c"
        "boot_state.c"
        "apps/app_boot_recovery.c"
        "ota_update.c"
        "ota_online.c"
        "ota_release.c"
        "display.c"
        "display_main_waveform.c"
        "display_reader_waveform.c"
        "sleep.c"
        "time_service.c"
        "lock_pin.c"
        "lock_pin_flow.c"
        "lock_screen.c"
        "settings.c"
        # 防褪色重刷：强光下像素电荷泄漏会让静态画面变灰/发黑，主循环与锁屏按间隔整屏重推。
        # Anti-fade: static frames fade/darken from charge leakage under strong light; the loop and
        # the lock face re-drive them at a fixed interval.
        "anti_fade.c"
        "factory_reset.c"
        "app/app_loop.c"
        # 逐界面运行内存诊断：内部 SRAM / PSRAM 峰值占用统计，供设置页查看与 SD 日志。
        # Per-screen runtime RAM diagnostics: Internal SRAM/PSRAM peaks for the settings page and SD log.
        "app/app_ram_diag.c"
        "app/crash_note.c"
        "app/app_registry.c"
        "ui/ui_kit.c"
        "ui/ui_text_edit.c"
        "ui/ui_text_input.c"
        "ui/ui_ime.c"
        "ui/ui_keyboard.c"
        "ui/ui_gesture.c"
        "ui/ui_glass.c"
        "ui/ui_pinpad.c"
        "ui/ui_power_dialog.c"
        "ui/ui_quick_menu.c"
        "ui/ui_lock_feedback.c"
        "ui/ui_quick_menu_input.c"
        "ui/ui_click_feedback.c"
        "ui/ui_wifi_qr.c"
        "ui/datamatrix.c"
        "ui/ui_menu.c"
        "ui/ui_nav.c"
        "ui/ui_touch_capture.c"
        "ui/ui_home_widget.c"
        "ui/ui_home_clock.c"
        "ui/ui_image_dither.c"
        "ui/ui_wallpaper.c"
        "ui/ui_avatar.c"
        "ui/ui_reader_background.c"
        "apps/app_book.c"
        "apps/book_toc.c"
        "apps/app_dashboard.c"
        "apps/app_files.c"
        # rc103 文件管理：增量深度优先递归搜索（文件页/统计共用）。
        # rc103 file management: incremental depth-first recursive search (file page and stats).
        "apps/file_search.c"
        "apps/file_tree.c"
        "apps/app_device_settings.c"
        "apps/app_features.c"
        "apps/feature_ui.c"
        "apps/feature_pomodoro.c"
        "apps/feature_alarm.c"
        "apps/game_2048.c"
        "apps/game_snake.c"
        "apps/game_tetris.c"
        "apps/game_gomoku.c"
        "apps/feature_todo.c"
        "apps/timer_service.c"
        "apps/app_reminder.c"
        "apps/todo_store.c"
        "apps/app_image.c"
        "apps/app_transfer.c"
        "apps/usb_storage.c"
        "book/book_store.c"
        # rc103 文件管理：书架首次收录顺序索引（移动/删除时迁移，供后续书架排序）。
        # rc103 file management: first-added ordering index (migrated on move/delete).
        "book/book_added.c"
        "book/book_progress.c"
        "book/book_progress_sync.c"
        "book/book_history_backup.c"
        "book/book_title.c"
        "book/book_ticket.c"
        "book/book_excerpt.c"
        "book/book_lock_collage.c"
        "book/book_lock_bookmark.c"
        "book/book_source.c"
        "book/book_index_cache.c"
        "book/book_txt.c"
        "book/book_epub.c"
        "book/book_cover.c"
        "book/book_cover_jobs.c"
        "book/book_highlight.c"
        "book/book_image_header.c"
        "book/book_cover_auto.c"
        "book/zip_reader.c"
        "book/html_text.c"
        "book/book_layout.c"
        "book/gbk.c"
        # Markdown 书源与坚果云同步页；新功能模块各自一个文件，便于独立维护。
        # Markdown source and the Jianguoyun sync page; one file per feature keeps them separable.
        "book/book_md.c"
        "apps/app_cloud.c"
        "net/webdav_client.c"
        "font/ttf_font.c"
        "font/app_font_context.c"
        "font/ui_font.c"
        "font/ui_hanzi.c"
        "font/font_diag.c"
        "font/zh_convert.c"
        "font/zh_convert_ctx.c"
        # 内嵌压缩资产（TTF/图标/时钟位图）的一次性解压助手；资产本身走 EMBED_FILES。
        # One-shot inflater for the compressed embedded assets; the assets themselves use EMBED_FILES.
        "assets/asset_unpack.c"
        "factory/pmu_selftest.c"
        "factory/vcom_setup.c")

idf_component_register(
    SRCS ${kiiko_selected_sources}
    REQUIRES ${main_requires}
    INCLUDE_DIRS "." "app" "apps" "font" "ui" "factory" "book" "net"
    EMBED_FILES
        # 瘦身第一批：TTF/图标掩码/首页时钟位图改为 zlib 压缩容器（PIA1），运行时解压到
        # PSRAM；原始 builtin.ttf 不再进镜像（源文件保留，仅供工具/回退）。
        # Slim batch 1: TTF, icon masks and Home-clock bitmaps ship as zlib containers (PIA1)
        # and inflate into PSRAM at runtime; the raw builtin.ttf is no longer embedded.
        "assets/builtin.ttf.z"
        "assets/ui_icons_masks.z"
        "assets/home_clock.z"
        "assets/ui-hanzi.bin"
        "assets/display-test.png"
)

# 包住 IDF 的 panic 处理器：崩溃现场在重启前落进 RTC，没有串口时那是唯一的现场。
# 链接选项挂在 main 上，INTERFACE 会带到最终链接；写在 project() 之后的全局属性则太晚。
# Wrap the IDF panic handler so the crash scene reaches RTC before a restart; without a console
# that is the only place it survives. The option hangs off main, whose INTERFACE carries it into
# the final link; a global property set after project() is too late for the linker to see it.
target_link_options(${COMPONENT_LIB} INTERFACE "-Wl,--wrap=esp_panic_handler")

# 本地 USB 测时入口，普通构建不包含。/ Local USB timing probe, omitted from ordinary product builds.
if("$ENV{KIIKO_LOCAL_LATENCY}" STREQUAL "1")
    target_compile_definitions(${COMPONENT_LIB} PRIVATE KIIKO_LOCAL_LATENCY=1)
endif()

# 剩余空间全部用于流畅性：整个 main 组件从默认 -O2 提到 -O3（字体栅格化、正文排版、
# 绘制、UI 合成、编码解码等所有热点都受益）。必须放在 idf_component_register 之后，
# 那里 ${COMPONENT_LIB} 才存在。脚本模式（IDF 扫描依赖时）会 include 本文件，跳过。
# Spare flash goes to smoothness: the whole main component moves from -O2 to -O3 (font
# rasterization, layout, drawing, UI composition, image decode all benefit). Must come after
# idf_component_register, where ${COMPONENT_LIB} exists; script-mode scans skip it.
if(NOT CMAKE_SCRIPT_MODE_FILE)
    target_compile_options(${COMPONENT_LIB} PRIVATE -O3)
endif()

# 只给最热的像素/排版文件开循环展开（整组件展开会多出 300KB 且压 I-cache）。
# Unroll only the hottest pixel/layout units (unrolling everything added 300 KB and thrashed the
# instruction cache).
if(NOT CMAKE_SCRIPT_MODE_FILE)
    set_source_files_properties(
        "book/book_layout.c" "book/book_md.c" "display.c" "font/ttf_font.c" "ui/ui_kit.c"
        "apps/app_book.c" "apps/app_dashboard.c" "ui/ui_home_clock.c"
        PROPERTIES COMPILE_OPTIONS "-funroll-loops")
endif()
